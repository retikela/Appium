package com.utc.BD.Pages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.support.ui.ExpectedConditions;

import com.appium.Common.Element;
import com.appium.Common.GenericFunctions;
import com.appium.Common.ObjectMap;
import com.appium.Common.SwitchContext;

import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;

public class CtSelfAssessment {
	GenericFunctions genericfnc= GenericFunctions.getInstance();
	private MobileElement covidPositive() throws Exception{
		if(GenericFunctions.isIOS()) {
			Element.waitforVisible("id", ObjectMap.getvalue("SelfAssessment_lbl_covidPostiveReponse"),15);
			return Element.findElementbyID(ObjectMap.getvalue("SelfAssessment_lbl_covidPostiveReponse"));
		}
		else {
			Element.swipeDown(10);
			List<MobileElement> eleList=Element.findElementsbyClass(genericfnc.getButtonClass());
			return eleList.get(1);
		}
	}

	public void MarkingUsercovidPositive() throws Exception{
		/*Add switch validation and create one more func for covid -*/
		covidPositive().click();
	}

	private MobileElement Apply() throws Exception{
		if(GenericFunctions.isIOS())
		{
			return Element.findElementbyID(ObjectMap.getvalue("SelfAssessment_btn_Apply"));
		}
		else
		{
			return Element.findElementbyID("btn_apply");
		}
	}

	public void clickAplyBtn() throws Exception{
		Apply().click();
		Thread.sleep(10000);
	}

	private MobileElement submitDeclaration() throws Exception{
		if(GenericFunctions.isIOS()) {
			return Element.findElementbyID(ObjectMap.getvalue("SelfAssessment_btn_confOK"));
		}
		else
		{
			return Element.findChildElementsbyClass(Element.findElementbyClass(genericfnc.getDialogClass()), genericfnc.getButtonClass()).get(Integer.parseInt(ObjectMap.getvalue("SelfAss_btn_confPopupOk")));
//			return Element.findElementbyClassIndex(genericfnc.getButtonClass(), Integer.parseInt(ObjectMap.getvalue("SelfAss_btn_confPopupOk")));
		}
	}

	/*
	 * Author-Sandeep
	 * */
	public String xpathString(String partOfString)
	{
		String xPath="//*[@text='"+partOfString+"']";
		return xPath;
	}
	public void clickConfirmOKBtn() throws Exception{
		submitDeclaration().click();
	}
	private List<MobileElement> completeSA() throws Exception{
		return Element.findElementsbyID(ObjectMap.getvalue("SelfAssessment_btn_completeSA"));
	}

	public String xpath(String partOfString)
	{
		String xPath="//*[@text='"+" "+partOfString+"']";
		return xPath;
	}
	/*public void clickcompleteSA() throws Exception{
	if(GenericFunctions.isIOS())
	{
		if(Element.waitforVisible("id", ObjectMap.getvalue("SelfAssessment_btn_completeSA"),15)) {
			        {
			( Element.findElementbyID(ObjectMap.getvalue("SelfAssessment_btn_completeSA"))).click();
		}
		else
		{
			System.out.println("popup is not displayed");
		}
	}
	else
	{
		List<MobileElement> ele=Element.findElementsbyClass(genericfnc.getButtonClass());
		for(int i=0;i<ele.size();i++)
		{
			if((ele.get(i).getText()).equals(ObjectMap.getvalue("SelfAssessment_PopupOkButton_txt")))
			{
				Element.findElementbyClassIndex(genericfnc.getButtonClass(), Integer.parseInt(ObjectMap.getvalue("selfAss_btn_popupOkButton"))).click();
				break;
			}


		}
		System.out.println(poupNumber);
        if(poupNumber>3)
        {
        	Element.findElementbyClassIndex(genericfnc.getButtonClass(), Integer.parseInt(ObjectMap.getvalue("selfAss_btn_popupOkButton"))).click();
        }
        else
        {
            System.out.println("popup is not displayed");
        }
	}
}

*/

public void clickcompleteSA(){
	try {
		if(OKBtnOnConfPopup()!= null) {
			//SwitchContext.switchToWebViewContext();
			OKBtnOnConfPopup().click();
			//SwitchContext.switchToNativeContext();
		}
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
private MobileElement OKBtnOnConfPopup() throws Exception{
	if(GenericFunctions.isIOS()) {
		if(Element.waitforVisible("id", ObjectMap.getvalue("SelfAssessment_btn_completeSA"),30)) {
			System.out.println("CLicking OK button");
	return Element.findElementbyID(ObjectMap.getvalue("SelfAssessment_btn_completeSA"));
}
else
{
return null;
}
	}
	else
//		if(Element.waitforVisible("id", ObjectMap.getvalue("selfAss_btn_popupOkButton"),15)) {
//	        
			return Element.findChildElementsbyClass(Element.findElementbyClass(genericfnc.getDialogClass()), genericfnc.getButtonClass()).get(Integer.parseInt(ObjectMap.getvalue("selfAss_btn_popupOkButton")));
		
//		}
//		else
//		{
//		return null;
//		}
	

}

	public void covidSymptomsReponse() throws Exception{

		Element.waitforVisible("id", ObjectMap.getvalue("SelfAssessment_lbl_covidSymptomsReponse"));
		covidSymptoms().click();
	}

	private MobileElement covidSymptoms() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("SelfAssessment_lbl_covidSymptomsReponse"));
	}

	public void areYouLocatedInContainmentZoneReponse() throws Exception{

		Element.waitforVisible("id", ObjectMap.getvalue("SelfAssessment_lbl_LocatedInContainmentZoneReponse"));
		covidSymptoms().click();
	}

	private MobileElement areYouLocatedInContainmentZone() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("SelfAssessment_lbl_LocatedInContainmentZoneReponse"));
	}


	public void contactExposureResponse() throws Exception{

		Element.waitforVisible("id", ObjectMap.getvalue("SelfAssessment_lbl_contactExposureReponse"));
		covidSymptoms().click();
	}

	private MobileElement contactExposure() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("SelfAssessment_lbl_contactExposureReponse"));
	}

	public void quarantinePeriodResponse() throws Exception{

		Element.waitforVisible("id", ObjectMap.getvalue("SelfAssessment_lbl_quarantinePeriodResponse"));
		covidSymptoms().click();
	}

	private MobileElement quarantinePeriod() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("SelfAssessment_lbl_quarantinePeriodResponse"));
	}
	public String AreYouDiagnoisedwithCovidQuetsion() throws Exception{
		if(GenericFunctions.isIOS()) {
			return AreYouDiagnoisedwithCovid().getText();
		}
		else {
			String text=AreYouDiagnoisedwithCovid().getText();
			String finalString=text.substring(1);
			finalString=finalString.trim();
			return finalString;
		}
	}
	private MobileElement AreYouDiagnoisedwithCovid() throws Exception{
		if(GenericFunctions.isIOS()) {
			return Element.findElementbyID(ObjectMap.getvalue("SelfAssessment_lbl_titleQuestion"));
		}
		else {
			return Element.findElementbyClassIndex(genericfnc.getLableClass(), Integer.parseInt(ObjectMap.getvalue("selfAss_txt_QuestionNumber1Index")));
		}
	}
	public String AreYouExperiencingAnySymptomsQuestion() throws Exception{
		if(GenericFunctions.isIOS()) {
			return AreYouExperiencingAnySymptoms().getText();
		}
		else {
			String text=AreYouExperiencingAnySymptoms().getText();
			String finalString=text.substring(1);
			finalString=finalString.trim();
			return finalString;
		}

	}
	private MobileElement AreYouExperiencingAnySymptoms() throws Exception{
		if(GenericFunctions.isIOS()) {
			return Element.findElementbyID(ObjectMap.getvalue("SelfAssessment_lbl_Question1"));
		}
		else {
			return Element.findElementbyClassIndex(genericfnc.getLableClass(), Integer.parseInt(ObjectMap.getvalue("selfAss_txt_QuestionNumber2Index")));
		}
	}
	public String AreYouInContaimentZoneQuestion() throws Exception{
		if(GenericFunctions.isIOS()) {
			return AreYouInContaimentZone().getText();
		}
		else {
			String text=AreYouInContaimentZone().getText();
			String finalString=text.substring(1);
			finalString=finalString.trim();
			return finalString;
		}
	}
	private MobileElement AreYouInContaimentZone() throws Exception{
		if(GenericFunctions.isIOS()) {
			return Element.findElementbyID(ObjectMap.getvalue("SelfAssessment_lbl_Question2"));
		}
		else {
			return Element.findElementbyClassIndex(genericfnc.getLableClass(), Integer.parseInt(ObjectMap.getvalue("selfAss_txt_QuestionNumber3Index")));
		}
	}

	public String contactExposureQuestion() throws Exception{
		if(GenericFunctions.isIOS()) {
			return contactExposureID().getText();
		}
		else
		{
			String text=contactExposureID().getText();
			String finalString=text.substring(1);
			finalString=finalString.trim();
			return finalString;
		}
	}
	private MobileElement contactExposureID() throws Exception{
		if(GenericFunctions.isIOS()) {
			return Element.findElementbyID(ObjectMap.getvalue("SelfAssessment_lbl_Question3"));
		}
		else
		{
			return Element.findElementbyClassIndex(genericfnc.getLableClass(), Integer.parseInt(ObjectMap.getvalue("selfAss_txt_QuestionNumber4Index")));
		}
	}
	public String DoYouRequireCompleteQuarantinePeriodQuestion() throws Exception{
		if(GenericFunctions.isIOS()) {
			return DoYouRequireCompleteQuarantinePeriod().getText();
		}
		else
		{
			String text=DoYouRequireCompleteQuarantinePeriod().getText();
			String finalString=text.substring(1);
			finalString=finalString.trim();
			return finalString;
		}
	}
	private MobileElement DoYouRequireCompleteQuarantinePeriod() throws Exception{
		if(GenericFunctions.isIOS()) {
			return Element.findElementbyID(ObjectMap.getvalue("SelfAssessment_lbl_Quetsion4"));
		}
		else {
			return Element.findElementbyClassIndex(genericfnc.getLableClass(), 4);
		}
	}
	private List<MobileElement> PreferencesOptions() throws Exception{
		return Element.findElementsbyID(ObjectMap.getvalue("accessdenied_lbl_PreferencesOptions"));
	}
	static List<String> CovidNegativePreferencesOptions =Arrays.asList(ObjectMap.getvalue("Preferences_LocationSettings_Txt"),
			ObjectMap.getvalue("Preferences_HealthAndSafetyTracking_Txt"),
			ObjectMap.getvalue("Preferences_Notifications_Txt"),
			ObjectMap.getvalue("Preferences_Sensitivity_Txt"),
			ObjectMap.getvalue("Preferences_Pathways_Txt"),
			ObjectMap.getvalue("Preferences_Favorites_Txt"),
			ObjectMap.getvalue("Preferences_Hidden_Txt"),
			ObjectMap.getvalue("Preferences_Gestures_Txt"),
			ObjectMap.getvalue("Preferences_Geofences_Txt"));
	        

	public boolean preferencesOptionWhenCovidNegative() throws Exception
	{
		boolean status=true;


		for(int i=0;i<PreferencesOptions().size();i++)
		{
			String name=PreferencesOptions().get(i).getText();
			System.out.println(name);
			if(!(CovidNegativePreferencesOptions.contains(name))){
				return false;
			}

		}
		System.out.println(status);
		return status;
	}

	public void waitForSelfAssProgressBar() throws Exception
	{
		Element.waitforVisible("Class", genericfnc.getProgressBarClass());
	}
	/*if(GenericFunctions.isAndroid()) {*/

	/*	}
		else
		{
			System.out.println("SelfAssessmen page is loaded");
		}
	}*/

	public void waitForSelfAssPageToLoad()
	{


		Element.waitforInVisibility("class", genericfnc.getProgressBarClass(), 180);

	}
	public void markUserAsCovidPositive() throws Exception {
		if (GenericFunctions.isIOS()) {

			covidPositive().click();

		} else {

			if (!Element.getCheckBoxStatus(covidPositive())) {
				covidPositive().click();
			}
		}
	}
	public String conformationPoupTitle() throws Exception
	{
		if(GenericFunctions.isAndroid()) {
			String confPopupTitle= Element.findChildElementsbyClass(Element.findElementbyClass(genericfnc.getDialogClass()), genericfnc.getViewClass()).get(2).getText();
                     /*Element.findElementbyClass(genericfnc.getDialogClass()),genericfnc.getButtonClass()).get(Integer.parseInt(ObjectMap.getvalue("SelfAss_btn_confPopupCancel")));*/
//			String confPopupTitle=Element.findElementbyClassIndex(genericfnc.getViewClass(), Integer.parseInt(ObjectMap.getvalue("selfAss_btn_confpopupTitle"))).getText();
	       System.out.println(confPopupTitle);
			return confPopupTitle;
		}
		else
		{
			String confPopupTitle= Element.findElementbyID(ObjectMap.getvalue("selfAss_btn_confpopupTitle")).getText();
			return confPopupTitle;
		}


	}
	public String conformationPoupMsg() throws Exception
	{
		String confPopupMsg=Element.findElementbyClassIndex(genericfnc.getViewClass(), Integer.parseInt(ObjectMap.getvalue("selfAss_btn_ConfPopupMsg"))).getText();

		return confPopupMsg;
	}

	public void clickConfirmCancelBtn() throws Exception{
		cancelBtnOnConfPopup().click();
	}
	private MobileElement cancelBtnOnConfPopup() throws Exception{
		if(GenericFunctions.isIOS()) {
			return Element.findElementbyID(ObjectMap.getvalue("SelfAss_btn_confPopupCancel"));
		}
		else
		{
			return Element.findChildElementsbyClass(Element.findElementbyClass(genericfnc.getDialogClass()), genericfnc.getButtonClass()).get(Integer.parseInt(ObjectMap.getvalue("SelfAss_btn_confPopupCancel")));
			//			return Element.findElementbyClassIndex(genericfnc.getButtonClass(), Integer.parseInt(ObjectMap.getvalue("SelfAss_btn_confPopupCancel")));
		}

	}


	public String conformationPoupMsgFoeCovidNegative() throws Exception
	{
		String confPopupMsg=Element.findElementbyClassIndex(genericfnc.getViewClass(), Integer.parseInt(ObjectMap.getvalue("selfAss_btn_ConfPopupMsg"))).getText();

		return confPopupMsg;
	}
}
