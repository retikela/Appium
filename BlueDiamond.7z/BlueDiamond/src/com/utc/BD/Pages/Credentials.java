package com.utc.BD.Pages;

import org.openqa.selenium.support.PageFactory;

import com.appium.Common.AppiumSetup;
import com.appium.Common.Element;
import com.appium.Common.GenericFunctions;
import com.appium.Common.Gestures;
import com.appium.Common.ObjectMap;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class Credentials {
	public Credentials(AppiumDriver<?> driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
//	private MobileElement header() throws Exception{
//		return Element.findElementbyID(ObjectMap.getvalue("Credentials_Navbar_Header"));
//	}
	@AndroidFindBy(id = "headerTitle")
	@iOSXCUITFindBy(accessibility = "Credential-title-label")
	MobileElement header;
	
	
	public boolean waitforCredentialsHeader() throws Exception {
		return Element.waitForElement(header);
	}
	
	public String getHeaderText() throws Exception {
		return header.getText();
	}
	
//	private MobileElement backButton() throws Exception{
//		return Element.findElementbyID(ObjectMap.getvalue("Credentials_btn_Back"));
//	}
	
	@AndroidFindBy(id = "closeButton")
	@iOSXCUITFindBy(accessibility = "Credential-back-button")
	MobileElement backButton;
	
	public void clickBack() throws Exception{
		backButton.click();
	}
	
//	private MobileElement editButton() throws Exception{
//		return Element.findElementbyID(ObjectMap.getvalue("Credentials_img_editIcon"));
//	}
	
	@AndroidFindBy(id = "penIcon")
	@iOSXCUITFindBy(accessibility = "Credential-penicon-view")
	MobileElement editButton;
	
	public void clickEditButton() throws Exception{
		editButton.click();
	}
	
//	private MobileElement credentialName() throws Exception{
//		return Element.findElementsbyID(ObjectMap.getvalue("Credentials_tbx_CredentialName")).get(0);
//	}
	
	@AndroidFindBy(id = "editcredentialName")
	@iOSXCUITFindBy(accessibility = "Credential-credentialname-field")
	MobileElement credentialName;
	
	
	public void enterCredentailName(String name) throws Exception{
		credentialName.clear();
		credentialName.sendKeys(name);
		Thread.sleep(600);
		GenericFunctions.pressBack();
	}
	
	public String getCredentialName() throws Exception{
		return Element.getTextfromTextbx(credentialName);
	}
	
//	private MobileElement updateCredentials() throws Exception{
//		return Element.findElementbyID(ObjectMap.getvalue("Credentials_btn_UpdateCredentials"));
//	}
	
	@AndroidFindBy(id = "syncButton")
	@iOSXCUITFindBy(accessibility = "Credential-refresh-button")
	MobileElement updateCredentials;
	
	Gestures gestures = new Gestures();
	public void enableDeviceWifi() throws Exception{
		if(GenericFunctions.isAndroid())
			AppiumSetup.enaableWifi();
		else
		gestures.enableWifi();
	}
	
	public void disableDeviceWifi() throws Exception{
		if(GenericFunctions.isAndroid())
			AppiumSetup.disableWifi();
		else
		gestures.disableWifi();
	}
	
	public void clickUpdateCredentials() throws Exception{
		updateCredentials.click();
	}
	
//	private MobileElement lblCredentialID() throws Exception{
//		return Element.findElementbyID(ObjectMap.getvalue("Credentials_lbl_CredentialID"));
//	}
	
	@AndroidFindBy(id = "CredentialID")
	@iOSXCUITFindBy(accessibility = "Credential-titleid-label")
	MobileElement lblCredentialID;
	
	public String getCredentialIDTxt() throws Exception{
		return lblCredentialID.getText();
	}
	
//	private MobileElement lblCredentialIDvalue() throws Exception{
//		return Element.findElementbyID(ObjectMap.getvalue("Credentials_lbl_CredentialIDvalue"));
//	}
	
	@AndroidFindBy(id = "credentialIDLabel")
	@iOSXCUITFindBy(accessibility = "Credential-badgeid-label")
	MobileElement lblCredentialIDvalue;
	
	public String getCredentialIDvalueTxt() throws Exception{
		return lblCredentialIDvalue.getText();
	}
	
//	private MobileElement lblCompanyInformation() throws Exception{
//		return Element.findElementbyID(ObjectMap.getvalue("Credentials_lbl_CompanyInformation"));
//	}
	
	@AndroidFindBy(id = "companyInfoLabel")
	@iOSXCUITFindBy(accessibility = "Credential-companyinfo-label")
	MobileElement lblCompanyInformation;
	
	public String getCompanyInformationTxt() throws Exception{
		return lblCompanyInformation.getText();
	}
	
//	private MobileElement lblCompanyAddress() throws Exception{
//		return Element.findElementbyID(ObjectMap.getvalue("Credentials_lbl_CompanyAddress"));
//	}
	
	@AndroidFindBy(id = "companyDetailLabel")
	@iOSXCUITFindBy(accessibility = "Credential-companyaddress-label")
	MobileElement lblCompanyAddress;
	
	public String getCompanyAddressTxt() throws Exception{
		return lblCompanyAddress.getText();
	}
	
//	private MobileElement lblCompanyName() throws Exception{
//		return Element.findElementbyID(ObjectMap.getvalue("Credentials_lbl_CompanyName"));
//	}
	
	@AndroidFindBy(id = "companyNameLabel")
	@iOSXCUITFindBy(accessibility = "Credential-companyname-label")
	MobileElement lblCompanyName;
	
	public String getCompanyNameTxt() throws Exception{
		return lblCompanyName.getText();
	}
	
//	private MobileElement lblPhoneNo() throws Exception{
//		return Element.findElementbyID(ObjectMap.getvalue("Credentials_btn_PhoneNo"));
//	}
	
	@AndroidFindBy(id = "companyPhoneNumberLabel")
	@iOSXCUITFindBy(accessibility = "Credential-phoneno-linklabel")
	MobileElement lblPhoneNo;
	
	public String getPhoneNoTxt() throws Exception{
		return lblPhoneNo.getText();
	}
	
//	private MobileElement lblSelect() throws Exception{
//		return Element.findElementbyID(ObjectMap.getvalue("Credentials_btn_Select"));
//	}
	
	@AndroidFindBy(id = "Credential-cellselect-button")
	@iOSXCUITFindBy(accessibility = "Credential-cellselect-button")
	MobileElement lblSelect;
	
	public String getSelectTxt() throws Exception{
		return lblSelect.getText();
	}
	
//	private MobileElement lblEmail() throws Exception{
//		return Element.findElementbyID(ObjectMap.getvalue("Credentials_btn_email"));
//	}
	
	@AndroidFindBy(id = "Credential-companyemail-linklabel")
	@iOSXCUITFindBy(accessibility = "companyEmailIDLabel")
	MobileElement lblEmail;
	
	public String getEmailTxt() throws Exception{
		return lblEmail.getText();
	}
	
//	private MobileElement badgeNumber() throws Exception{
//		return Element.findElementbyXpath(ObjectMap.getvalue("Credentials_cell_badgeNumber"));
//	}
	
	@AndroidFindBy(xpath = "//XCUIElementTypeApplication[@name=\"BlueDiamond\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther[2]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTable/XCUIElementTypeCell")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeApplication[@name=\"BlueDiamond\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther[2]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTable/XCUIElementTypeCell")
	MobileElement badgeNumber;
	
	public void clickBadgeNumber() throws Exception{
		badgeNumber.click();
	}
	
//	private MobileElement loadingIndicator() throws Exception{
//		return Element.findElementbyID(ObjectMap.getvalue("Credentials_img_syncingCredentials"));
//	}
	
	@AndroidFindBy(id = "Credential-loading-view")
	@iOSXCUITFindBy(accessibility = "progressSpinner")
	MobileElement loadingIndicator;
	
	public boolean waitforLoadingIndicator() throws Exception{
		return Element.waitForElement(loadingIndicator);
	}
	
//	private MobileElement updatingCredentials() throws Exception{
//		return Element.findElementbyID(ObjectMap.getvalue("Credentials_lbl_UpdatingCredentialsMsg"));
//	}
	
	@AndroidFindBy(id = "credentialUpdateStatus")
	@iOSXCUITFindBy(accessibility = "Credential-statusupdate-label")
	MobileElement updatingCredentials;
	
	public String getUpdatingCredentialsMsg() throws Exception{
		return updatingCredentials.getText();
	}
	
	public void waitforLoaderDismiss() throws Exception{
//		int i=0;
//		try {
//		while(Element.waitForElement(loadingIndicator(), 1)){
//			System.out.println("Still updating credentials");
//			i++;
//			if(i>60){
//				break;
//			}
//		}
//		}catch (Exception e) {
//			// TODO: handle exception
//		}
		Element.waitforInVisibility("id", ObjectMap.getvalue("Credentials_img_syncingCredentials"), 60);
	}
	
	class MyTask implements Runnable
	{
	    public void run() { 
	        // add your code here
	    }
	}

	
	
}
