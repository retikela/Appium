package com.utc.BD.Pages;

import com.appium.Common.Element;
import com.appium.Common.GenericFunctions;
import com.appium.Common.ObjectMap;

import io.appium.java_client.MobileElement;

public class ErrorScren {

	private MobileElement cancel() throws Exception{
		return Element.findElementsbyClass(GenericFunctions.getInstance().getButtonClass()).get(Integer.parseInt(ObjectMap.getvalue("Error_btn_CancelIndex")));
	} 
	
	private MobileElement tryAgain() throws Exception{
		return Element.findElementsbyClass(GenericFunctions.getInstance().getButtonClass()).get(Integer.parseInt(ObjectMap.getvalue("Error_btn_TryagainIndex")));
	}
	
	private MobileElement errorIcon() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Error_img_errIcon"));
	}
	
	private MobileElement errorMessage() throws Exception{
		return Element.findElementsbyClass(GenericFunctions.getInstance().getLableClass()).get(Integer.parseInt(ObjectMap.getvalue("Error_img_errMessageIndex")));
	}
	
	private MobileElement errorType() throws Exception{
		return Element.findElementsbyClass(GenericFunctions.getInstance().getLableClass()).get(Integer.parseInt(ObjectMap.getvalue("Error_lbl_errTypeIndex")));
	}
	
	public void clickCacnel() throws Exception{
		cancel().click();
	}
	
	public void clickTryAgain() throws Exception{
		tryAgain().click();
	}
	
	public String getCacnelText() throws Exception{
		return cancel().getText();
	}
	
	public String getTryAgainText() throws Exception{
		return tryAgain().getText();
	}
	
	public String getErrorMessage() throws Exception{
		return errorMessage().getText();
	}
	
	public String getErrorType() throws Exception{
		return errorType().getText();
	}
	
	public boolean waitForErrorIcon() throws Exception{
		return Element.waitForElement(errorIcon());
	}
	
	private MobileElement errorHintIcon() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("ReaderList_img_errorHintIcon"));
	}
	
	public boolean waitForErrorHintIcon() {
		try {
			return Element.waitForElement(errorHintIcon());
		} catch (Exception e) {
			return false;
		}
	}
	
	public void clickErrorHintIcon() throws Exception{
		errorHintIcon().click();
	}
	
	private MobileElement errorDescription() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("ReaderList_lbl_errorDescription"));
	}
	
	public boolean isErrorDescription() throws Exception{
		return Element.isVisible(errorDescription());
	}
	
	public String getErrorDescription() throws Exception{
		return errorDescription().getText();
	}
	
	private MobileElement errorHintTitle() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("ReaderList_lbl_errorHint"));
	}
	
	public String getErrorHintTitle() throws Exception{
		return errorHintTitle().getText();
	}
}
