package com.utc.BD.Pages;

import com.appium.Common.Element;
import com.appium.Common.GenericFunctions;
import com.appium.Common.ObjectMap;

import io.appium.java_client.MobileElement;

public class PHAAB {
	private MobileElement lblInfo() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("PhoneAsABadge_lbl_info"));
	}
	
	public boolean waitforPHAABInfo() throws Exception {
		return Element.waitForElement(lblInfo());
	}
	
	public String getPHAABInfotext() throws Exception{
		return lblInfo().getText();
	}
	
	private MobileElement btnCancel() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("PhoneAsABadge_btn_cancel"));
	}
	
	public void clickCancel() throws Exception{
		btnCancel().click();
	}
	
	private MobileElement btnStart() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("PhoneAsABadge_btn_START"));
	}
	
	public void clickStart() throws Exception{
		btnStart().click();
		Thread.sleep(5000);
	}
	
	public void selectReader() throws Exception {
		GenericFunctions.acceptAlert();
	}
	
	public void SelectAllreaders() throws Exception {
		GenericFunctions.declineAlert();
	}
	
	public String GetPopupReaderName() throws Exception{
		return GenericFunctions.getInstance().getAcceptAlertText();
	}
	
	public String getStartbtnTxt() throws Exception{
		return btnStart().getText();
	}
	
	private MobileElement lblTapToStartMsg() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("PhoneAsABadge_lbl_tapToStartMsg"));
	}
	
	public String getTapToStartMsgtext() throws Exception{
		return lblTapToStartMsg().getText();
	}
	
	private MobileElement lblSuccess() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("PhoneAsABadge_lbl_Success"));
	}
	
	public String getSuccesstext() throws Exception{
		return lblSuccess().getText();
	}
	
	private MobileElement lblSuccessinfoMsg() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("PhoneAsABadge_lbl_Successinfo"));
	}
	
	public String getlblSuccessinfoMsgtext() throws Exception{
		return lblSuccessinfoMsg().getText();
	}
	
	private MobileElement lblReaderName() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("PhoneAsABadge_lbl_readerName"));
	}
	
	public String getReaderName() throws Exception{
		return lblReaderName().getText();
	}
	
	private MobileElement btnDone() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("PhoneAsABadge_btn_Done"));
	}
	
	public void clickDone() throws Exception{
		btnDone().click();
	}
	
	public String getDonebtnTxt() throws Exception{
		return btnDone().getText();
	}
	
}
