package com.utc.BD.Pages;

import java.util.Arrays;
import java.util.List;

import com.appium.Common.Element;
import com.appium.Common.ObjectMap;

import io.appium.java_client.MobileElement;

public class AccessDenied
{
	private MobileElement accessDeniedheader() throws Exception{
		Element.waitforVisible("id", ObjectMap.getvalue("AccessDenied_lbl_Heading"));
		return Element.findElementbyID(ObjectMap.getvalue("AccessDenied_lbl_Heading"));
	}
	
	private List<MobileElement> PreferencesOptions() throws Exception{
		return Element.findElementsbyID(ObjectMap.getvalue("accessdenied_lbl_PreferencesOptions"));
	}
	public boolean waitforAccessDeniedHeader() throws Exception {
		return Element.waitForElement(accessDeniedheader());
	}
	
	
	public String getQuarantineEndDate() throws Exception{
		return QuarantineEndDate().getText();
	
}
	
	private MobileElement QuarantineEndDate() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("AccessDenied_lbl_Quarantine-EndDate"));
	}
	
	private MobileElement accessDeniedMsgDescription() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("accessDenied_lbl_Description"));
	}
	
	private MobileElement accessDeniedMsgQues() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("accessDenied_lbl_msgQues"));
	}
	
	private MobileElement refreshBtn() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("accessDenied_btn_Refresh"));
	}
	
	public String accessDeniedDescription() throws Exception
	{
		return accessDeniedMsgDescription().getText();
	}
	
	public String accessDeniedQuesMsg() throws Exception
	{
		return accessDeniedMsgQues().getText();
	}
	
	public void clickRefreshBtn() throws Exception
	{
		refreshBtn().click();
	}
	public void clickSettings() throws Exception{
		  settings().click();
}
	
	private MobileElement settings() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("AccessDenied_icon_menu"));
	}
		
	public boolean gestureIsDisplay() throws Exception
	{
		boolean status=false;
		for(int i=0;i<PreferencesOptions().size();i++)
		{
			String name=PreferencesOptions().get(i).getText();
			if(name.equalsIgnoreCase("Gestures"))
			{
				status=true;
			}
		}
		System.out.println(status);
		return status;
	}
	/*static List<String> CovidNegativePreferencesOptions =Arrays.asList(ObjectMap.getvalue("Preferences_LocationSettings_Txt"),
			ObjectMap.getvalue("Preferences_Notifications_Txt"),
			ObjectMap.getvalue("Preferences_Sensitivity_Txt"),
			ObjectMap.getvalue("Preferences_Pathways_Txt"),
			ObjectMap.getvalue("Preferences_Favorites_Txt"),
			ObjectMap.getvalue("Preferences_Hidden_Txt"),
			ObjectMap.getvalue("Preferences_Gestures_Txt"));
			
	public boolean healthAndSafetyTrackingPresent() throws Exception
	{
		boolean status=false;
		
		
		for(int i=0;i<PreferencesOptions().size();i++)
		{
			String name=PreferencesOptions().get(i).getText();
			System.out.println(name);
			if(!(CovidNegativePreferencesOptions.contains(name))){
				return true;
			}
			
		}
		System.out.println(status);
		return status;
	}}
*/
	public boolean healthAndSafetyTrackingPresent() throws Exception
	{
		boolean status=true;
		for(int i=0;i<PreferencesOptions().size();i++)
		{
			String name=PreferencesOptions().get(i).getText();
			if(name.equalsIgnoreCase(ObjectMap.getvalue("Preferences_LocationSettings_Txt"))||
					name.equalsIgnoreCase(ObjectMap.getvalue("Preferences_Notifications_Txt"))||
					name.equalsIgnoreCase(ObjectMap.getvalue("Preferences_Sensitivity_Txt")) ||
				    name.equalsIgnoreCase(ObjectMap.getvalue("Preferences_Pathways_Txt")) ||
					name.equalsIgnoreCase(ObjectMap.getvalue("Preferences_Favorites_Txt")) ||
					name.equalsIgnoreCase(ObjectMap.getvalue("Preferences_Hidden_Txt"))
					||name.equalsIgnoreCase(ObjectMap.getvalue("Preferences_Gestures_Txt")))
			{
				status=false;
			}
		}
		System.out.println(status);
		return status;
	}
	}

