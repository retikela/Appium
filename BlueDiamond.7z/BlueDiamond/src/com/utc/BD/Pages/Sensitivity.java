package com.utc.BD.Pages;

import com.appium.Common.Element;
import com.appium.Common.ObjectMap;

import io.appium.java_client.MobileElement;

public class Sensitivity {
	private MobileElement Overall() throws Exception {
		return Element.findElementsbyID(ObjectMap.getvalue("Sensitivity_lbl_Header"))
				.get(Integer.parseInt(ObjectMap.getvalue("Sensitivity_lbl_OverallIndex")));
	}

	public String getOverallText() throws Exception {
		return Element.getElementText(Overall());

	}
	
	private MobileElement Pathways() throws Exception {
		return Element.findElementsbyID(ObjectMap.getvalue("Sensitivity_lbl_Header"))
				.get(Integer.parseInt(ObjectMap.getvalue("Sensitivity_lbl_PathwaysIndex")));
	}

	public String getPathwaysText() throws Exception {
		return Element.getElementText(Pathways());

	}

	private MobileElement title() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Sensitivity_lbl_Title"));
	}

	public boolean waitforSensitivityPageTitle() throws Exception {
		return Element.waitForElement(title());
	}

	public String getTitleText() throws Exception {
		return Element.getElementText(title());

	}

	private MobileElement backButton() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Sensitivity_btn_Back"));
	}

	public void clickBack() throws Exception {
		backButton().click();
	}

	
	private MobileElement pathwaysSlider() throws Exception {
		return Element.findElementsbyID(ObjectMap.getvalue("Sensitivity_slider_ReaderTypes"))
				.get(Integer.parseInt(ObjectMap.getvalue("Sensitivity_lbl_PathwaysIndex")));
	}
	
	private MobileElement overallSlider() throws Exception {
		return Element.findElementsbyID(ObjectMap.getvalue("Sensitivity_slider_ReaderTypes"))
				.get(Integer.parseInt(ObjectMap.getvalue("Sensitivity_lbl_OverallIndex")));
	}
	
	public void setMinvalToOverallSlider() throws Exception {
		Element.swipeSliderLeft(overallSlider(), 0);
	}
	
	public void setOverallSliderValue(int percentage) throws Exception {
//		Element.swipeSliderLeft(overallSlider(), 90);
		Element.setSliderVal(overallSlider(), percentage);
	}

	public String getOverallSliderVal() throws Exception {
		return Element.getAttribute(overallSlider(), "value");
	}
	
	public String getPathwaySliderVal() throws Exception {
		return Element.getAttribute(pathwaysSlider(), "value");
	}

}
