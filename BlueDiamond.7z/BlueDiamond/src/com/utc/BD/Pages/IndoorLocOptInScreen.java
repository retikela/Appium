package com.utc.BD.Pages;

import org.testng.Reporter;

import com.appium.Common.Element;
import com.appium.Common.GenericFunctions;
import com.appium.Common.ObjectMap;

import io.appium.java_client.MobileElement;

public class IndoorLocOptInScreen {
	
	public MobileElement titleOptIn() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("optin_lbl_title"));
	}
	
	public MobileElement imgToggle() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("optin_img_toggle"));
	}
	
	public MobileElement textToggle() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("optin_lbl_toggleText"));
	}
	
	public MobileElement checkBoxLiveNavigation() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("optin_chckbox_live"));
	}
	
	public MobileElement checkBoxBGService() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("optin_chckbox_bgServices"));
	}
	
	public MobileElement checkBoxGeofence() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("optin_chckbox_geoFence"));
	}
	
	public MobileElement btnContinue() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("optin_btn_continue"));
	}
	
	public MobileElement verbiage() throws Exception {
		if (GenericFunctions.isIOS()) {
			return Element.findElementbyID(ObjectMap.getvalue("optin_lbl_verbiage"));
		} else {
			return Element.findElementbyXpath(ObjectMap.getvalue("optin_lbl_verbiage"));
		}
		
	}
	
	public MobileElement verbiageInNoThanksAlert() throws Exception {
		if (GenericFunctions.isIOS()) {
			return Element.findElementbyID(ObjectMap.getvalue(""));
		} else {
			return Element.findElementbyXpath(ObjectMap.getvalue("optin_lbl_noThanksAlertVerbiage"));
		}
	}
	
	public String getMessageFromAlert() throws Exception {
		String message = "";
		message = GenericFunctions.getAlertMsg();
		message = message.replaceAll("\n", " ");

		return message;
	}
	
	public MobileElement btnNoThanks() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("optin_btn_noThanks"));
	}
	
	public MobileElement btnNoThanksInAlert() throws Exception {
		return Element.findElementbyID("button2");
	}
	
	public MobileElement btnEnableInAlert() throws Exception {
		return Element.findElementbyID("button1");
	}
	
	public void clickNoThanks() throws Exception {
		btnNoThanks().click();
	}
	
	public void clickNoThanksInAlert() throws Exception {
		btnNoThanksInAlert().click();
	}
	
	public void clickEnableInAlert() throws Exception {
		btnEnableInAlert().click();
	}
	
	public String getverbiageOnNoThanksAlert() throws Exception {
		return verbiageInNoThanksAlert().getText();
	}
	
	public String getBtn2TextOnNoThanksAlert() throws Exception {
		return btnNoThanksInAlert().getText();
	}
	
	public String getBtn1TextOnNoThanksAlert() throws Exception {
		return btnEnableInAlert().getText();
	}
	
	public String getNoThanksBtnTxt() throws Exception {
		return btnNoThanks().getText();
	}
	
	
	public void clickLiveNavigation() throws Exception {
		checkBoxLiveNavigation().click();
		Thread.sleep(1000);
		Reporter.log("Clicked on Live navigation check box");
	}
	
	public void clickToggle() throws Exception {
		imgToggle().click();
		Thread.sleep(1000);
		Reporter.log("Clicked on Location Service toggle button");
	}
	
	public void clickBGService() throws Exception {
		checkBoxBGService().click();
		Thread.sleep(1500);
		Reporter.log("Clicked on BG services check box");
	}
	
	public void clickGeoFence() throws Exception {
		checkBoxGeofence().click();
		Thread.sleep(1500);
		Reporter.log("Clicked on Geo fence check box");
	}
	
	public void clickContinue() throws Exception {
		btnContinue().click();
		Thread.sleep(1000);
		Reporter.log("Clicked on continue button");
	}
	
	public String getverbiage() throws Exception {
		return verbiage().getText();
	}
	
	public String getPageTitle() throws Exception {
		return titleOptIn().getText();
	}
	
	public String getToggleText() throws Exception {
		return textToggle().getText();
	}
	
	public boolean verifyLiveNavigationAvailibility() throws Exception {
		boolean flag = false;
		try {
			if (checkBoxLiveNavigation().isDisplayed()) {
				return flag;
			}
		} catch (Exception e) {
			return flag;
		}
		return flag;
	}
	
	public boolean verifyCheckBoxState(MobileElement element) throws Exception {
		boolean flag = false;

		if (GenericFunctions.isAndroid()) {
			if (element.getAttribute("checked").equals("false")) {
				flag = false;
				Reporter.log("State of the checkbox is disabled");
			} else {
				flag = true;
				Reporter.log("State of the checkbox is enabled");
			}

		} else {
			if (element.getAttribute("label").equals("Checkbox OFF")) {
				flag = false;
				Reporter.log("State of the checkbox is disabled");
			} else {
				flag = true;
				Reporter.log("State of the checkbox is enabled");
			}
		}
		return flag;

	}
	

}
