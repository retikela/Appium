package com.utc.BD.Pages;

import java.util.List;
import java.util.Random;

import org.testng.Reporter;

import com.appium.Common.Element;
import com.appium.Common.GenericFunctions;
import com.appium.Common.Gestures;
import com.appium.Common.ObjectMap;

import io.appium.java_client.MobileElement;

public class BrowsePoints {
	
	Gestures gest = new Gestures();

	public MobileElement header_browsePoints() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("points_lbl_header"));
	}

	public MobileElement btn_thisFloor() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("points_btn_thisFloor"));
	}

	public MobileElement btn_allFloors() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("points_btn_allFloors"));
	}

	public MobileElement btn_filter() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("points_btn_filter"));
	}

	public MobileElement btn_cancel() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("points_lbl_cancel"));
	}

	public MobileElement clearText() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("points_btn_clearText"));
	}

	public MobileElement clearFilter() throws Exception {
		if (GenericFunctions.isIOS()) {
			return Element.findElementbyID(ObjectMap.getvalue("points_lbl_clearFilter"));
		} else {
			return Element.findElementbyXpath(ObjectMap.getvalue("points_lbl_clearFilter"));
		}
	}

	public MobileElement apply() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("points_btn_apply"));
	}

	public MobileElement filterApplied() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("points_btn_filterApplied"));
	}

	public MobileElement searchPoiResult() throws Exception {
		if (GenericFunctions.isIOS()) {
			return Element.findElementbyID(ObjectMap.getvalue("points_lbl_searchPoi"));
		} else {
			return Element.findElementbyXpath(ObjectMap.getvalue("points_lbl_searchPoi"));
		}
	}

	public MobileElement resultPoiType() throws Exception {
		if (GenericFunctions.isIOS()) {
			return Element.findElementbyID(ObjectMap.getvalue("points_lbl_resultPoiType"));
		} else {
			return Element.findElementbyXpath(ObjectMap.getvalue("points_lbl_resultPoiType"));
		}
	}

	public MobileElement search() throws Exception {
		if (GenericFunctions.isIOS()) {
		return Element.findElementbyID(ObjectMap.getvalue("points_txtFld_search"));
		} else {
			return Element.findElementbyID(ObjectMap.getvalue("points_txtFld_search"));
		}
	}

	public MobileElement PoiType() throws Exception {
		if (GenericFunctions.isIOS()) {
			return Element.findElementbyXpath(ObjectMap.getvalue("points_btn_selectPOI"));
		} else {
			return Element.findElementbyXpath(ObjectMap.getvalue("points_btn_selectPOI"));
		}
	}
	
	public int poiCount() throws Exception {
		List<MobileElement> count = Element.findElementsbyXpath(ObjectMap.getvalue("points_lbl_poiCount"));
		return count.size();
	}
	
	private MobileElement sensitivity() throws Exception{
		return Element.findElementbyIdIndex(ObjectMap.getvalue("Preferences_lbl_options"), Integer.parseInt(ObjectMap.getvalue("Preferences_Cell_SensitivityIndex")));
	}
	
	public String verifyPageTitle() throws Exception {
		return header_browsePoints().getText();
	}

	public void clickAllFloors() throws Exception {
		btn_allFloors().click();
		Reporter.log("Clicked on All Floors tab");
		Thread.sleep(1000);
	}

	public void clickThisFloor() throws Exception {
		btn_thisFloor().click();
		Reporter.log("Clicked on This Floor tab");
		Thread.sleep(1000);
	}

	public void clickFilter() throws Exception {
		btn_filter().click();
		Reporter.log("Clicked on Filter button");
		Thread.sleep(1000);
	}

	public void clickApply() throws Exception {
		apply().click();
		Reporter.log("Clicked on Apply button");
		Thread.sleep(1000);
	}

	public void selectPoiType() throws Exception {
		PoiType().click();
		Reporter.log("Clicked on Filter checkbox button");
		Thread.sleep(1000);
	}

	public void clickCancel() throws Exception {
		btn_cancel().click();
		Reporter.log("Clicked on Cancel button");
		Thread.sleep(1000);
	}

	public void clickClearText() throws Exception {
		clearText().click();
		Reporter.log("Clicked on Clear text button in the search feild");
		Thread.sleep(1000);
	}

	public void verifySearch() throws Exception {
		search().sendKeys("main");
		Reporter.log("Entered text in the search feild");
		Thread.sleep(1000);
	}
	
	public boolean selectRandomPOI() throws Exception {
		
		List<MobileElement> poiCount = Element.findElementsbyXpath(ObjectMap.getvalue("points_lbl_poiCount"));
		int count = poiCount.size();
		Random r = new Random();
		int randomNumber = r.nextInt(count - 1) + 1;
		MobileElement poi = Element.findElementbyXpath("(//*[@id='listPOI' or @id='listBrowseMaps']//*[@id='poiName'])["+randomNumber+"]");
		String poiName = poi.getText();
		search().sendKeys(poiName);
		MobileElement searchString = Element.findElementbyXpath("//*[@id='poiName' and @text='"+poiName+"']");
		if(poiName.contentEquals(searchString.getText())) {
			return true;
		} else {
			return false;
		}
	}
	
	public String selectRandomPOIForStart() throws Exception {
		MobileElement poi;
		MobileElement searchString;
		int count = 0;
		String poiName = "";
		List<MobileElement> poiCount = Element.findElementsbyXpath(ObjectMap.getvalue("points_lbl_poiCount"));
		count = poiCount.size();
		Reporter.log("There are a total of "+count+" POI's available.");
		Random r = new Random();
		int randomNumber = r.nextInt(9 - 1) + 1;
		//int randomNumber = 10;
		if (GenericFunctions.isAndroid()) {
		poi = Element.findElementbyXpath("(//*[@id='listPOI' or @id='listBrowseMaps']//*[@id='poiName'])[" + randomNumber + "]");
		} else {
			if(randomNumber > 9) {
				poi = Element.findElementbyXpath("(//*[@class='UIAImage']//following-sibling::*[@class='UIAStaticText'][1])[" + randomNumber + "]");	
				gest.scrollFromBottomOfScreen();
			}
			poi = Element.findElementbyXpath("(//*[@class='UIAImage']//following-sibling::*[@class='UIAStaticText'][1])[" + randomNumber + "]");	
		}
		
		Thread.sleep(1000);
		poiName = poi.getText();
		
		search().sendKeys(poiName);
		Reporter.log("Entered the search string as "+poiName+" in the search field.");
		if (GenericFunctions.isAndroid()) {
			searchString = Element.findElementbyXpath("//*[@id='poiName' and @text='" + poiName + "']");
		} else {
			searchString = Element.findElementbyXpath("//*[@id='labelName' and @text='" + poiName + "']");	
		}
		
		if (poiName.contentEquals(searchString.getText())) {
			Reporter.log("POI search result is as expected ");
		} else {
			Reporter.log("POI search result is not as expected ");
		}
		
		searchString.click();
		Reporter.log("Clicked on selected POI");
		
		return poiName;
	}
	
	public MobileElement generateRandomPOI() throws Exception {
		MobileElement poi = null;
		int count = 0;
		//String poiName = "";
		try {
			List<MobileElement> poiCount = Element.findElementsbyXpath(ObjectMap.getvalue("points_lbl_poiCount"));
			count = poiCount.size();
			
			Random r = new Random();
			int randomNumber = r.nextInt(count - 1) + 1;
			if (GenericFunctions.isAndroid()) {
			poi = Element.findElementbyXpath("(//*[@id='listPOI' or @id='listBrowseMaps']//*[@id='poiName'])[" + randomNumber + "]");
			} else {
				poi = Element.findElementbyXpath("(//*[@id='labelName'])[" + randomNumber + "]");	
			}
			return poi;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return poi;
	}
	
	public String getGeneratedRandomPOIText() throws Exception {
		MobileElement poi = null;
		int count = 0;
		String poiName = "";
		try {
			List<MobileElement> poiCount = Element.findElementsbyXpath(ObjectMap.getvalue("points_lbl_poiCount"));
			count = poiCount.size();
			
			Random r = new Random();
			int randomNumber = r.nextInt(count - 1) + 1;
			if (GenericFunctions.isAndroid()) {
			poi = Element.findElementbyXpath("(//*[@id='listPOI' or @id='listBrowseMaps']//*[@id='poiName'])[" + randomNumber + "]");
			} else {
				poi = Element.findElementbyXpath("(//*[@id='labelName'])[" + randomNumber + "]");	
			}
			
			poiName = poi.getText();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return poiName;
	}

}
