package com.utc.BD.Pages;

import java.util.Base64;

import com.appium.Common.AppiumSetup;
import com.appium.Common.Element;
import com.appium.Common.GenericFunctions;
import com.appium.Common.Gestures;
import com.appium.Common.ObjectMap;

import io.appium.java_client.MobileElement;
import io.appium.java_client.clipboard.ClipboardContentType;
import io.appium.java_client.clipboard.HasClipboard;
import io.appium.java_client.pagefactory.bys.ContentType;

public class LoginPage {

	public MobileElement userID() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Login_tbx_username"));
	}

	public MobileElement password() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Login_tbx_password"));
	}

	public MobileElement signIn() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Login_btn_next"));
	}
	
	public MobileElement clearBtn() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Login_btn_clearButton"));
	}

	public MobileElement checkboxEula() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Login_cbx_EULA"));
	}

	public MobileElement Eula() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Login_lbl_EULA"));
	}

	public MobileElement Privacy() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Login_lbl_DataPrivacy"));
	}

	public MobileElement checkboxDataPrivacy() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Login_cbx_DataPrivacy"));
	}

	public MobileElement logo() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Login_img_logo"));
	}

	public boolean waitforLogo() throws Exception {
		return Element.waitForElement(logo());
	}

	public MobileElement LocationServicesAlertinfo() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("LocationServicesAlert_lbl_info"));
	}

	public boolean waitforLocationServicesAlertinfo() {
		try {
			return Element.waitForElement(LocationServicesAlertinfo(), 3);
		} catch (Exception e) {
			return false;
		}
	}

	public MobileElement whileUsing() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("LocationServicesAlert_btn_whileUsing"));
	}

	public void clickWhileUsing() throws Exception {
		if(waitforLocationServicesAlertinfo())
		whileUsing().click();
	}

	public MobileElement alwaysAllow() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("LocationServicesAlert_btn_alwaysAllow"));
	}

	public void clickAlwaysAllow() throws Exception {
		if(waitforLocationServicesAlertinfo())
		alwaysAllow().click();
	}

	public MobileElement dontAllow() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("LocationServicesAlert_btn_dontAllow"));
	}

	public void clickDontAllow() throws Exception {
		if(waitforLocationServicesAlertinfo())
		dontAllow().click();
	}

	public MobileElement NotificationsAlertinfo() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("NotificationsAlert_lbl_info"));
	}
	
	public MobileElement motionNdFitnessAlertinfo() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("motionNdFitnessAlert_lbl_info"));
	}
	
	public MobileElement bleAlertinfo() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("BleAlert_lbl_info"));
	}
	
	public MobileElement paymentAlertinfo() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("PaymentCardsAlert_lbl_info"));
	}

	public boolean waitforNotificationsAlertinfo() {
		try {
			return Element.waitForElement(NotificationsAlertinfo(), 3);
		} catch (Exception e) {
			return false;
		}
	}
	
	public boolean waitforMotionNdFitnessinfo() {
		try {
			return Element.waitForElement(motionNdFitnessAlertinfo(), 3);
		} catch (Exception e) {
			return false;
		}
	}
	
	public boolean waitforBLEalert() {
		try {
			return Element.waitForElement(bleAlertinfo(), 3);
		} catch (Exception e) {
			return false;
		}
	}
	
	public boolean waitforPaymentalert() {
		try {
			return Element.waitForElement(paymentAlertinfo(), 6);
		} catch (Exception e) {
			return false;
		}
	}

	public MobileElement allow() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("NotificationsAlert_btn_allow"));
	}

	public void clickAllow() throws Exception {
		if(waitforNotificationsAlertinfo())
		allow().click();
	}

	public MobileElement NotificationdontAllow() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("NotificationsAlert_btn_dontAllow"));
	}
	
	public MobileElement MotionNdFitnessAllow() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("motionNdFitnessAlert_btn_allow"));
	}
	
	public MobileElement bleAllow() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("BleAlert_btn_allow"));
	}
	
	public MobileElement paymentAllow() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("PaymentCardsAlert_btn_allow"));
	}

	public void clickNotificationsAllow() throws Exception {
		if(waitforNotificationsAlertinfo())
		NotificationdontAllow().click();
	}
	
	public void acceptMotionNdFitness() throws Exception {
		if(waitforMotionNdFitnessinfo())
			MotionNdFitnessAllow().click();
	}
	
	public void acceptBLEAlert() throws Exception {
		if(waitforBLEalert())
			bleAllow().click();
	}
	
	public void acceptPaymentlert() throws Exception {
		if(waitforPaymentalert())
			paymentAllow().click();
	}

	public void enterUsername(String name) throws Exception {
//		clearBtn().click();
//		Setup.driver.hideKeyboard();
				userID().clear();
//		((HasClipboard) AppiumSetup.driver).setClipboard(ClipboardContentType.URL ,
//				((HasClipboard) AppiumSetup.driver).getClipboard(ClipboardContentType.URL).getBytes());
//		Gestures ges = new Gestures();
//		ges.longPress(userID());
//		Setup.driver.findElementByClassName("XCUIElementTypeMenuItem").click();
		userID().setValue(name);
		Thread.sleep(6000);
		GenericFunctions.pressBack();
		Thread.sleep(600);
	}

	public String getUsername() throws Exception {
		return userID().getText();
	}

	public void enterPassword(String password) throws Exception {
		password().sendKeys(password);
		Thread.sleep(600);
		GenericFunctions.pressBack();
		Thread.sleep(600);
	}

	public void clickSignin() throws Exception {
		signIn().click();
	}

	public void checkEula() throws Exception {
		if (!getEulaStatus()) {
			checkboxEula().click();
		}
	}

	public void checkDataPrivacy() throws Exception {
		if (!getDataPrivacyStatus()) {
			checkboxDataPrivacy().click();
		}
	}

	public void uncheckEula() throws Exception {
		if (getEulaStatus()) {
			checkboxEula().click();
		}
	}

	public void uncheckDataPrivacy() throws Exception {
		if (getDataPrivacyStatus()) {
			checkboxDataPrivacy().click();
		}
	}

	private boolean getEulaStatus() throws Exception {
		return Element.getCheckBoxStatus(checkboxEula());
//		String status = Element.getAttribute(checkboxEula(), "label");
//		if ((!status.isEmpty()) && status.equalsIgnoreCase("unchecked")) {
//			return false;
//		} else
//			return true;
	}

	private boolean getDataPrivacyStatus() throws Exception {
//		String status = Element.getAttribute(checkboxDataPrivacy(), "label");
		return Element.getCheckBoxStatus(checkboxDataPrivacy());
//		if ((!status.isEmpty()) && status.equalsIgnoreCase("unchecked")) {
//			return false;
//		} else
//			return true;
	}

	public MobileElement errorTitle() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Login_lbl_errorTitle"));
	}

	public MobileElement errorDescription() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Login_lbl_errorDescription"));
	}

	public MobileElement errorDismiss() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Login_btn_errorDismiss"));
	}

	public String getErrorTitle() throws Exception {
		return errorTitle().getText();
	}

	public String getErrorDescription() throws Exception {
		return errorDescription().getText();
	}

	public boolean waitforDismiss() throws Exception {
		return Element.waitForElement(errorDismiss(), 15);
	}

	public void clickDismiss() throws Exception {
		errorDismiss().click();
	}

	public String getEULAtxt() throws Exception {
		return Eula().getText();
	}

	public String getPrivacytxt() throws Exception {
		return Privacy().getText();
	}

	public String getNextTxt() throws Exception {
		return signIn().getText();
	}

} // end of class
