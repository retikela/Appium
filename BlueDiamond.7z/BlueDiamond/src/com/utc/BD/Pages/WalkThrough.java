package com.utc.BD.Pages;

import com.appium.Common.Element;
import com.appium.Common.GenericFunctions;
import com.appium.Common.Gestures;
import com.appium.Common.ObjectMap;

import io.appium.java_client.MobileElement;

public class WalkThrough {
	Gestures gestures= new Gestures();
	
	//*****Renitas Edits
	/*private MobileElement skipBtn() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("WalkThrough_btn_Next"));
	}*/
	public MobileElement skipBtn() throws Exception {
		Element.waitforVisible("id", ObjectMap.getvalue("WalkthroughScreen_btn_skip"));
		return Element.findElementbyID(ObjectMap.getvalue("WalkthroughScreen_btn_skip"));
	}
	
	public boolean waitforSkipBtn() throws Exception {
		try {
			return Element.waitForElement(skipBtn(), 20);
		} catch (Exception e) {
			return false;
		}
	}

	public void clickSkipbtn() throws Exception {
		skipBtn().click();
	}
	public void clickDone() throws Exception {
		clickwalkthroughdemodone();
	}
	public MobileElement clickSkipBtn() throws Exception {
		return skipBtn();
	}
	// ****************************************************************************************************
	//verticalSwipe(MobileElement ele) git edit by renita
	private MobileElement walkthroughscreens() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Walkthrough_screens"));
	}
	public void swipewalkthroughscreen() throws Exception
	{
//			Element.swipeLeft(walkthroughscreens(), 90);
		gestures.scrollFromRightToLeftOfScreen();
	}
	
	
	private MobileElement homescreenwalkthrough() throws Exception {
		Element.waitforVisible("id", ObjectMap.getvalue("WalkThrough_lbl_homescreen"));
		return Element.findElementbyID(ObjectMap.getvalue("WalkThrough_lbl_homescreen"));
	}

	
	private MobileElement menuwalkthrough() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("WalkThrough_lbl_menu"));
	}


	private MobileElement readeroptionswalkthrough() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("WalkThrough_lbl_readeroptions"));
	}

	
	private MobileElement gestureswalkthrough() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("WalkThrough_lbl_gestures"));
	}

	

	private MobileElement pathwayswalkthrough() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("WalkThrough_lbl_pathways"));
	}


	private MobileElement twofactorauthenticationwalkthrough() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("WalkThrough_lbl_twofactorauthentication"));
	}

	private MobileElement walkthroughdeomdone() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("WalkThrough_btn_Done"));
	}
	
	
	  public String homescreenwalkthroughText() throws Exception{
		return homescreenwalkthrough().getText();
	}
	  
	  private MobileElement mapsandDirectionsText() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("WalkThrough_lbl_MapsAndDirections"));
		}

	  public String  mapsandDirectionswalkthrough() throws Exception{
		  String t=ObjectMap.getvalue("WalkThrough_lbl_MapsAndDirections");
		  String t2=mapsandDirectionsText().getText();;
			return mapsandDirectionsText().getText();
		}  

	public String menuwalkthroughText() throws Exception{
		return menuwalkthrough().getText();
	}
	
	public String readeroptionswalkthroughText() throws Exception{
		return readeroptionswalkthrough().getText();
	}
	
	public String gestureswalkthroughText() throws Exception{
		return gestureswalkthrough().getText();
	}
	
	
	public String pathwayswalkthroughText() throws Exception{
		return pathwayswalkthrough().getText();
	}
	public String twofactorauthenticationwalthroughText() throws Exception{
		return twofactorauthenticationwalkthrough().getText();
	}
	
	
	public void clickwalkthroughdemodone() throws Exception {
		walkthroughdeomdone().click();
	}
	
	public void clickwLearnMore() throws Exception {
		LearnMore().click();
	}
	
	private MobileElement LearnMore() throws Exception {
		Element.waitforVisible("id", ObjectMap.getvalue("WalkThrough_lbl_LearMore"));
		return Element.findElementbyID(ObjectMap.getvalue("WalkThrough_lbl_LearMore"));
	}
	
	
	

	private MobileElement HealthAndSafetyTrackText() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("WalkthroughScreen_lbl_Health&SafetyTrackingDescription"));
	}

	public String HealthAndSafetyTrackingwalkthroughText() throws Exception {
		return HealthAndSafetyTrackText().getText();
	}
	
	
	
	private MobileElement HealthAndSafetyTrackingHeaderText() throws Exception{
		Element.waitforVisible("id", ObjectMap.getvalue("WalkthroughScreen_lbl_Health&SafetyTracking"));
		return Element.findElementbyID(ObjectMap.getvalue("WalkthroughScreen_lbl_Health&SafetyTracking"));
	}
	
	public String HealthAndSafetyTrackingHeader() throws Exception {
		Element.waitForElement(HealthAndSafetyTrackingHeaderText());
		return HealthAndSafetyTrackingHeaderText().getText();
	}
	
	private MobileElement MapsAndDirectionsheader() throws Exception {
		Element.waitforVisible("id", ObjectMap.getvalue("WalkThrough_lbl_MapsAndDirectionsheader"));
		return Element.findElementbyID(ObjectMap.getvalue("WalkThrough_lbl_MapsAndDirectionsheader"));
	}

	public String MapsAndDirectionsHeaderText() throws Exception {
		Element.waitForElement(MapsAndDirectionsheader());
		return MapsAndDirectionsheader().getText();
	}
	
	private MobileElement menuheaderID() throws Exception {
		Element.waitforVisible("id", ObjectMap.getvalue("WalkThrough_lbl_menuheader"));
		return Element.findElementbyID(ObjectMap.getvalue("WalkThrough_lbl_menuheader"));
	}

	public String menuheader() throws Exception {
		 Element.waitForElement(menuheaderID());
		 return menuheaderID().getText();
	}


	private MobileElement readeroptionsheaderID() throws Exception {
		Element.waitforVisible("id", ObjectMap.getvalue("WalkThrough_lbl_readeroptionsheader"));
		return Element.findElementbyID(ObjectMap.getvalue("WalkThrough_lbl_readeroptionsheader"));
	}

	public String readeroptionsheader() throws Exception {
		Element.waitForElement(readeroptionsheaderID());
		return readeroptionsheaderID().getText();
	}
	
	private MobileElement gesturesheaderID() throws Exception {
		Element.waitforVisible("id", ObjectMap.getvalue("WalkThrough_lbl_gesturesheader"));
		return Element.findElementbyID(ObjectMap.getvalue("WalkThrough_lbl_gesturesheader"));
	}

	public String gesturesheader() throws Exception {
		 Element.waitForElement(gesturesheaderID());
		 return gesturesheaderID().getText();
	}

	private MobileElement pathwaysheaderID() throws Exception {
		Element.waitforVisible("id", ObjectMap.getvalue("WalkThrough_lbl_pathwaysheader"));
		return Element.findElementbyID(ObjectMap.getvalue("WalkThrough_lbl_pathwaysheader"));
	}

	public String pathwaysheader() throws Exception {
		 Element.waitForElement(pathwaysheaderID());
		 return pathwaysheaderID().getText();
	}
	
	private MobileElement twofactorauthenticationID() throws Exception {
		Element.waitforVisible("id", ObjectMap.getvalue("WalkThrough_lbl_twofactorauthenticationheader"));
		return Element.findElementbyID(ObjectMap.getvalue("WalkThrough_lbl_twofactorauthenticationheader"));
	}

	public String twofactorauthenticationheader() throws Exception {
		Element.waitForElement(twofactorauthenticationID());
		return twofactorauthenticationID().getText();
	}
	

	private MobileElement homescreenheaderID() throws Exception {
		Element.waitforVisible("id", ObjectMap.getvalue("WalkThrough_lbl_homescreen_header"));
		return Element.findElementbyID(ObjectMap.getvalue("WalkThrough_lbl_homescreen_header"));
	}

	public String homescreenheader() throws Exception {
		Element.waitForElement(homescreenheaderID());
		return homescreenheaderID().getText();
	}

	
	private MobileElement HelpBackBtn() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("WalkthroughScreen_lbl_Health&SafetyTracking"));
	}
	
	private MobileElement OKBtn() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("WalkThrough_btn_OK"));
	}
	
	public void clickOKBtn() throws Exception{
		OKBtn().click();
	}
	private MobileElement continueBluetoothBtn() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Bluetooth_btn_Continue"));
	}
	
	public void clickcontinueBluetoothBtn() throws Exception{
		if(GenericFunctions.isAndroid()) {
		continueBluetoothBtn().click();
		}
		else
		{
			System.out.println("continue with walkthrough");
		}
	}
	
	
	
	public void clickallowBluetoothBtn() throws Exception{

		if(GenericFunctions.isAndroid()) {
			
			allowBluetoothBtn();}
			else
			{
				System.out.println("continue with walkthrough");
			}
		}

	public void allowBluetoothBtn() throws Exception
	{
		Element.findElementbyClassIndex("android.widget.Button", 0).click();
	}

		
	private MobileElement continueBtn() throws Exception{
		Element.waitforVisible("id", ObjectMap.getvalue("Location_btn_Continue"));
		return Element.findElementbyID(ObjectMap.getvalue("Location_btn_Continue"));
	}
	
	public void clickcontinueBtn() throws Exception{
		continueBtn().click();
	}
	
	public MobileElement imgToggle() throws Exception {
        return Element.findElementbyID(ObjectMap.getvalue("optin_img_toggle"));
	}
	
	private MobileElement continueLocationBtn() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Location_btn_continue"));
	}
	public void toggleLocation() throws Exception
	{
		if(GenericFunctions.isAndroid()) {
		imgToggle().click();
		continueLocationBtn().click();
		Thread.sleep(1000);
		locationAllow();
		}
		else
		{
			clickcontinueBtn();
		}
	}
	
	public void locationAllow() throws Exception
	{
		Element.findElementbyClassIndex("android.widget.Button", 0).click();
	}
	
	public boolean locationScreen() throws Exception
	{
		try {
			return Element.waitforVisible("id", ObjectMap.getvalue("location_txt_LocationTitle"), 10);
		} catch (Exception e) {
			return false;
		}
	}
}
