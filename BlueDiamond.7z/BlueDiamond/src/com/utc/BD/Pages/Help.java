package com.utc.BD.Pages;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.openqa.selenium.support.PageFactory;

import com.appium.Common.Element;
import com.appium.Common.GenericFunctions;
import com.appium.Common.ObjectMap;
import com.appium.Common.AppiumSetup;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class Help {
	
	public Help(AppiumDriver<?> driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	@AndroidFindBy(id = "headerTitle")
	 @iOSXCUITFindBy(accessibility = "Help-title-label")
	MobileElement header;
	
//	private MobileElement header() throws Exception{
//		return Element.findElementbyID(ObjectMap.getvalue("Help_Navbar_Header"));
//	}
	
	public boolean waitforHelpHeader() throws Exception {
		System.out.println(header.getText());
		return Element.waitForElement(header);
	}
	
	private MobileElement backButton() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Help_btn_Back"));
	}
	
	public void clickBack() throws Exception{
		backButton().click();
	}
	
	public String getHelpText() throws Exception{
		List<MobileElement>labels = AppiumSetup.driver.findElementsByClassName(GenericFunctions.getInstance().getLableClass());
		 StringBuilder sb = new StringBuilder();
		 Pattern p = Pattern.compile("[^A-Za-z0-9]");
		 Matcher m;
		for (int i=1;i<labels.size();i++){
			 m = p.matcher(labels.get(i).getAttribute("name").substring(0,1));
			if(m.find()){
				sb.deleteCharAt(sb.length()-1);	
			}
			sb.append(labels.get(i).getAttribute("name")+" ");
		}
		return sb.toString().trim();
	}
	
	public String extractText(Reader reader) throws IOException {
	    StringBuilder sb = new StringBuilder();
	    BufferedReader br = new BufferedReader(reader);
	    String line;
	    for (int i=0;(line=br.readLine()) != null;i++){
	    	if(i>3){
	    	 sb.append(line);
	    	}
	    }
//	    while ( (line=br.readLine()) != null) {
//	      sb.append(line);
//	    }
	    String textOnly = Jsoup.parse(sb.toString()).text();
	    return textOnly;
	  }
	
}
