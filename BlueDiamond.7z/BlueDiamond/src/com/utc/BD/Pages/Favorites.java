package com.utc.BD.Pages;

import java.util.ArrayList;
import java.util.List;

import com.appium.Common.Element;
import com.appium.Common.GenericFunctions;
import com.appium.Common.ObjectMap;

import io.appium.java_client.MobileElement;

public class Favorites {
	private MobileElement header() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Favorites_lbl_Title"));
	}
	
	public boolean waitforFavoritePageHeader() throws Exception {
		return Element.waitForElement(header());
	}
	
	public String getHeaderText() throws Exception {
		return Element.getElementText(header());
		
	}
	
	private MobileElement backButton() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Favorites_btn_Back"));
	}
	
	public void clickBack() throws Exception{
		backButton().click();
	}
	
	public List<MobileElement> getDeleteIconList() throws Exception{
		List<MobileElement> DeleteIcons;
		DeleteIcons = Element.findElementsbyID(ObjectMap.getvalue("Favorites_btn_deleteIcon"));
		return DeleteIcons;
		
	}
	
	public List<MobileElement> getFavoriteReaderList() throws Exception{
		List<MobileElement> readers;
		readers = Element.findElementsbyID(ObjectMap.getvalue("Favorites_lbl_ReaderNames"));
		return readers;
	}
	
	
	public List<String> Favoritereaders = new ArrayList<String>();
	public List<String> getFavoriteReaders() throws Exception{
		Favoritereaders.clear();
		for (MobileElement reader : getFavoriteReaderList()) {
			Favoritereaders.add(reader.getText().trim());
		}
		return Favoritereaders;
	}
	
	public void DeleteAllReaders() throws Exception{
		List<MobileElement> readers = getDeleteIconList();
//		for (MobileElement mobileElement : readers) {
//			readers.get(0).click();
//		}
		for (int i=0;i<readers.size();i++)
		{
//			readers.get(i).click();
			getDeleteIconList().get(0).click();
			new ReadersList().acceptRemoveReader();
			
		}
	}

}
