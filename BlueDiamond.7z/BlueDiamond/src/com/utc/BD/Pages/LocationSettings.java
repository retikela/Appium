package com.utc.BD.Pages;

import org.testng.Reporter;

import com.appium.Common.Element;
import com.appium.Common.GenericFunctions;
import com.appium.Common.ObjectMap;

import io.appium.java_client.MobileElement;

public class LocationSettings {
	
	public MobileElement header() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("location_lbl_title"));
	}
	
	public MobileElement showMaps() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("location_lyout_showMaps"));

	}
	
	public MobileElement backGroundServicesToggle() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("location_lyout_background"));
	}
	
	public MobileElement location() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("location_lyout_location"));
	}
	
	public MobileElement checkBoxLiveNavigation() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("location_chckbox_live"));
	}
	
	public MobileElement backGroundServices() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("location_chckbox_bgServices"));
	}
	
	public MobileElement geoFences() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("location_chckbox_geoFence"));
	}
	
	public MobileElement backButton() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("location_btn_back"));
	}
	
	
	public String getPageTitle() throws Exception {
		return header().getText();
	}
	
	public void clickShowMaps() throws Exception {
		showMaps().click();
		Reporter.log("Clicked on Show Maps toggle button");
		Thread.sleep(1000);
	}
	
	public void clickBack() throws Exception {
		backButton().click();
		Reporter.log("Clicked on back button");
		Thread.sleep(1000);
	}
	
	public void clickLiveNavigation() throws Exception {
		
		checkBoxLiveNavigation().click();
		Thread.sleep(1000);
		Reporter.log("Clicked on Live Navigation check box");
	}
	
}
