package com.utc.BD.Pages;

import java.util.ArrayList;
import java.util.List;

import com.appium.Common.Element;
import com.appium.Common.GenericFunctions;
import com.appium.Common.ObjectMap;

import io.appium.java_client.MobileElement;

public class ManagePathway {

	private MobileElement header() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("ManagePathway-lbl-PathwayHeader"));
	}
	
	public boolean waitforManagePathwayTitle() throws Exception {
		try {
			return Element.waitForElement(header(), 3);
		} catch (Exception e) {
			return false;
		}
	}
	
	public String getHeaderText() throws Exception {
		return Element.getElementText(header());
		
	}
	
	private MobileElement backClose() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("ManagePathway-btn-Cancel"));
	}
	
	public void clickClose() throws Exception{
		backClose().click();
	}
	
	private MobileElement btnManagePathway() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("ManagePathway-btn-Manage"));
	}
	
	public void clickbtnManagePathway() throws Exception{
		if(waitforManagePathwayTitle())
		btnManagePathway().click();
	}
	
	public String getbtnManagePathwayText() throws Exception {
		return Element.getElementText(btnManagePathway());
		
	}
	
	
	private MobileElement btnCreatePathway() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("ManagePathway-btn-Create"));
	}
	
	public void clickbtnCreatePathway() throws Exception{
		if(waitforManagePathwayTitle())
		btnCreatePathway().click();
	}
	
	public String getbtnCreatePathwayText() throws Exception {
		return Element.getElementText(btnCreatePathway());
	}
	
	private MobileElement lblRunPathway() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("ManagePathway-lbl-RunPathway"));
	}
	
	public String getlblRunPathwayText() throws Exception {
		return Element.getElementText(lblRunPathway());
		
	}
	
	private List<MobileElement> lblPathwayNames() throws Exception{
		return Element.findElementsbyID(ObjectMap.getvalue("ManagePathway-lbl-PathwayName"));
	}
	
	private List<String> pathwayNames = new ArrayList<String>();
	public List<String> getPathwayNames() throws Exception {
		pathwayNames.clear();
		for (MobileElement pathway : lblPathwayNames()) {
			pathwayNames.add(Element.getElementText(pathway));
		}
		System.out.println("Pathway Names : "+pathwayNames);
		return pathwayNames;
	}

	public void clickPathway(String name) throws Exception {
		lblPathwayNames().get(getPathwayNames().indexOf(name)).click();
	}
	
}
