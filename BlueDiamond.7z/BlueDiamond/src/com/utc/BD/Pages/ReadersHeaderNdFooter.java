package com.utc.BD.Pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;

import com.appium.Common.Configure;
import com.appium.Common.Element;
import com.appium.Common.GenericFunctions;
import com.appium.Common.Gestures;

import groovyjarjarantlr4.v4.parse.ANTLRParser.element_return;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class ReadersHeaderNdFooter {
	Configure config = new Configure();
	private static ReadersHeaderNdFooter instance;

	public static ReadersHeaderNdFooter getInstance(AppiumDriver<?> driver) {
		instance = new ReadersHeaderNdFooter(driver);
		return instance;
	}
	
	protected ReadersHeaderNdFooter(AppiumDriver<?> driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	@AndroidFindBy(id = "dropdown_normalview_textview")
	@iOSXCUITFindBy(accessibility = "dropDownTitleLabel")
	MobileElement viewsDropdown;
	
	public boolean waitforviewsDropdown() throws Exception {
		return Element.waitForElement(viewsDropdown);
	}
	
	public String getviewsDropdownText() throws Exception {
		return Element.getElementText(viewsDropdown);
		
	}
	
	public void clickViewsDropdown() throws Exception {
		viewsDropdown.click();		
	}
	
	
	@AndroidFindBy(id = "dropdown_item_textview")
	@iOSXCUITFindBy(accessibility = "dropDownListLabel")
	List<MobileElement> viewsDropdownlist;
	
//	Returns views text
	public List<String> getviewsDropdownvalues() throws Exception {
		List<String> dropdownValues = new ArrayList<>();
		 for (MobileElement mobileElement : viewsDropdownlist) {
			 dropdownValues.add(Element.getElementText(mobileElement));
		 }
		System.out.println("dorp down values" + dropdownValues);
		return dropdownValues;
		
	}
	
	public void clickviewsDropdownvalue(String val) throws Exception {
		int i = getviewsDropdownvalues().indexOf(val);
		System.out.println(i);
		if(i>-1) {
			viewsDropdownlist.get(i).click();
			Reporter.log("clicked value "+val+" from drop down");
		}else {
			Reporter.log("Value "+val+" is not available in drop down");
		}
	}
//		for (MobileElement mobileElement : viewsDropdownlist) {
//			 if(Element.getElementText(mobileElement).equalsIgnoreCase(val)){
//			 mobileElement.click();
//			 Reporter.log("clicked value "+val+" from drop down");
//			 return;
//			 }
//		 }
//		Reporter.log("Value "+val+" is not available in drop down");
//	}
	
	@AndroidFindBy(id = "refreshIcon")
	@iOSXCUITFindBy(accessibility = "dropDownHeaderRightButton")
	MobileElement headerRightbtn;
	
	
	public void clickRightbtn() throws Exception{
		headerRightbtn.click();
		Reporter.log("clicked header right button");
	}
	
	public String getRightbtntxt() throws Exception{
		if(config.isAndroid() )
			return headerRightbtn.getAttribute("content-desc");
		else
		return headerRightbtn.getText();
	}
	
	
	
	
	
	@AndroidFindBy(xpath = "//*[@contentDescription='About']")
	@iOSXCUITFindBy(accessibility = "dropDownHeaderLeftButton")
	MobileElement headerLeftbtn;
	
	
	public void clickMenubtn() throws Exception{
		headerLeftbtn.click();
		Reporter.log("clicked menu icon");
	}
	
	@AndroidFindBy(id = "dropdown_item_imageview")
	@iOSXCUITFindBy(accessibility = "dropDownCheckMark")
	List<MobileElement> listCheckIcon;
	
	public Boolean isviewSelected(String val) throws Exception{
		int i = getviewsDropdownvalues().indexOf(val);
		if(i>-1) {
			if(listCheckIcon.get(i).getAttribute("value").equalsIgnoreCase("Checked"))
			Reporter.log("value "+val+" is selected in drop down");
			return true;
		}else {
			Reporter.log("Value "+val+" is not selected in drop down");
			return false;
		}
	}

	public String getPopupText() throws Exception {
		return GenericFunctions.getAlertMsg();
	}
	
	public String getPopupTitle() throws Exception {
		return GenericFunctions.getAlertTitleMessage();
	}
	
	public String getPopupDeletetxt() throws Exception {
		return GenericFunctions.getAcceptAlertText();
	}
	
	public String getPopupCanceltxt() throws Exception {
		return GenericFunctions.getCancelAlertText();
	}
	
	public void selectDeleteinPopup() throws Exception {
		 GenericFunctions.acceptAlert();
	}
	
	@AndroidFindBy(id = "tv_lockstatus")
	@iOSXCUITFindBy(accessibility = "Footer_status_label")
	MobileElement FooterStatus;
	
	
	public String getFooterStatus() throws Exception{
		return FooterStatus.getText();
	}
	
	public void clickUnlock() {
		FooterStatus.click();
		Reporter.log("clicked on Footer status ");
	}
	
	@AndroidFindBy(id = "tv_readername")
	@iOSXCUITFindBy(accessibility = "Footer_reader_name_label")
	MobileElement Nickname;
	
	
	public String getReaderNickname() throws Exception{
		return Nickname.getText();
	}

	@AndroidFindBy(id = "tv_nick_name")
	@iOSXCUITFindBy(accessibility = "Footer_reader_description_label")
	MobileElement SeverReaderName;
	
	
	public String getOriginalReadername() throws Exception{
		return SeverReaderName.getText();
	}
	
	@AndroidFindBy(id = "tv_lockstatus")
	@iOSXCUITFindBy(accessibility = "Footer_pathway_start_label")
	MobileElement FooterPathwayStatus;
	
	
	public String getFooterPathwayStatus() throws Exception{
		return FooterPathwayStatus.getText();
	}
	
	public void clickStartpathway() {
		FooterPathwayStatus.click();
		Reporter.log("clicked on Footer tap to satrt ");
	}
	
	@AndroidFindBy(id = "tv_readername")
	@iOSXCUITFindBy(accessibility = "Footer_pathway_name_label")
	MobileElement pathwayName;
	
	
	public String getpathwayName() throws Exception{
		return pathwayName.getText();
	}

	@AndroidFindBy(id = "tv_nick_name")
	@iOSXCUITFindBy(accessibility = "Footer_pathway_description_label")
	MobileElement startingReaderName;
	
	
	public String getstartingReaderName() throws Exception{
		return startingReaderName.getText();
	}
	
	
	
	@AndroidFindBy(id = "lockedReaderImageButton")
	@iOSXCUITFindBy(accessibility = "Doors-doorlockicon-button")
	MobileElement footerDaimondimg;
	
	public String getfooterDaimondimgText() {
		if(config.isAndroid())
			return footerDaimondimg.getAttribute("contentDescription");
		else
			return footerDaimondimg.getText();
				
	}
	
	public boolean isUnlockimgDisplayed() {
		if(getfooterDaimondimgText().equalsIgnoreCase("reader locked"))
			return true;
		else 
			return false;
	}
	
	public boolean isPathwayimgDisplayed() {
		if(getfooterDaimondimgText().equalsIgnoreCase("pathway start icon"))
			return true;
		else 
			return false;
	}
	
	@AndroidFindBy(id = "layout_dot")
	@iOSXCUITFindBy(accessibility = "Footer_page_control")
	MobileElement footerDottedimg;
	
	public boolean isDottedimgDisplayed() {
		return Element.isEnabled(footerDottedimg);
	}
	
	
	@AndroidFindBy(id = "layout_dot")
	@iOSXCUITFindBy(xpath = "//*[@class='UIAScrollView']")
	MobileElement footerView;
	
	public void Swipefooter() throws Exception {
		new Gestures().swipeFromRightToLeft(footerView, 90);
	}
	
	
	
	
}
