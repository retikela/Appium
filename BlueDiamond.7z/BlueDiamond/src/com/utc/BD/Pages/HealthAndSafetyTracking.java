package com.utc.BD.Pages;

import com.appium.Common.Element;
import com.appium.Common.ObjectMap;

import io.appium.java_client.MobileElement;

public class HealthAndSafetyTracking {
	
	private MobileElement SocialDistancingChbx() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("optOut_cbx_SocialDistancing"));
	}
	
	public void clickSocialDistancingChbx() throws Exception{
		SocialDistancingChbx().click();
	}
	
	private MobileElement SelfAssessmentChbx() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("optOut_cbx_SelfAssessment"));
	}
	
	public void clickSelfAssessmentChbx() throws Exception{
		SelfAssessmentChbx().click();
	}
	
	private MobileElement SaveBtn() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("optOut_btn_Save"));
	}
	
	public void clickSaveBtn() throws Exception{
		SaveBtn().click();
	}
	
	private MobileElement continueBtn() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("optOut_btn_Continue"));
	}
	
	public void clickcontinueBtn() throws Exception{
		continueBtn().click();
	}
	
	private MobileElement AsseentrequiredPopup() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("optOut_Asseentrequired"));
	}
	
	private MobileElement AsseentrequiredDescription() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("optOut_AsseentrequiredDescription"));
	}
	private MobileElement AsseentrequiredOk() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("optOut_btn-AsseentrequiredOk"));
	}
	public void clickAsseentrequired() throws Exception{
		AsseentrequiredOk().click();
	}
	
	
	
}
