package com.utc.BD.Pages;

import java.util.ArrayList;
import java.util.List;

import com.appium.Common.Element;
import com.appium.Common.GenericFunctions;
import com.appium.Common.ObjectMap;

import io.appium.java_client.MobileElement;

public class CreatePathway {
	private MobileElement btnSave() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("CreatePathway-btn-Save"));
	}

	public void clickbtnSave() throws Exception {
		btnSave().click();
	}

	public String getbtnSaveText() throws Exception {
		return Element.getElementText(btnSave());

	}
	
	private MobileElement btnAddMoreReaders() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("CreatePathway-lbl-AddMoreReader"));
	}

	public void clickbtnAddMoreReaders() throws Exception {
		btnAddMoreReaders().click();
	}

	public String getbtnAddMoreReadersText() throws Exception {
		return Element.getElementText(btnAddMoreReaders());

	}

	public boolean waitforbtnSave() throws Exception {
		return Element.waitForElement(btnSave());
	}
	
	public boolean isbtnSaveEnabled() throws Exception {
		return Element.isEnabled(btnSave());
	}
	
	private MobileElement btnCleartext() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("CreatePathway-btn-cleartext"));
	}

	public void clickbtnCleartext() {
		try {
		btnCleartext().click();
		}catch (Exception e){
			
		}
	}

	public boolean isbtnCleartextVisible() throws Exception {
		return Element.isVisible(btnCleartext());
	}

	private MobileElement backClose() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("CreatePathway-btn-close"));
	}

	public void clickClose() throws Exception {
		backClose().click();
	}

	private MobileElement lblPathway() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("CreatePathway-lbl-pathway"));
	}

	public String getlblPathwayText() throws Exception {
		return Element.getElementText(lblPathway());

	}

	public boolean waitforPathway() throws Exception {
		return Element.waitForElement(lblPathway());
	}
	
	private MobileElement tbxPathwayName() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("CreatePathway-txtView-PathwayName"));
	}
	
	public void enterPathwayName(String name) throws Exception {
		tbxPathwayName().click();
		clickbtnCleartext();
		tbxPathwayName().clear();
		tbxPathwayName().sendKeys(name);
		Thread.sleep(600);
		GenericFunctions.pressBack();
		Thread.sleep(600);
	}
	
	public String getPathwayName() throws Exception {
		return Element.getElementText(tbxPathwayName());
	}
	
	
	private MobileElement lblpathTime() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("CreatePathway-lbl-pathTime"));
	}

	public String getlblpathTimeText() throws Exception {
		return Element.getElementText(lblpathTime());
	}

	private MobileElement lblPathTimerValue() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("CreatePathway-lbl-pathTimer"));
	}


	public String getlblPathTimerValueText() throws Exception {
		return Element.getElementText(lblPathTimerValue());

	}
	
	private MobileElement imgtimePickerDownArrow() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("CreatePathway-img-timePicker"));
	}
	
	public void clickPickerDownArrow() throws Exception {
		imgtimePickerDownArrow().click();
	}
	
	public void setTime(String value) throws Exception {
		clickPickerDownArrow();
		Element.selectFromListBox(value);
	}
	
	private MobileElement lblsetLocation() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("CreatePathway-lbl-setLocation"));
	}

	public String getlblsetLocationText() throws Exception {
		return Element.getElementText(lblsetLocation());
	}
	
	private MobileElement imgsetLocationicon() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("CreatePathway-img-setLocationCheck"));
	}
	
	public boolean isSetLocationiconVisible() throws Exception {
		return Element.isVisible(imgsetLocationicon());
	}
	
	private MobileElement imgMapClear() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("CreatePathway-img-MapClear"));
	}
	
	public void clickMapClearicon() throws Exception {
		imgMapClear().click();
	}
	
	public boolean isMapCleariconVisible() throws Exception {
		return Element.isVisible(imgMapClear());
	}
	
	private List<MobileElement> imgDeleteReader() throws Exception {
		return Element.findElementsbyID(ObjectMap.getvalue("CreatePathway-img-DeleteReader"));
	}
	
	public void clickDeleteReadericon(int position) throws Exception {
		imgDeleteReader().get(position).click();
	}
	
	

	public List<MobileElement> getlblPathwayReaders() throws Exception {
		return Element.findElementsbyID(ObjectMap.getvalue("CreatePathway-lbl-ReaderName"));
	}


	public List<String> PathwayReaders = new ArrayList<String>();

	public List<String> getPathwayReaderNames() throws Exception {
		PathwayReaders.clear();
		for (MobileElement reader : getlblPathwayReaders()) {
			PathwayReaders.add(reader.getText().trim());
		}
		System.out.println(PathwayReaders);
		return PathwayReaders;
	}


	public void deleteReaderfromPathway(String string) throws Exception {
		int pathReaderPosition = getPathwayReaderNames().indexOf(string);
		clickDeleteReadericon(pathReaderPosition);
	}

	public boolean VerifyPathwayReaderList(String reader) throws Exception {
		if (getPathwayReaderNames().contains(reader)) {
			return true;
		} else
			return false;
	}

	public boolean verifyOrderOfReaders(List<String> DragNdDropList) throws Exception {
		System.out.println("Drag and drop screen readers"+DragNdDropList);
		System.out.println("create pathway screen readers"+getPathwayReaderNames());
		return DragNdDropList.equals(getPathwayReaderNames());
	}

}
