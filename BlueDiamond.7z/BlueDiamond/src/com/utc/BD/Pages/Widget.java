package com.utc.BD.Pages;

import java.util.ArrayList;
import java.util.List;

import com.appium.Common.Configure;
import com.appium.Common.Element;
import com.appium.Common.GenericFunctions;
import com.appium.Common.ObjectMap;

import io.appium.java_client.MobileElement;

public class Widget {

	Configure config = new Configure();

	public void clickWidgetEdit() throws Exception {
		GenericFunctions.btnWidgetEdit().click();
	}

	public boolean waitForAddWidgest() throws Exception {
		return Element.waitForElement(GenericFunctions.lblAddWidgets());
	}

	private MobileElement addWidgetAppName() throws Exception {
		return Element.findElementbyXpath("//XCUIElementTypeCell[@name=\"BlueDiamond\"]");
	}

	private MobileElement btnAddApp() throws Exception {
		return Element.findElementbyID("Insert BlueDiamond");
	}

	public void clickbtnAddApp() throws Exception {
		if (Element.isEnabled(addWidgetAppName()))
			btnAddApp().click();
	}

	public void clickAddWidgestDone() throws Exception {
		GenericFunctions.btnAddWidgestDone().click();
	}

	private MobileElement addedWidgetAppName() throws Exception {
		return Element.findElementbyID("BLUEDIAMOND");
	}

	private MobileElement btnShowLess() throws Exception {
		if (GenericFunctions.isAndroid())
			return Element.findElementbyID(ObjectMap.getvalue("Widget-btn-Show"));
		else if (Integer.parseInt(config.getMobileOSVersion()) < 14)
			return Element.findElementbyID("Show Less");
		else
			return Element.findElementbyXpath("//*[@class='UIAView']/*[@text='Show Less']");
	}

	public boolean isBDWidgetAvailable() throws Exception {
		return Element.waitForElement(addedWidgetAppName());
	}

	public void clickShowLess() throws Exception {
		if (GenericFunctions.isAndroid()) {
			if (btnShowLess().getText().equalsIgnoreCase("Show Less")) 
				btnShowLess().click();
			} else {
				try {
					if (Element.isEnabled(btnShowLess())) {
						btnShowLess().click();
					}
				} catch (Exception e) {
				}
			}
	}

	private MobileElement btnShowMore() throws Exception {
		if (GenericFunctions.isAndroid())
			return Element.findElementbyID(ObjectMap.getvalue("Widget-btn-Show"));
		else if (Integer.parseInt(config.getMobileOSVersion()) < 14)
			return Element.findElementbyID("Show More");
		else
			return Element.findElementbyXpath("//*[@class='UIAView']/*[@text='Show More']");
	}

	private boolean isBlueDiamondWidgetAvailable() {
		return false;
	}

	public void clickShowMore() {
		try {
			if (GenericFunctions.isAndroid()) {
				lblHint().click();
				Thread.sleep(5000);
				System.out.println("is show more enabled? : " + Element.isEnabled(btnShowMore()));
				if (btnShowMore().getText().equalsIgnoreCase("Show More"))
					btnShowMore().click();
			} else if (Element.isEnabled(btnShowMore())) {
				btnShowMore().click();
			}
		} catch (Exception e) {
		}
	}

	private MobileElement imgArrow() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Widget_ShowLess-img-Arrow"));
	}

	public boolean isimgArrowDisplayed() throws Exception {
		return Element.isEnabled(imgArrow());
	}

	private List<MobileElement> getFavoriteReadersList() throws Exception {
		return Element.findElementsbyID(ObjectMap.getvalue("Widget_ShowMore-lbl-ReaderName"));
	}

	public List<String> getFavoriteReaders() throws Exception {
		List<String> favoritereaders = new ArrayList<>();
		favoritereaders.clear();
		List<MobileElement> favReadersElements = getFavoriteReadersList();
		for (int i = 0; i < favReadersElements.size(); i++) {
			favoritereaders.add(favReadersElements.get(i).getText());
		}
		System.out.println("Favorite readers" + favoritereaders);
		return favoritereaders;

	}

	public void clickReader(String reader) throws Exception {
//		Thread.sleep(5000);
		clickReader(getFavoriteReadersList().get(getFavoriteReaders().indexOf(reader)));
	}

	public void clickReader(MobileElement reader) {
		reader.click();
	}

	private List<MobileElement> getPathwaysList() throws Exception {
		return Element.findElementsbyID(ObjectMap.getvalue("Widget_ShowMore-lbl-PathwayName"));
	}

	public List<String> getPathways() throws Exception {
		List<String> Pathways = new ArrayList<>();
		Pathways.clear();
		List<MobileElement> pathways = getPathwaysList();
		for (int i = 0; i < pathways.size(); i++) {
			Pathways.add(pathways.get(i).getText());
		}
		System.out.println("Pathways" + Pathways);
		return Pathways;

	}

	public void clickPathway(String Pathway) throws Exception {
		clickPathway(getPathwaysList().get(getPathways().indexOf(Pathway)));
	}

	public void clickPathway(MobileElement Pathway) {
		Pathway.click();
	}

	private MobileElement lblEmptyPathways() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Widget_ShowMore-lbl-PathwaysEmpty"));
	}

	public String getEmptyPathwaysText() throws Exception {
		return Element.getElementText(lblEmptyPathways());
	}

	public boolean waitForlblEmptyPathways() throws Exception {
		try {
			return Element.isEnabled(lblEmptyPathways());
		} catch (Exception e) {
			return false;
		}
	}

	private MobileElement lblEmptyReaders() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Widget_ShowMore-lbl-ReadersEmpty"));
	}

	public String getEmptyReadersText() throws Exception {
		return Element.getElementText(lblEmptyReaders());
	}

	private MobileElement lblNearby() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Widget-lbl-Nearby"));
	}

	public String getNearbyText() throws Exception {
		return Element.getElementText(lblNearby());
	}

	public void clickNearby() throws Exception {
		lblNearby().click();
		Thread.sleep(2000);
	}

	private MobileElement lblPathways() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Widget-lbl-Pathways"));
	}

	public String getPathwaysText() throws Exception {
		return Element.getElementText(lblPathways());
	}

	public void clickPathways() throws Exception {
		lblPathways().click();
	}

	private MobileElement lblHint() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Widget-lbl-Hint"));
	}

	public String getHintText() throws Exception {
		return Element.getElementText(lblHint());
	}

	private MobileElement imgBluetooth() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Widget_ShowMore-img-Bluetooth"));
	}

	public boolean isimgBluetoothDisplayed() throws Exception {
		return Element.isEnabled(imgBluetooth());
	}

	private MobileElement lblNoBluetooth() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Widget_ShowMore-lbl-NoBluetooth"));
	}

	public String getNoBluetoothText() throws Exception {
		return Element.getElementText(lblNoBluetooth());
	}

	private MobileElement lblGoToSettingsMsg() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Widget_ShowMore-lbl-GoToSettingsMsg"));
	}

	public String getGoToSettingsMsgText() throws Exception {
		return Element.getElementText(lblGoToSettingsMsg());
	}

	private MobileElement lblNoBluetoothMsg() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Widget_ShowMore-lbl-NoBluetoothMsg"));
	}

	public String getNoBluetoothMsgText() throws Exception {
		return Element.getElementText(lblNoBluetoothMsg());
	}

	private MobileElement lblGoToSettingsBtn() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Widget_ShowMore-lbl-GoToSettingsBtn"));
	}

	public String getGoToSettingsBtnText() throws Exception {
		return Element.getElementText(lblGoToSettingsBtn());
	}

	public void clickGoToSettingsBtn() throws Exception {
		lblGoToSettingsBtn().click();
	}

	private MobileElement imgGoToSettingsBtn() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Widget_ShowMore-img-GoToSettingsBtn"));
	}

	public boolean isimgGoToSettingsDisplayed() throws Exception {
		return Element.isEnabled(imgGoToSettingsBtn());
	}

}
