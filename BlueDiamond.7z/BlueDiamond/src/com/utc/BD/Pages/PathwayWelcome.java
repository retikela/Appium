package com.utc.BD.Pages;

import com.appium.Common.Element;
import com.appium.Common.ObjectMap;

import io.appium.java_client.MobileElement;

public class PathwayWelcome {
	private MobileElement header() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("WelcomePathway_lbl_welcomeTitle"));
	}
	
	public boolean waitforPathwayWelcomeTitle() throws Exception {
		try {
			return Element.waitForElement(header(), 3);
		} catch (Exception e) {
			return false;
		}
	}
	
	public String getHeaderText() throws Exception {
		return Element.getElementText(header());
		
	}
	
	private MobileElement backClose() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("WelcomePathway_btn_Close"));
	}
	
	public void clickClose() throws Exception{
		backClose().click();
	}
	
	private MobileElement btnEnableNotifications() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("WelcomePathway_btn_EnableNotifications"));
	}
	
	public void clickbtnEnableNotifications() throws Exception{
		btnEnableNotifications().click();
	}
	
	public String getbtnEnableNotificationsText() throws Exception {
		return Element.getElementText(btnEnableNotifications());
		
	}
	
	
	private MobileElement btnEnableLocationServices() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("WelcomePathway_btn_EnableLocationServices"));
	}
	
	public void clickbtnEnableLocationServices() throws Exception{
		btnEnableLocationServices().click();
	}
	
	public String getbtnEnableLocationServicesText() throws Exception {
		return Element.getElementText(btnEnableLocationServices());
	}
	
	private MobileElement btnGetStarted() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("WelcomePathway_btn_GetStarted"));
	}
	
	public void clickbtnGetStarted() throws Exception{
		if(waitforPathwayWelcomeTitle())
		btnGetStarted().click();
	}
	
	public String getbtnGetStartedText() throws Exception {
		return Element.getElementText(btnGetStarted());
		
	}
	
	
}
