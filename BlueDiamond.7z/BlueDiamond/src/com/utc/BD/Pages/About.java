package com.utc.BD.Pages;

import org.openqa.selenium.support.PageFactory;

import com.appium.Common.Element;
import com.appium.Common.ObjectMap;
import com.appium.Common.SiriCommand;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class About {
	public About(AppiumDriver<?> driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	@AndroidFindBy(id = "About-title-label")
	@iOSXCUITFindBy(accessibility = "About-title-label")
	MobileElement header;
//	private MobileElement header() throws Exception{
//		return Element.findElementbyID(ObjectMap.getvalue("About_Navbar_Header"));
//	}
	
	public boolean waitforAboutHeader() throws Exception {
		return Element.waitForElement(header);
	}
	
	public String getHeaderTxt() throws Exception{
		return header.getText();
	}
	
//	private MobileElement backButton() throws Exception{
//		return Element.findElementbyID(ObjectMap.getvalue("About_btn_Back"));
//	}
	
	@AndroidFindBy(id = "About-back-button")
	@iOSXCUITFindBy(accessibility = "About-back-button")
	MobileElement backButton;
	
	public void clickBack() throws Exception{
		backButton.click();
	}
	
//	private MobileElement lblCopyrights() throws Exception{
//		return Element.findElementbyID(ObjectMap.getvalue("About_lbl_copyrights"));
//	}
	
	@AndroidFindBy(id = "About-copyrights-label")
	@iOSXCUITFindBy(accessibility = "About-copyrights-label")
	MobileElement lblCopyrights;
	
	public String getCopyrightsTxt() throws Exception{
		return lblCopyrights.getText();
	}
	
//	private MobileElement lblDiagnostics() throws Exception{
//		return Element.findElementbyID(ObjectMap.getvalue("About_lbl_Diagnostics"));
//	}
	
	@AndroidFindBy(id = "diagnostics-titlle-label")
	@iOSXCUITFindBy(accessibility = "diagnostics-titlle-label")
	MobileElement lblDiagnostics;
	
	public String getDiagnosticsTxt() throws Exception{
		return lblDiagnostics.getText();
	}
	
//	private MobileElement lblVersion() throws Exception{
//		return Element.findElementbyID(ObjectMap.getvalue("About_lbl_version"));
//	}
	
	@AndroidFindBy(id = "diagnostics-version-label")
	@iOSXCUITFindBy(accessibility = "diagnostics-version-label")
	MobileElement lblVersion;
	
	public String getVersionTxt() throws Exception{
		return lblVersion.getText();
	}
	
//	private MobileElement lblVersionValue() throws Exception{
//		return Element.findElementbyID(ObjectMap.getvalue("About_lbl_versionValue"));
//	}
	
	@AndroidFindBy(id = "diagnostics-version-field")
	@iOSXCUITFindBy(accessibility = "diagnostics-version-field")
	MobileElement lblVersionValue;
	
	public String getVersionValueTxt() throws Exception{
		return lblVersionValue.getText();
	}
	
//	private MobileElement lblFrameworkVersion() throws Exception{
//		return Element.findElementbyID(ObjectMap.getvalue("About_lbl_frameworkVersion"));
//	}
	
	@AndroidFindBy(id = "diagnostics-framework-label")
	@iOSXCUITFindBy(accessibility = "diagnostics-framework-label")
	MobileElement lblFrameworkVersion;
	
	public String getFrameworkVersionTxt() throws Exception{
		return lblFrameworkVersion.getText();
	}
	
//	private MobileElement lblFrameworkVersionVal() throws Exception{
//		return Element.findElementbyID(ObjectMap.getvalue("About_lbl_frameworkVersionVal"));
//	}
	
	@AndroidFindBy(id = "diagnostics-framework-field")
	@iOSXCUITFindBy(accessibility = "diagnostics-framework-field")
	MobileElement lblFrameworkVersionVal;
	
	public String getFrameworkVersionValTxt() throws Exception{
		return lblFrameworkVersionVal.getText();
	}
	
//	private MobileElement lblSerialNumber() throws Exception{
//		return Element.findElementbyID(ObjectMap.getvalue("About_lbl_serialNumber"));
//	}
	
	@AndroidFindBy(id = "diagnostics-serialno-label")
	@iOSXCUITFindBy(accessibility = "diagnostics-serialno-label")
	MobileElement lblSerialNumber;
	
	public String getSerialNumberTxt() throws Exception{
		return lblSerialNumber.getText();
	}
	
//	private MobileElement lblSerialNumberVal() throws Exception{
//		return Element.findElementbyID(ObjectMap.getvalue("About_lbl_serialNumberVal"));
//	}
	
	@AndroidFindBy(id = "diagnostics-serialnumber-field")
	@iOSXCUITFindBy(accessibility = "diagnostics-serialnumber-field")
	MobileElement lblSerialNumberVal;
	
	public String getSerialNumberValTxt() throws Exception{
		return lblSerialNumberVal.getText();
	}
	
//	private MobileElement lbllenelFeedback() throws Exception{
//		return Element.findElementbyID(ObjectMap.getvalue("About_lbl_lenelFeedback"));
//	}
	
	@AndroidFindBy(id = "Feedback-title-label")
	@iOSXCUITFindBy(accessibility = "Feedback-title-label")
	MobileElement lbllenelFeedback;
	
	public String getlenelFeedbackTxt() throws Exception{
		return lbllenelFeedback.getText();
	}
	
//	private MobileElement lblWeb() throws Exception{
//		return Element.findElementbyID(ObjectMap.getvalue("About_lbl_web"));
//	}
	
	@AndroidFindBy(id = "Feedback-web-label")
	@iOSXCUITFindBy(accessibility = "Feedback-web-label")
	MobileElement lblWeb;
	
	public String getWebTxt() throws Exception{
		return lblWeb.getText();
	}
	
//	private MobileElement lblWebUrl() throws Exception{
//		return Element.findElementbyID(ObjectMap.getvalue("About_lbl_webUrl"));
//	}
	
	@AndroidFindBy(id = "Feedback-web-linklabel")
	@iOSXCUITFindBy(accessibility = "Feedback-web-linklabel")
	MobileElement lblWebUrl;
	
	public String getWebUrlTxt() throws Exception{
		return lblWebUrl.getText();
	}
	
//	private MobileElement lblEmail() throws Exception{
//		return Element.findElementbyID(ObjectMap.getvalue("About_lbl_email"));
//	}
	
	@AndroidFindBy(id = "Feedback-email-label")
	@iOSXCUITFindBy(accessibility = "Feedback-email-label")
	MobileElement lblEmail;
	
	public String getEmailTxt() throws Exception{
		return lblEmail.getText();
	}
	
//	private MobileElement lblEmailValue() throws Exception{
//		return Element.findElementbyID(ObjectMap.getvalue("About_lbl_emailValue"));
//	}
	
	@AndroidFindBy(id = "Feedback-email-linklabel")
	@iOSXCUITFindBy(accessibility = "Feedback-email-linklabel")
	MobileElement lblEmailValue;
	
	public String getEmailValueTxt() throws Exception{
		return lblEmailValue.getText();
	}
	
//	private MobileElement lblTelephone() throws Exception{
//		return Element.findElementbyID(ObjectMap.getvalue("About_lbl_telephone"));
//	}
	
	@AndroidFindBy(id = "Feedback-phoneno-label")
	@iOSXCUITFindBy(accessibility = "Feedback-phoneno-label")
	MobileElement lblTelephone;
	
	public String getTelephoneTxt() throws Exception{
		return lblTelephone.getText();
	}
	
//	private MobileElement lblTelephoneNumber() throws Exception{
//		return Element.findElementbyID(ObjectMap.getvalue("About_lbl_telephoneNumber"));
//	}
	
	@AndroidFindBy(id = "Feedback-phoneno-linklabel")
	@iOSXCUITFindBy(accessibility = "Feedback-phoneno-linklabel")
	MobileElement lblTelephoneNumber;
	
	public String getTelephoneNumberTxt() throws Exception{
		return lblTelephoneNumber.getText();
	}
	
//	private MobileElement lblGeneralInquiries() throws Exception{
//		return Element.findElementbyID(ObjectMap.getvalue("About_lbl_generalInquiries"));
//	}
	
	@AndroidFindBy(id = "Feedback-inquiry-label")
	@iOSXCUITFindBy(accessibility = "Feedback-inquiry-label")
	MobileElement lblGeneralInquiries;
	
	public String getGeneralInquiriesTxt() throws Exception{
		return lblGeneralInquiries.getText();
	}
	
//	private MobileElement lblGeneralInquiriesLink() throws Exception{
//		return Element.findElementbyID(ObjectMap.getvalue("About_lbl_generalInquiriesLink"));
//	}
	
	@AndroidFindBy(id = "Feedback-inquiry-linklabel")
	@iOSXCUITFindBy(accessibility = "Feedback-inquiry-linklabel")
	MobileElement lblGeneralInquiriesLink;
	
	public String getGeneralInquiriesLinkTxt() throws Exception{
		return lblGeneralInquiriesLink.getText();
	}
	
}
