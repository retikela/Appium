package com.utc.BD.Pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.appium.Common.Configure;
import com.appium.Common.Element;
import com.appium.Common.GenericFunctions;
import com.appium.Common.Gestures;
import com.appium.Common.ObjectMap;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.connection.HasNetworkConnection;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class ReadersList {
	public ReadersList(AppiumDriver<?> driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	public ReadersList() {
	}
	
	Gestures gestures = new Gestures();

	private MobileElement settings() throws Exception {
		if (GenericFunctions.isAndroid()) {
			return Element.findElementbyClassIndex(GenericFunctions.getInstance().getImageButtonClass(), 0);
		} else
			return Element.findElementbyID(ObjectMap.getvalue("ReaderList_btn_Appmenu"));
	}

	private MobileElement PathwayIcon() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("ReaderList_btn_PathwayIcon"));
	}

	public void clickPathwayIcon() throws Exception {
//		PathwayIcon().click();
		selectPathwayView();
	}
	
	ReadersHeaderNdFooter readerHnF = ReadersHeaderNdFooter.getInstance(Setup.driver);
	public void selectPathwayView() throws Exception {
		String view = ObjectMap.getvalue("Home_lbl_Pathways_txt");
		if(!(readerHnF.getviewsDropdownText().equalsIgnoreCase(view))) {
		readerHnF.clickViewsDropdown();
		readerHnF.clickviewsDropdownvalue(view);
//		Assert.assertEquals(readerHnF.getviewsDropdownText(),view,"View is not selected");
//		if(new Configure().isiOS()) {
//		readerHnF.clickViewsDropdown();
//		Assert.assertTrue(readerHnF.isviewSelected(view),"selected view is not checked");
//		readerHnF.clickViewsDropdown();
//		Assert.assertEquals(readerHnF.getRightbtntxt(), ObjectMap.getvalue("Nearby_btn_HeaderRightbtn_txt"),"Refresh button is not displayed");
//		}
		}
	}

	private MobileElement unlockbtn() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("ReaderList_btn_unlockButton"));
	}

	public void clickUnlockBtn() throws Exception {
		unlockbtn().click();
	}

	// private MobileElement errorHintIcon() throws Exception{
	// return
	// Element.findElementbyID(ObjectMap.getvalue("ReaderList_img_errorHintIcon"));
	// }
	//
	// public boolean waitForerrorHintIcon() throws Exception{
	// return Element.waitForElement(errorHintIcon());
	// }

	private MobileElement unlockBG() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("ReaderList_img_unlockBG"));
	}

	public boolean waitForUnlockBG() throws Exception {
		return Element.waitForElement(unlockBG());
	}

	private MobileElement doorOpeningAnimation() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("ReaderList_img_animitaion"));
	}

	public boolean waitForAnimation() throws Exception {
		return Element.waitForElement(doorOpeningAnimation(), 20);
	}

	private MobileElement doorStatus() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("ReaderList_lbl_doorStatus"));
	}

	public String getDoorStatus() throws Exception {
		return doorStatus().getText();
	}

	// private MobileElement errorDescription() throws Exception{
	// return
	// Element.findElementbyID(ObjectMap.getvalue("ReaderList_lbl_errorDescription"));
	// }
	//
	// public String getErrorDescription() throws Exception{
	// return errorDescription().getText();
	// }
	//
	// private MobileElement errorHintTitle() throws Exception{
	// return
	// Element.findElementbyID(ObjectMap.getvalue("ReaderList_lbl_errorHint"));
	// }
	//
	// public String getErrorHintTitle() throws Exception{
	// return errorHintTitle().getText();
	// }

	public void clickSettings() throws Exception {
		settings().click();
	}

	public boolean waitForSettings() {
		try {
			return Element.waitForElement(settings(), 20);
		} catch (Exception e) {
			return false;
		}
	}

	public boolean isPathwayIconVisible() {
		try {
			return Element.waitForElement(PathwayIcon(), 1);
		} catch (Exception e) {
			return false;
		}
	}

	private MobileElement btnStartPathway() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("ReaderList_btn_startPathway"));
	}

	public void clickBtnStartPathway() throws Exception {
		btnStartPathway().click();
	}

	public String getTextFromStartPathway() throws Exception {
		return Element.getElementText(btnStartPathway());
	}

	public boolean isStartPathwayVisible() {
		try {
			return Element.waitForElement(btnStartPathway(), 2);
		} catch (Exception e) {
			return false;
		}
	}

	private MobileElement imgCancelPathway() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("ReaderList_img_cancelPathway"));
	}

	public void clickimgCancelPathway() {
		try {
			imgCancelPathway().click();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public boolean isimgCancelPathwayVisible() {
		try {
			return Element.waitForElement(imgCancelPathway(), 1);
		} catch (Exception e) {
			return false;
		}
	}

	private MobileElement imgPathwayimage() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("ReaderList_img_Pathwayimage"));
	}

	public boolean isimgPathwayimageVisible() {
		try {
			return Element.waitForElement(imgPathwayimage(), 2);
		} catch (Exception e) {
			return false;
		}
	}

	// int statusTextIndex =
	// Integer.parseInt(ObjectMap.getvalue("ReaderList_lbl_StatusIndex"));
	//
	// private MobileElement status() throws Exception {
	// return
	// Element.findElementsbyClass(GenericFunctions.getLableClass()).get(statusTextIndex);
	// }

	public void clickReader(MobileElement m) {
		m.click();
	}

	public void addReaderToFavorite(MobileElement m) throws Exception {
		m.click();
		System.out.println("long press on element"+m.getText());
		gestures.longPress(m);
		waitForPin();
		clickPin();
		Thread.sleep(5000);
	}

	public void selectReaderforEdit(MobileElement m) throws Exception {
		m.click();
		gestures.longPress(m);
		waitForEdit();
		clickEdit();
		Thread.sleep(5000);
	}

	public void swapReaders(String Reader1, String Reader2) throws Exception {
		int reader1Index = getFavoriteReaders().indexOf(Reader1);
		int reader2Index = getFavoriteReaders().indexOf(Reader2);
		Gestures.dragAndDrop(getFavoriteReadersList().get(reader1Index), getFavoriteReadersList().get(reader2Index),
				10);
	}

	public void hideReader(MobileElement m) throws Exception {
		gestures.longPress(m);
		waitForHide();
		clickHide();
		acceptRemoveReader();
	}

	private MobileElement btnstartPathway() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("ActionPopup_btn_startPathway"));
	}

	public boolean waitForStartPathway() throws Exception {
		return Element.waitForElement(btnstartPathway());
	}

	public void clickStartPathway() throws Exception {
		btnstartPathway().click();
	}

	public void startPathway(String readername) throws Exception {
		clickFavouriteReader(readername);
//		m.click();
		Thread.sleep(2000);
		int position = getFavoriteReaders().indexOf(readername);
		gestures.longPress(getFavoriteReadersList().get(position));
		waitForStartPathway();
		clickStartPathway();
	}

	public static void acceptRemoveReader() {
		try {
			if (GenericFunctions.waitforAlert()) {
				System.out.println(GenericFunctions.getAlertMsg());
				GenericFunctions.acceptAlert();
			}
		} catch (Exception e) {
		}
	}

	public void removeReaderfromFavorite(MobileElement m) throws Exception {
		m.click();
		gestures.longPress(m);
		waitForUnPin();
		clickUnPin();
		acceptRemoveReader();
	}

	public void quicklinkFavReader(MobileElement m) throws Exception {
		m.click();
		gestures.longPress(m);
		waitForQuicklink();
		clikcQuicklink();
	}

	public void unlinkFavReader(MobileElement m) throws Exception {
		m.click();
		gestures.longPress(m);
		waitForUnlink();
		clikcUnlink();
		acceptRemoveReader();
	}

	public boolean addReaderasPHAAB(MobileElement m) throws Exception {
		System.out.println(m.getText());
		Gestures.clickScreenWindow();
//		m.click();
		gestures.longPress(m);
		return waitForEnablePhaab();
	}

	public void removeReaderfromPHAAB(MobileElement m) throws Exception {
		m.click();
		gestures.longPress(m);
		if (waitForRemovePhaab()) {
			clikcRemovePhaab();
		} else {
			Gestures.clickScreenWindow();
		}
		acceptRemoveReader();
	}

	private MobileElement pin() throws Exception {
		if (GenericFunctions.isAndroid()) {
			return Element.findElementbyXpath(ObjectMap.getvalue("ActionPopup_btn_pin"));
		} else
			return Element.findElementbyID(ObjectMap.getvalue("ActionPopup_btn_pin"));
	}

	public void clickPin() throws Exception {
		pin().click();
	}

	public void clickUnPin() throws Exception {
		unpin().click();
	}

	public boolean waitForPin() throws Exception {
		return Element.waitForElement(pin());
	}

	private MobileElement unpin() throws Exception {
		if (GenericFunctions.isAndroid()) {
			return Element.findElementbyXpath(ObjectMap.getvalue("ActionPopup_btn_unpin"));
		} else
			return Element.findElementbyID(ObjectMap.getvalue("ActionPopup_btn_unpin"));
	}

	public boolean waitForUnPin() throws Exception {
		return Element.waitForElement(unpin());
	}

	private MobileElement hide() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("ActionPopup_btn_hide"));
	}

	public boolean waitForHide() throws Exception {
		return Element.waitForElement(hide());
	}

	private MobileElement edit() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("ActionPopup_btn_edit"));
	}

	public boolean waitForEdit() throws Exception {
		return Element.waitForElement(edit());
	}

	public void clickEdit() throws Exception {
		edit().click();
	}

	public void clickHide() throws Exception {
		hide().click();
	}

	public String getStatusText() throws Exception {
		return doorStatus().getText();
	}

	public boolean waitForStatusText() throws Exception {
		return Element.waitForElement(doorStatus());
	}

	public ArrayList<String> normalreaders = new ArrayList<String>();

	public List<MobileElement> getReadersList() throws Exception {
		List<MobileElement> readers = ReadersTable();
		// List<MobileElement> readersList = new ArrayList<MobileElement>();
		// for (int i=0;i<readers.size();i++){
		// readersList.add(readers.get(i));
		// System.out.println(readers.get(i).getText());
		// }
		for (int i = 0; i < readers.size(); i++) {
			// favreadersList.add(favreaders.get(i));
			normalreaders.add(readers.get(i).getText());
			System.out.println(readers.get(i).getText());
		}
		return readers;
	}

	public List<String> getReaders() throws Exception {
		normalreaders.clear();
		getReadersList();
		System.out.println("Normal readers" + normalreaders);
		return normalreaders;

	}

	// return mobile elements of the readers under favorite
	public List<MobileElement> getFavoriteReadersList() throws Exception {
		// favoritereaders.clear();
		// List<MobileElement> favreaders = favoriteReadersTable();
		// List<MobileElement> favreadersList = new ArrayList<MobileElement>();

		return favoriteReadersTable();
	}

	// return names of the readers under favorite
	public List<String> getFavoriteReaders() throws Exception {
		List<String> favoritereaders = new ArrayList<>();
		favoritereaders.clear();
		List<MobileElement> favReadersElements = getFavoriteReadersList();
		// for (MobileElement mobileElement : getFavoriteReadersList()) {
		// favoritereaders.add(Element.getElementText(mobileElement));
		// }
		for (int i = 0; i < favReadersElements.size(); i++) {
			// favreadersList.add(favreaders.get(i));
			// System.out.println(getFavoriteReadersList().get(i).getText());
			// Element.findElementsbyName("Doors-favouritedoor-label").get(0).getText();
			favoritereaders.add(favReadersElements.get(i).getText());
		}
		System.out.println("Favorite readers" + favoritereaders);
		return favoritereaders;

	}

	private List<MobileElement> ReadersTable() throws Exception {
		// MobileElement readertable =
		// Element.findElementbyClass(GenericFunctions.getTableClass());
		// List<MobileElement> readers =
		// Element.findChildElementsbyClass(readertable,
		// GenericFunctions.getTableCellClass());
		if (GenericFunctions.isAndroid()) {
			return Element.findElementsbyXpath(ObjectMap.getvalue("ReaderList_lbl_Doors"));
		} else
			return Element.findElementsbyID(ObjectMap.getvalue("ReaderList_lbl_Doors"));
	}

	private List<MobileElement> favoriteReadersTable() throws Exception {
		// MobileElement readertable =
		// Element.findElementbyClass(GenericFunctions.getTableClass());
		// List<MobileElement> readers =
		// Element.findChildElementsbyClass(readertable,
		// GenericFunctions.getTableCellClass());
		// List<MobileElement> favReaders =
		// Element.findElementsbyName(ObjectMap.getvalue("ReaderList_lbl_favoriteDoors"));
		// return favReaders;
		if (GenericFunctions.isAndroid()) {
//			return Setup.driver.findElements(MobileBy.AndroidUIAutomator(
//	                String.format("new UiSelector().description(\"%s\")", "Favorite")));
			return Element.findElementsbyXpath(ObjectMap.getvalue("ReaderList_lbl_favoriteDoors"));
		} else
			return Element.findElementsbyID(ObjectMap.getvalue("ReaderList_lbl_favoriteDoors"));
	}

	// XCUIElementTypeImage[@name="Doors-favicon-image"])[2]//parent::XCUIElementTypeCell

	private List<MobileElement> favoriteReaderscells() throws Exception {
		List<MobileElement> favReaderscells = Element
				.findElementsbyXpath(ObjectMap.getvalue("ReaderList_cell_FavReaders"));
		return favReaderscells;
	}

	private List<MobileElement> NormalReaderscells() throws Exception {
		List<MobileElement> normalReaderscells = Element
				.findElementsbyXpath(ObjectMap.getvalue("ReaderList_cell_NormalReaders"));
		System.out.println("normalReaderscell count : " + normalReaderscells.size());
		return normalReaderscells;
	}

	public boolean isQuicConnectEnabled(int i) {
		// Element.findElementsbyXpath("//XCUIElementTypeOther[1]/XCUIElementTypeCollectionView/XCUIElementTypeCell").get(0).findElementsByClassName("XCUIElementTypeImage").get(0).getAttribute("name")
		// Element.findElementsbyXpath("//XCUIElementTypeOther[1]/XCUIElementTypeCollectionView/XCUIElementTypeCell").get(0).findElementByXPath("/XCUIElementTypeOther/XCUIElementTypeOther");
		try {
			return Element.waitForElement(Element.findChildElementsbyID(favoriteReaderscells().get(i),
					ObjectMap.getvalue("ReaderList_img_quickConnectEnabled")).get(0));
		} catch (Exception e) {
			return false;
		}
		// return
		// Element.waitForElement(favoriteReaderscells().get(mobileElement).findElementById(ObjectMap.getvalue("ReaderList_img_quickConnectEnabled")));
	}

	public boolean isPHAABEnabledforFavoriteReader(int favritePosition) {
		try {
			Thread.sleep(8000);
			Element.findElementsbyID(ObjectMap.getvalue("ReaderList_img_Phaab")).get(favritePosition).isEnabled();
//			Boolean status = Element.isEnabled(Element.findElementsbyID(ObjectMap.getvalue("ReaderList_img_Phaab")).get(favritePosition));
//			status=Boolean.valueOf(Element.findElementsbyID(ObjectMap.getvalue("ReaderList_img_Phaab")).get(favritePosition).getAttribute("enabled"));
			return true;
//			return Element.isEnabled(Element.findChildElementbyID(favoriteReaderscells().get(favritePosition),ObjectMap.getvalue("ReaderList_img_Phaab")));
		} catch (Exception e) {
			return false;
		}
		// return
		// Element.waitForElement(favoriteReaderscells().get(mobileElement).findElementById(ObjectMap.getvalue("ReaderList_img_quickConnectEnabled")));
	}

	public boolean isPHAABEnabledforNormalReader(int Position) {
		try {
			return Element.isEnabled(Element.findChildElementbyID(NormalReaderscells().get(Position),
					ObjectMap.getvalue("ReaderList_img_PhaabNormal")));
		} catch (Exception e) {
			return false;
		}
		// return
		// Element.waitForElement(favoriteReaderscells().get(mobileElement).findElementById(ObjectMap.getvalue("ReaderList_img_quickConnectEnabled")));
	}

	public void clearallFavReaders() throws Exception {
		List<MobileElement> readersList = getFavoriteReadersList();
		for (MobileElement mobileElement : readersList) {
			removeReaderfromFavorite(mobileElement);
		}
	}

	public void clearallPHAABFavReaders() throws Exception {
		List<MobileElement> readersList = getFavoriteReadersList();
		for (MobileElement mobileElement : readersList) {
			removeReaderfromPHAAB(mobileElement);
		}
	}

	public void clearallPHAABNormalReaders() throws Exception {
		List<MobileElement> readersList = getReadersList();
		for (MobileElement mobileElement : readersList) {
			removeReaderfromPHAAB(mobileElement);
		}
	}

	public boolean isQuicConnectReady(int reader) {
		try {
			return Element.waitForElement(Element.findChildElementsbyID(favoriteReaderscells().get(reader),
					ObjectMap.getvalue("ReaderList_img_quickConnectReady")).get(0));
		} catch (Exception e) {
			return false;
		}
	}

	public boolean isQuicConnecting(int reader) {
		try {
			return Element.waitForElement(Element.findChildElementsbyID(favoriteReaderscells().get(reader),
					ObjectMap.getvalue("ReaderList_img_quickConnectConnecting")).get(0));
		} catch (Exception e) {
			return false;
		}
		// return
		// favoriteReaderscells().get(reader).findElementById(id)equals(quickConnecting());
	}

	public void clickReader(int number) throws Exception {
		getReadersList().get(number).click();
	}

	public void clickFavouriteReader(String reader) throws Exception {
		int position = getFavoriteReaders().indexOf(reader);
		getFavoriteReadersList().get(position).click();
	}

	public int getEmptyCellHeight() throws Exception {
		return (ReadersTable().get(0).getSize()).height;
	}

	// public boolean isBluetoothOff() throws Exception{
	// if(getStatusText().equalsIgnoreCase(ObjectMap.getvalue("ReadersList_txt_BluetoothOff"))){
	// return true;
	// }else{
	// return false;
	// }
	// }
	//
	public boolean isSearching() throws Exception {
		if (getStatusText().equalsIgnoreCase(ObjectMap.getvalue("ReadersList_txt_Searching"))) {
			return true;
		} else {
			return false;
		}
	}

	public boolean isLookingForReaders() throws Exception {
		if (getSelectedReaderText().equalsIgnoreCase(ObjectMap.getvalue("ReadersList_txt_LookingForReaders"))) {
			return true;
		} else {
			return false;
		}
	}

	public void disableDeviceBluetooth() throws Exception {
		gestures.disableBlueTooth();
	}

	public void enableDeviceBluetooth() throws Exception {
		gestures.enableBlueTooth();
	}

	private MobileElement selectedReader() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("ReaderList_lbl_selectedDoor"));
	}

	public String getSelectedReaderText() throws Exception {
		return selectedReader().getText();
	}

	private MobileElement quicklink() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("ActionPopup_btn_quicklink"));
	}

	public boolean waitForQuicklink() throws Exception {
		return Element.waitForElement(quicklink());
	}

	private MobileElement enablePhaab() throws Exception {
		if (GenericFunctions.isAndroid()) {
			return Element.findElementbyXpath(ObjectMap.getvalue("ActionPopup_btn_Phaabadd"));
		} else
			return Element.findElementbyID(ObjectMap.getvalue("ActionPopup_btn_Phaabadd"));
	}

	public boolean waitForEnablePhaab() throws Exception {
		return Boolean.valueOf(Element.getAttribute(enablePhaab(), "enabled"));
	}

	public void clikcEnablePhaab() throws Exception {
		enablePhaab().click();
	}

	private MobileElement removePhaab() {
		try {
			if (GenericFunctions.isAndroid()) {
				return Element.findElementbyXpath(ObjectMap.getvalue("ActionPopup_btn_Phaabremove"));
			} else
				return Element.findElementbyID(ObjectMap.getvalue("ActionPopup_btn_Phaabremove"));
		} catch (Exception e) {
		}
		return null;
	}

	public boolean waitForRemovePhaab() {
		return Element.waitForElement(removePhaab());
	}

	public void clikcRemovePhaab() throws Exception {
		removePhaab().click();
	}

	public void clikcQuicklink() throws Exception {
		quicklink().click();
	}

	private MobileElement unlink() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("ActionPopup_btn_unlink"));
	}

	public boolean waitForUnlink() throws Exception {
		return Element.waitForElement(unlink());
	}

	public void clikcUnlink() throws Exception {
		unlink().click();
	}

	private MobileElement quickConnecting() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("ReaderList_img_quickConnectConnecting"));
	}

	public boolean waitForQuickConnecting() throws Exception {
		return Element.waitForElement(quickConnecting());
	}

	private MobileElement quickConnectEnabled() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("ReaderList_img_quickConnectEnabled"));
	}

	public boolean waitForQuickConnectEnabled() throws Exception {
		return Element.waitForElement(quickConnectEnabled());
	}

	private MobileElement quickConnectReady() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("ReaderList_img_quickConnectReady"));
	}

	public boolean waitForQuickConnectReady() throws Exception {
		return Element.waitForElement(quickConnectReady());
	}

}
