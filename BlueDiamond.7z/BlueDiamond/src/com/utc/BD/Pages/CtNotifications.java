package com.utc.BD.Pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.appium.Common.Element;
import com.appium.Common.GenericFunctions;
import com.appium.Common.ObjectMap;

import io.appium.java_client.MobileElement;

public class CtNotifications {
	
	private MobileElement notificationReceiveTime() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("notification_lbl_receiveTime"));
	}
	private MobileElement notificationMessageinDetailPage() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("notificationDetail_lbl_message"));
	}
	private MobileElement messageDescriptionInDetailPage() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("notificationDetail_lbl_messageDescription"));
	}
	private MobileElement deleteButtoninNotificationDetailPage() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("notificationDetail_btn_deleteButton"));
	}

	private MobileElement unreadNotification() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("notification_lbl_unreadNotificaionNumber"));
	}
	
	private MobileElement quarantineStarted() throws Exception{
		return Element.findElementbyXpath(ObjectMap.getvalue("notification_txt_quarantineStratrd"));
	}
	
	private MobileElement markAllRead() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("notification_btn_markAllRead"));
	}
	
	private MobileElement alertPopup() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("notificationDetail_btn_DeleteAlertPopup"));
	}
	
	private MobileElement notificationDetailBackbtn() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Rename_btn_back"));
	}
	
	private List<MobileElement> notifications() throws Exception{
		return Element.findElementsbyID("notification_lbl_message");
	}
	
	private MobileElement tooCloseDescriptionInDetailPage() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("notificationDetail_lbl_messageDescription"));
	}
	private MobileElement notificationHeader() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("notification_lbl_notification"));
	}
	private List<MobileElement> listOfNotificationEle() throws Exception{
		return Element.findElementsbyID(ObjectMap.getvalue("notification_lbl_message"));
	}
	
	private List<MobileElement> listOfNotification() throws Exception{
		return Element.findElementsbyID(ObjectMap.getvalue("notification_lbl_rlItemView"));
	}
	private List<MobileElement> listOfIvDotEle() throws Exception{
		return Element.findElementsbyID(ObjectMap.getvalue("notification_img_dot"));
	}
	private List<MobileElement> notificationDateTime() throws Exception{
		return Element.findElementsbyID(ObjectMap.getvalue("notification_lbl_receiveTime"));
	}
	
	private List<MobileElement> rllitemView() throws Exception{
		return Element.findElementsbyID(ObjectMap.getvalue("notification_Layout_rllitemView"));
	}
	
	private MobileElement header() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("notification_Navbar_Header"));
	}
	public List<MobileElement> notificationsIds() throws Exception
	{
		return notifications();
		
	}
	public String unreadNotificatioCount() throws Exception
	{
		return unreadNotification().getText();
	}
	
	public String quarantineStartedNotification() throws Exception
	{
		return quarantineStarted().getText();
	}
	
	public String markAllReadBtn() throws Exception
	{
		return markAllRead().getText();
	}
	
	public void clickMarkAllRead() throws Exception
	{
		markAllRead().click();
	}
	
	public String verifyDeleteBtn() 
	{
		String str=null;
		try {
			boolean status =isDisplay(deleteButtoninNotificationDetailPage());
			if(status==true)
			{
				str="Delete button is Displaying";
			}
		} catch (Exception e) {
			str="Delete button is not Displaying";
		}
		return str;
	}
	
	public String VerifymarkAllRead() 
	{
		String str=null;
		try {
			boolean status =isDisplay(markAllRead());
			if(status==true)
			{
				str="markAllRead button is Displaying";
			}
		} catch (Exception e) {
			str="markAllRead button is not Displaying";
		}
		return str;
	}
	
	public void clickOnDeleteBtn() throws Exception
	{
		deleteButtoninNotificationDetailPage().click();
	}
	
	public void deleteAlertPopup() throws Exception
	{
		alertPopup().click();
	}
	
	public void clickDeleteBtnOnDeleteNotifictnPopup() throws Exception
	{
		if(GenericFunctions.isIOS())
		{
			Element.findElementbyID(ObjectMap.getvalue("notificationDetail_btn_AlertPopupDeleteBtn")).click();	
		}	
		else {
			List<MobileElement> ele=Element.findElementsbyID(ObjectMap.getvalue("notificationDetail_btn_AlertPopupAllButtons"));
			ele.get(0).click();
		}
		
	}
	public void clickBackbtn() throws Exception
	{
		notificationDetailBackbtn().click();
	}
	
	public String QurantineStrtdTitle() throws Exception
	{
		return notificationMessageinDetailPage().getText();
	}
	
	public String notificationDescription() throws Exception
	{
		return messageDescriptionInDetailPage().getText();
	}
	public boolean isDisplay(MobileElement element)
	{
		boolean status=false;
		try {
		 status=element.isDisplayed();
		}
		catch(Exception e)
		{
			status=false;
		}
		return status ;
	}
	
	public String tooCloseTitle() throws Exception
	{
		return notificationMessageinDetailPage().getText();
	}
	
	public String toCloseNotificationDescription() throws Exception
	{
		return tooCloseDescriptionInDetailPage().getText();
	}
	
	public boolean waitforNotificationHeader() throws Exception {
		return Element.waitForElement(notificationHeader());
	}
	
	public String timeAndDateQurantineNotification() throws Exception
	{
		String t=notificationReceiveTime().getText();
		return notificationReceiveTime().getText();
	}
	public void clickOnQuarantineStrtd() throws Exception
	{
		
		for(int i=0;i<=listOfNotificationEle().size();i++)
		{
			
			WebElement ele=listOfNotificationEle().get(i);
			if(ele.getText().contains(ObjectMap.getvalue("notification_txt_quarantine")))
			{
				ele.click();
				break;
			}
			
			
		}
	}
	
	public String QuarantinenotificationRcvTime() throws Exception
	{
		String dateTime=null;
		for(int i=0;i<=listOfNotificationEle().size();i++)
		{
		    WebElement ele2=notificationDateTime().get(i);
			if(listOfNotificationEle().get(i).getText().contains(ObjectMap.getvalue("notification_txt_quarantine")))
			{
				dateTime=ele2.getText();
				break;
			}
		}
		return dateTime;
	}
	
	public void clickOnTooClose() throws Exception
	{
		
		for(int i=0;i<=listOfNotificationEle().size();i++)
		{
			
			WebElement ele=listOfNotificationEle().get(i);
			if(ele.getText().contains(ObjectMap.getvalue("notification_lbl_Tooclose")))
			{
				ele.click();
				break;
			}
			
			
		}
	}
	
	public int clickOnNotificationAndVerifyIVDot() throws Exception
	{
		int notificationNumber = 0;
		int notificationIndex=0;
		int count=0;
		for(int i=0;i<=listOfNotificationEle().size();i++)
		{	
			WebElement ele=listOfNotificationEle().get(i);
			if(ele.getText().contains(ObjectMap.getvalue("notification_lbl_Tooclose")))
			{
				notificationNumber=1;
				notificationIndex=i;
				ele.click();
				break;
			}	
		}
		clickBackbtn();
		
		if(notificationNumber>0) {
			try {
				MobileElement ele;
				ele = listOfNotification().get(notificationIndex);
				Element.findChildElementbyID(ele, ObjectMap.getvalue("notification_img_dot"));
				count++;
			} catch (Exception e) {
				count=0;
			}
		
		}
		return count;
	}
	
	public List<MobileElement> getNotifications() throws Exception {
		return listOfNotificationEle();
	}
	
	public String tooCloseNotificationRcvTime() throws Exception
	{
		String dateTime=null;
		for(int i=0;i<=listOfNotificationEle().size();i++)
		{
		    WebElement ele2=notificationDateTime().get(i);
			if(listOfNotificationEle().get(i).getText().contains(ObjectMap.getvalue("notification_lbl_Tooclose")))
			{
				dateTime=ele2.getText();
				break;
			}
		}
		return dateTime;
	}
	
	public int totalNotificationReceived()
	{
		int count=0;
		try {
			for(int i=0;i<=(listOfNotificationEle().size())-1;i++)
			{		
				WebElement ele=listOfNotificationEle().get(i);
				
					count++;	
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}
	
	public int totalNumberOFTooCloseNotification()
	{
		int count=0;
		try {
			for(int i=0;i<=(listOfNotificationEle().size())-1;i++)
			{		
				WebElement ele=listOfNotificationEle().get(i);
				if(ele.getText().contains(ObjectMap.getvalue("notification_lbl_Tooclose")))
				{
					count++;
				}	
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}
	
	public int ivDotCount()
	{
		int count=0;
		try {
			count = listOfIvDotEle().size();
		} catch (Exception e) {
			count=0;
		}
		
		return count;
	}
	
	public void verifyMarkAllRead() throws Exception
	{
		int ivDotcountBfreClick=ivDotCount();
		clickMarkAllRead();
		int ivDotCountAftrClick=ivDotCount();
		if(ivDotcountBfreClick>0)
		{
			Assert.assertEquals(ivDotCountAftrClick,0);
		}
		
		
	}
	
	public int verifyIvDot()
	{
		int count=0;
		MobileElement ele;
		try {
			ele = rllitemView().get(1);
			Element.findChildElementbyID(ele, ObjectMap.getvalue("notification_img_dot"));
			count++;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			
		}
		return count;
	}
	
	public String getHeaderText() throws Exception{
		return header().getText();
	}
	
	public int totalNumberOFQurantineNotification() throws Exception
	{
		int count=0;
			for(int i=0;i<=(listOfNotificationEle().size())-1;i++)
			{		
				WebElement ele=listOfNotificationEle().get(i);
				if(ele.getText().contains(ObjectMap.getvalue("notification_txt_quarantine")))
				{
					count++;
				}	
			}
		return count;
	}
	
	public boolean verifyDeleteNotificationPopupTitle()
	{
		try {
			return Element.waitforVisible("id", ObjectMap.getvalue("notification_lbl_DeleteNotificationPopUpTitle"), 30);
		} catch (Exception e) {
			return false;

		}
	}
	
	private MobileElement titleDeleteNotifictnPopup() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("notification_lbl_DeleteNotificationPopUpTitle"));
	}
	
	private MobileElement descriptionMsgDeleteNotifictnPopup() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("notification_lbl_DeleteNotificationPopUpMessage"));
	}
	public String titleOfDeleteNotifictnPopUp() throws Exception
	{
		return titleDeleteNotifictnPopup().getText();
	}
	
	public String deleteNotifictnPopUpDescriptionMsg() throws Exception
	{
		return descriptionMsgDeleteNotifictnPopup().getText();
	}
	
	public void clickCancelBtnOnDeleteNtfnPopup() throws Exception
	{
		if(GenericFunctions.isIOS())
		{
		Element.findElementbyID(ObjectMap.getvalue("notificationDetail_btn_AlertPopupCancelBtn")).click();
		}
		else
		{
			List<MobileElement> ele=Element.findElementsbyID(ObjectMap.getvalue("notificationDetail_btn_AlertPopupAllButtons"));
			ele.get(2).click();
		}
		
	}
	
	

	/*public int notificationsCount() throws Exception
	{
		int count=0;
			for(int i=0;i<=(listOfNotificationEle().size())-1;i++)
			{		
				WebElement ele=listOfNotificationEle().get(i);
				String m = ele.getText();
				String t1=ObjectMap.getvalue("notification_txt_quarantine");
				String t2=ObjectMap.getvalue("notification_txt_quarantineEnded");
				String t3=ObjectMap.getvalue("notification_txt_contactNotice");
				if(ele.getText().equalsIgnoreCase(ObjectMap.getvalue("notification_txt_quarantine"))
						||(ele.getText().equalsIgnoreCase(ObjectMap.getvalue("notification_txt_quarantineEnded"))||
								(ele.getText().equalsIgnoreCase(ObjectMap.getvalue("notification_txt_contactNotice")))))
						
				{
					count++;
				}	
			}
		return count;
	}*/
	
	public int notificationBatchCount() throws Exception
	{
		String s= BatchCount().getText();
		return Integer.parseInt(s);  
	}
	private WebElement BatchCount() throws Exception {

		return Element.findElementbyID(ObjectMap.getvalue("notification_lbl_notificationCount"));

	}
	
	public void selectNotificationsTab()
	{
		
	}
}


