package com.utc.BD.Test;

import java.io.FileReader;
import java.lang.reflect.Method;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appium.Common.Configure;
import com.appium.Common.Element;
import com.appium.Common.GenericFunctions;
import com.appium.Common.Gestures;
import com.appium.Common.ObjectMap;
import com.appium.Common.SiriCommand;
import com.utc.BD.Pages.About;
import com.utc.BD.Pages.BlueToothError;
import com.utc.BD.Pages.CreatePathway;
import com.utc.BD.Pages.Credentials;
import com.utc.BD.Pages.Debug;
import com.utc.BD.Pages.ErrorScren;
import com.utc.BD.Pages.Favorites;
import com.utc.BD.Pages.Help;
import com.utc.BD.Pages.Hidden;
import com.utc.BD.Pages.LoginPage;
import com.utc.BD.Pages.ManagePathway;
import com.utc.BD.Pages.PHAAB;
import com.utc.BD.Pages.PathwayDragAndDrop;
import com.utc.BD.Pages.PathwayWelcome;
import com.utc.BD.Pages.Preferences;
import com.utc.BD.Pages.Prefereneces_Gestures;
import com.utc.BD.Pages.ReadersHeaderNdFooter;
import com.utc.BD.Pages.ReadersList;
import com.utc.BD.Pages.RenameReader;
import com.utc.BD.Pages.Sensitivity;
import com.utc.BD.Pages.Settings;
import com.utc.BD.Pages.Settings_Pathway;
import com.utc.BD.Pages.Setup;
import com.utc.BD.Pages.WalkThrough;
import com.utc.BD.Pages.Widget;

import io.appium.java_client.MobileElement;

public class TestCases extends Setup {

	static LoginPage lp ;
	static ReadersList readersPage ;
	static BlueToothError bterror ;
	static Settings settings;
	static Configure config;
	static Debug debug;
	static Preferences preferences ;
	static Help help;
	static Credentials credentials ;
	static RenameReader rename ;
	static About abt ;
	static ErrorScren err ;
	static Hidden hide ;
	static Favorites fav;
	static Sensitivity sensitivity ;
	static PathwayWelcome welcome;
	static PathwayDragAndDrop dragDrop;
	static CreatePathway pathcreate;
	static ManagePathway pathmanage;
	static Settings_Pathway pathSetting;
	static Widget widget;
	static WalkThrough walk;
	static ReadersHeaderNdFooter readerHnF;
	
	@BeforeMethod()
	public void initiateDriver() {
		 lp = new LoginPage();
		 readersPage = new ReadersList(driver);
		 bterror = new BlueToothError();
		 settings = new Settings();
		 config = new Configure();
		 debug = new Debug();
		 preferences = new Preferences();
		 help = new Help(driver);
		 credentials = new Credentials(driver);
		 rename = new RenameReader();
		 abt = new About(driver);
		 err = new ErrorScren();
		 hide = new Hidden();
		 fav = new Favorites();
		 sensitivity = new Sensitivity();
		 welcome = new PathwayWelcome();
		 dragDrop = new PathwayDragAndDrop();
		 pathcreate = new CreatePathway();
		 pathmanage = new ManagePathway();
		 pathSetting = new Settings_Pathway();
		 widget = new Widget();
		 walk = new WalkThrough();
		 readerHnF = ReadersHeaderNdFooter.getInstance(driver);
	}

	@Test
	public void appLogin() {
		try {
			// sa.assertTrue(lp.waitforLocationServicesAlertinfo(), "Location services are
			// not displayed");
			lp.clickWhileUsing();
			// sa.assertTrue(lp.waitforNotificationsAlertinfo(), "Unable to navigate login
			// page");
			lp.clickAllow();
			lp.acceptMotionNdFitness();
			lp.acceptBLEAlert();
			Assert.assertTrue(lp.waitforLogo(), "Unable to navigate login page");
			lp.enterUsername(config.getUsername());
			lp.enterPassword(config.getPassword());
			sa.assertEquals(ObjectMap.getvalue("Login_EULA_txt"), lp.getEULAtxt());
			sa.assertEquals(ObjectMap.getvalue("Login_Privacy_txt"), lp.getPrivacytxt());
			lp.checkEula();
			lp.checkDataPrivacy();
			sa.assertEquals(ObjectMap.getvalue("Login_Next_txt"), lp.getNextTxt());
			lp.clickSignin();
			Thread.sleep(10000);
			lp.acceptPaymentlert();
//			readersPage.waitForSettings();
			Assert.assertEquals(ObjectMap.getvalue("WalkthroughScreen_MapsAndDirections_txt"), walk.MapsAndDirectionsHeaderText());
//			Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers page");
			sa.assertAll();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Assert.fail();
		}
	}

	@Test(description = "verify error message displayed for invalid url")
	public void invalidUrlLogin() {
		try {
			Assert.assertTrue(lp.waitforLogo(), "Unable to navigate login page");
			lp.enterUsername("abc.co.in");
			lp.enterPassword(config.getPassword());
			lp.checkEula();
			lp.checkDataPrivacy();
			lp.clickSignin();
			Assert.assertTrue(lp.waitforDismiss());
			lp.clickDismiss();
			Assert.assertTrue(lp.waitforLogo(), "Unable to navigate login page");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Assert.fail();
		}
	}

	@Test(description = "verify error message displayed for invalid key")
	public void invalidKeyLogin() {
		try {
			Assert.assertTrue(lp.waitforLogo(), "Unable to navigate login page");
			lp.enterUsername(config.getUsername());
			lp.enterPassword("12345");
			lp.checkEula();
			lp.checkDataPrivacy();
			lp.clickSignin();
			Assert.assertTrue(lp.waitforDismiss());
			lp.clickDismiss();
			Assert.assertTrue(lp.waitforLogo(), "Unable to navigate login page");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Assert.fail();
		}
	}

	@Test
	public void navigateToSettings(Method method) {
		try {
			readersPage.waitForSettings();
			readersPage.clickSettings();
			Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
			sa.assertEquals(ObjectMap.getvalue("About_Header_Txt"), settings.getAboutText());
			sa.assertEquals(ObjectMap.getvalue("Preferences_Header_Txt"), settings.getPreferencesText());
			sa.assertEquals(ObjectMap.getvalue("Help_Header_Txt"), settings.getAHelpText());
			sa.assertEquals(ObjectMap.getvalue("Credentials_Header_Txt"), settings.getCredentialsText());
			settings.clickCloseButton();
			sa.assertAll();
			Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers page");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Assert.fail();
		}
	}

	@Test
	public void navigateToAboutPage() {
		try {
			readersPage.waitForSettings();
			readersPage.clickSettings();
			SiriCommand.shake();
			new SiriCommand().testSiriCommand("Open Door");
			Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
			settings.clickAbout();
			Assert.assertTrue(abt.waitforAboutHeader(), "Unable to navigate About page");
			sa.assertEquals(ObjectMap.getvalue("About_Header_Txt"), abt.getHeaderTxt());
			sa.assertEquals(ObjectMap.getvalue("About_Copyrights_Txt"), abt.getCopyrightsTxt());
			sa.assertEquals(ObjectMap.getvalue("About_Diagnostics_Txt"), abt.getDiagnosticsTxt());
			sa.assertEquals(ObjectMap.getvalue("About_Version_Txt"), abt.getVersionTxt());
			// sa.assertEquals(ObjectMap.getvalue("About_FrameworkVersion_Txt"),
			// abt.getFrameworkVersionTxt());
			sa.assertEquals(ObjectMap.getvalue("About_SerialNumber_Txt"), abt.getSerialNumberTxt());
			// sa.assertEquals(ObjectMap.getvalue("About_Web_Txt"), abt.getWebTxt());
			// sa.assertEquals(ObjectMap.getvalue("About_Email_Txt"), abt.getEmailTxt());
			// sa.assertEquals(ObjectMap.getvalue("About_TelePhone_Txt"),
			// abt.getTelephoneTxt());
			// sa.assertEquals(ObjectMap.getvalue("About_GeneralInquiries_Txt"),
			// abt.getGeneralInquiriesTxt());
			abt.clickBack();
			Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
			settings.clickCloseButton();
			Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers page");
			sa.assertAll();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Assert.fail();
		}
	}

	@Test
	public void navigateToDebugPage() throws Exception {
		readersPage.waitForSettings();
		readersPage.clickSettings();
		Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
		try {
			settings.clickDebug();
		} catch (Exception e) {
			throw new SkipException("Skipping the testcases as the debug is not enabled for the installed key");
		}
		Assert.assertTrue(debug.waitforDebugHeader(), "Unable to navigate Diagnostics page");
		debug.clickBack();
		Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
		settings.clickCloseButton();
		Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers page");
	}

	@Test // Need to update the test case for B2 2.1.5
	public void navigateToHelpPage() {
		try {
			readersPage.waitForSettings();
			readersPage.clickSettings();
			Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
			settings.clickHelp();
			Assert.assertTrue(help.waitforHelpHeader(), "Unable to navigate Help page");
			FileReader reader = new FileReader("BD_help.htm");
			// System.out.println("Phone Text: "+help.getHelpText());
			// System.out.println("Help file Text: "+help.extractText(reader));
			sa.assertEquals(help.getHelpText(), help.extractText(reader)); // phone help issue
			sa.assertAll();
			help.clickBack();
			Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
			settings.clickCloseButton();
			Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers page");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Assert.fail();
		}
	}

	public void navigateToPreferencesPage() {
		try {
			readersPage.waitForSettings();
			readersPage.clickSettings();
			Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
			settings.clickPreferences();
			Assert.assertEquals(preferences.getHeaderText(), ObjectMap.getvalue("Preferences_Header_Txt"),
					"Unable to navigate Preferences page");
			sa.assertEquals(ObjectMap.getvalue("Preferences_Header_Txt"), preferences.getHeaderText());
			sa.assertEquals(ObjectMap.getvalue("Preferences_Sensitivity_Txt"), preferences.getSensitivityTxt());
			sa.assertEquals(ObjectMap.getvalue("Preferences_BGServices_Txt"), preferences.getBackgroundServicesTxt());
			sa.assertEquals(ObjectMap.getvalue("Preferences_Notifications_Txt"), preferences.getNotificationsTxt());
			sa.assertEquals(ObjectMap.getvalue("Preferences_Pathways_Txt"), preferences.getPathwaysTxt());
			sa.assertEquals(ObjectMap.getvalue("Preferences_Hidden_Txt"), preferences.getHiddenTxt());
			sa.assertEquals(ObjectMap.getvalue("Preferences_Gestures_Txt"), preferences.getGesturesTxt());
			sa.assertEquals(ObjectMap.getvalue("Preferences_Favorites_Txt"), preferences.getFavoritesTxt());
			preferences.clickBack();
			sa.assertAll();
			Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
			settings.clickCloseButton();
			Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers page");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Assert.fail();
		}
	}

	// @Test
	// public void verifyPrefencesPriorityTop() throws Exception {
	// readersPage.waitForSettings();
	// if (readersPage.getReadersList().size() > 0) {
	// // if (readersPage.getEmptyCellHeight() > 0) {
	// readersPage.clickSettings();
	// Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate
	// Settings page");
	// settings.clickPreferences();
	// Assert.assertTrue(preferences.waitforPreferencesHeader(), "Unable to navigate
	// Preferences page");
	// preferences.clickPriorityTop();
	// sa.assertTrue(preferences.isCheckedPriorityTop(), "Top is not in checked
	// state");
	// preferences.clickBack();
	// Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate
	// Settings page");
	// settings.clickCloseButton();
	// Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers
	// page");
	// if (readersPage.getEmptyCellHeight() > 0) {
	// sa.fail("List is not displayed at top");
	// }
	// // } else {
	// // throw new SkipException("Skipping the testcases as the list is
	// // already at top");
	// // }
	// } else {
	// throw new SkipException("Skipping the testcases as the list is empty");
	// }
	//
	// }

	// @Test
	// public void verifyPrefencesPriorityBottom() throws Exception {
	// readersPage.waitForSettings();
	// if (readersPage.getReadersList().size() > 0) {
	// // if (readersPage.getEmptyCellHeight() > 0) {
	// readersPage.clickSettings();
	// Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate
	// Settings page");
	// settings.clickPreferences();
	// Assert.assertTrue(preferences.waitforPreferencesHeader(), "Unable to navigate
	// Preferences page");
	// preferences.clickPriorityBottom();
	// sa.assertTrue(preferences.isCheckedPriorityBottom(), "Bottom is not in
	// checked state");
	// preferences.clickBack();
	// Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate
	// Settings page");
	// settings.clickCloseButton();
	// Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers
	// page");
	// if (readersPage.getEmptyCellHeight() > 0) {
	// sa.fail("List is not displayed at top");
	// }
	// // } else {
	// // throw new SkipException("Skipping the testcases as the list is
	// // already at bottom");
	// // }
	// } else {
	// throw new SkipException("Skipping the testcases as the list is empty");
	// }
	//
	// }

	@Test(description = "Verfiy user is navigated to BlueTooth error screen on turning off the device bluetooth")
	public void verifyReaderListOnBTOff() throws Exception {
		// readersPage.waitForSettings();
		// if (!bterror.isBluetoothOff()) {
		// if (readersPage.getReadersList().size() > 0) {
		readersPage.disableDeviceBluetooth();
		sa.assertEquals(bterror.waitforBTOffIconIcon(), true, "'BlueTooth is off' screen is not displayed");
		sa.assertEquals(ObjectMap.getvalue("BT_Header_txt"), bterror.getErrorDescription());
		sa.assertEquals(ObjectMap.getvalue("BT_BToff_txt"), bterror.getBTOffMessage());
		sa.assertEquals(ObjectMap.getvalue("BT_Error_txt"), bterror.getErrorHint());
		sa.assertEquals(ObjectMap.getvalue("BT_SettingsHint_txt"), bterror.getEnableSettingsLink());
		sa.assertAll();
	}

	@Test(description = "Verfiy user is navigated to device settings page on selecting settings in application")
	public void verifyErrorOnBTOff() throws Exception {
		try {
			readersPage.waitForSettings();
			// List<MobileElement> readersList = readersPage.getReadersList();
			// if (readersList.size() > 0) {
			// // if (readersPage.getEmptyCellHeight() > 0) {
			// readersPage.clickReader(readersList.get(0));
			readersPage.disableDeviceBluetooth();
			sa.assertEquals(bterror.waitforBTOffIconIcon(), true, "'BlueTooth is off' screen is not displayed");
			bterror.clickSettingsLink();
			sa.assertEquals(bterror.waitForDeviceSettings(), true, "Unabble to navigate to Settings Screen");
		} finally {
			bterror.clickReturnToApp();
			sa.assertEquals(bterror.waitforBTOffIconIcon(), true, "'BlueTooth is off' screen is not displayed");
			sa.assertAll();
			// sa.assertEquals(err.waitForErrorIcon(),false,"error message is
			// not displayed");
			// } else {
			// throw new SkipException("Skipping the testcases as the list is
			// empty");
			// }
		}

	}

	@Test(description = "Verfiy the selected reader is displayed under lock icon")
	public void verifySelectedReader() throws Exception {
		readersPage.waitForSettings();
		List<MobileElement> readersList = readersPage.getReadersList();
		if (readersList.size() > 0) {
			readersPage.clickReader(readersList.get(0));
			sa.assertEquals(readersList.get(0).getText(), readersPage.getSelectedReaderText(),
					"Selected reader text is not displayed as expected");
		} else {
			throw new SkipException("Skipping the testcases as the list is empty");
		}
		sa.assertAll();
	}

	@Test(description = "Verfiy the selected favorite reader is displayed under lock icon")
	public void verifySelectedFavReader() throws Exception {
		readersPage.waitForSettings();
		List<MobileElement> readersList = readersPage.getFavoriteReadersList();
		if (!(readersList.size() > 0)) {
			verifyFavoriteReader();
		}
		readersList = readersPage.getFavoriteReadersList();
		if (readersList.size() > 0) {
			readersPage.clickReader(readersList.get(0));
			sa.assertEquals(readersList.get(0).getText(), readersPage.getSelectedReaderText(),
					"Selected reader text is not displayed as expected");
		} else {
			throw new SkipException("Skipping the testcases as the list is empty");
		}
		sa.assertAll();
	}

	@Test(description = "Verfiy the selected reader is displayed under favorites")
	public void verifyFavoriteReader() throws Exception {
		SoftAssert sa = new SoftAssert();
		readersPage.waitForSettings();
		if (!(readersPage.getReadersList().size() > 0)) {
			navigateFromHomeToFavorites();
			fav.DeleteAllReaders();
			navigateFromFavoritesToHome();
		}
		List<MobileElement> readersList = readersPage.getReadersList();

		if (readersList.size() > 0) {
			String reader = readersList.get(0).getText();
			Thread.sleep(5000);
			readersPage.addReaderToFavorite(readersList.get(0));
			if (!readersPage.getFavoriteReaders().contains(reader)) {
				Assert.fail("selected reader is not added to favorite reader list");
			}
			readersPage.clickSettings();
			Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
			settings.clickPreferences();
			Assert.assertEquals(preferences.getHeaderText(), ObjectMap.getvalue("Preferences_Header_Txt"),
					"Unable to navigate Preferences page");
			preferences.clickFavorites();
			Assert.assertEquals(fav.getHeaderText(), ObjectMap.getvalue("Favorites_Title_Txt"),
					"Unable to navigate Favorites page");
			if (!fav.getFavoriteReaders().contains(reader)) {
				Assert.fail("selected reader is not displayed in favorite page");
			}
			fav.clickBack();
			Assert.assertEquals(preferences.getHeaderText(), ObjectMap.getvalue("Preferences_Header_Txt"),
					"Unable to navigate Preferences page");
			preferences.clickBack();
			if(config.isiOS()) {
			Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
			settings.clickCloseButton();
			}
			Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers page");
		} else {
			throw new SkipException("Skipping the testcases as the normal readers list is empty");
		}
		sa.assertAll();
	}

	
	public void navigateFromHomeToFavorites() throws Exception {
		readersPage.clickSettings();
		Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
		settings.clickPreferences();
		Assert.assertEquals(preferences.getHeaderText(), ObjectMap.getvalue("Preferences_Header_Txt"),
				"Unable to navigate Preferences page");
		preferences.clickFavorites();
		Assert.assertEquals(fav.getHeaderText(), ObjectMap.getvalue("Favorites_Title_Txt"),
				"Unable to navigate Favorites page");
	}

	public void navigateFromFavoritesToHome() throws Exception {
		fav.clickBack();
		Assert.assertEquals(preferences.getHeaderText(), ObjectMap.getvalue("Preferences_Header_Txt"),
				"Unable to navigate Preferences page");
		preferences.clickBack();
		if(config.isiOS()) {
		Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
		settings.clickCloseButton();
		}
		Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers page");
	}

	@Test(description = "Verfiy the renaming a reader")
	public void verifyRenameReader() throws Exception {
		readersPage.waitForSettings();
		navigateFromHomeToFavorites();
		fav.DeleteAllReaders();
		navigateFromFavoritesToHome();
		List<MobileElement> readersList = readersPage.getReadersList();
		if (readersList.size() > 0) {
			String reader = readersList.get(0).getText();
			readersPage.selectReaderforEdit(readersList.get(0));
			Assert.assertTrue(rename.waitforRenameHeader(), "Rename reader screen is not displayed");
			sa.assertEquals(ObjectMap.getvalue("Rename_Header_Txt"), rename.getHeadertext(), "Header Text: ");
			sa.assertEquals(ObjectMap.getvalue("Rename_Save_Txt"), rename.getSaveTxt(), "Save Text: ");
			sa.assertEquals(ObjectMap.getvalue("Rename_MyReaderName_Txt"), rename.geteditLabeltext(),
					"MyReaderName Text: ");
			sa.assertEquals(reader, rename.getEditboxText().trim(),
					"reader name is not matching with reader list screen");
			String input = RandomStringUtils.randomAlphabetic(5);
			rename.enterReaderName(input);
			rename.clickSave();
			sa.assertAll();
			Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate to reders list screen");
			if (!readersPage.getReaders().contains(input)) {
				sa.fail("Renamed reader is not displayed reader list");
			}
		} else {
			throw new SkipException("Skipping the testcases as the normal readers list is empty");
		}
		sa.assertAll();
	}

	public void renameFavReader(String ReaderName, int NumberofWords) throws Exception {
		List<MobileElement> favreadersList = readersPage.getFavoriteReadersList();
		int favreaderPosition = readersPage.getFavoriteReaders().indexOf(ReaderName);
		System.out.println("Reader Name selected : " + Element.getElementText(favreadersList.get(favreaderPosition)));
		readersPage.selectReaderforEdit(favreadersList.get(favreaderPosition));
		Assert.assertTrue(rename.waitforRenameHeader(), "Rename reader screen is not displayed");
		sa.assertEquals(ObjectMap.getvalue("Rename_Header_Txt"), rename.getHeadertext());
		sa.assertEquals(ObjectMap.getvalue("Rename_Save_Txt"), rename.getSaveTxt());
		sa.assertEquals(ObjectMap.getvalue("Rename_MyReaderName_Txt"), rename.geteditLabeltext());
		sa.assertEquals(ReaderName, rename.getEditboxText().trim(),
				"reader name is not matching with reader list screen");
		String input = null;
		switch (NumberofWords) {
		case 1:
			input = RandomStringUtils.randomAlphabetic(5);
			break;
		case 2:
			input = RandomStringUtils.randomAlphabetic(3) + " " + RandomStringUtils.randomAlphabetic(3);
			break;
		case 3:
			input = RandomStringUtils.randomAlphabetic(3) + " " + RandomStringUtils.randomAlphabetic(3) + " "
					+ RandomStringUtils.randomAlphabetic(3);
			break;
		}
		rename.enterReaderName(input);
		rename.clickSave();
	}

	@Test(description = "Verfiy the hide reader and displayed in preferences screen")
	public void verifyHideReader() throws Exception {
		readersPage.waitForSettings();
		navigateFromHomeToFavorites();
		fav.DeleteAllReaders();
		navigateFromFavoritesToHome();
		List<MobileElement> readersList = readersPage.getReadersList();
		if (readersList.size() > 0) {
			String reader = readersList.get(0).getText().trim();
			readersPage.hideReader(readersList.get(0));
			if (readersPage.getReaders().contains(reader)) {
				sa.fail("selected reader not hided from reader list");
			}
			readersPage.clickSettings();
			Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
			settings.clickPreferences();
			Assert.assertEquals(preferences.getHeaderText(), ObjectMap.getvalue("Preferences_Header_Txt"),
					"Unable to navigate Preferences page");
			preferences.clickHidden();
			Assert.assertEquals(hide.getHeaderText(), ObjectMap.getvalue("HiddenReaders_Header_Txt"),
					"Unable to navigate Hidden Readers page");
			if (!hide.getHiddenReaders().contains(reader)) {
				sa.fail("hidden reader is not displayed under hidden list");
			}
			hide.clickBack();
			Assert.assertEquals(preferences.getHeaderText(), ObjectMap.getvalue("Preferences_Header_Txt"),
					"Unable to navigate Preferences page");
			preferences.clickBack();
			Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
			settings.clickCloseButton();
			Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers page");
		} else {
			throw new SkipException("Skipping the testcases as the normal readers list is empty");
		}
		sa.assertAll();
	}

	@Test(description = "unhide all the readers")
	public void unhideAllreaders() {
		try {
			readersPage.waitForSettings();
			readersPage.clickSettings();
			Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
			settings.clickPreferences();
			Assert.assertEquals(preferences.getHeaderText(), ObjectMap.getvalue("Preferences_Header_Txt"),
					"Unable to navigate Preferences page");
			preferences.clickHidden();
			Assert.assertEquals(hide.getHeaderText(), ObjectMap.getvalue("HiddenReaders_Header_Txt"),
					"Unable to navigate Hidden Readers page");
			hide.unhideAllReaders();
			hide.clickBack();
			Assert.assertEquals(preferences.getHeaderText(), ObjectMap.getvalue("Preferences_Header_Txt"),
					"Unable to navigate Preferences page");
			preferences.clickBack();
			Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
			settings.clickCloseButton();
			Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers page");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Assert.fail();
		}
	}

	@Test(description = "unfavorite all the readers from settings screen")
	public void unFavoriteAllreaders() {
		try {
			readersPage.waitForSettings();
			navigateFromHomeToFavorites();
			fav.DeleteAllReaders();
			navigateFromFavoritesToHome();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Assert.fail();
		}
	}

	@Test(description = "Verfiy the renaming a favorite reader")
	public void verifyHideFavoriteReader() throws Exception {
		readersPage.waitForSettings();
		List<MobileElement> readersList = readersPage.getFavoriteReadersList();
		if (!(readersList.size() > 0)) {
			verifyFavoriteReader();
			readersList = readersPage.getFavoriteReadersList();
		}
		if (readersList.size() > 0) {
			String reader = readersList.get(0).getText();
			readersPage.hideReader(readersList.get(0));
			if (readersPage.getFavoriteReaders().contains(reader)) {
				sa.fail("selected reader not hided from fav reader list");
			}
			readersPage.clickSettings();
			Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
			settings.clickPreferences();
			Assert.assertEquals(preferences.getHeaderText(), ObjectMap.getvalue("Preferences_Header_Txt"),
					"Unable to navigate Preferences page");
			preferences.clickHidden();
			Assert.assertEquals(hide.getHeaderText(), ObjectMap.getvalue("HiddenReaders_Header_Txt"),
					"Unable to navigate Hidden Readers page");
			if (!hide.getHiddenReaders().contains(reader)) {
				sa.fail("hidden reader is not displayed under hidden list");
			}
			hide.clickBack();
			Assert.assertEquals(preferences.getHeaderText(), ObjectMap.getvalue("Preferences_Header_Txt"),
					"Unable to navigate Preferences page");
			preferences.clickBack();
			Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
			settings.clickCloseButton();
			Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers page");
		} else {
			throw new SkipException("Skipping the testcases as the normal readers list is empty");
		}
		sa.assertAll();
	}

	@Test(description = "Verfiy the Searching text is displayed if there are no reders in range") // slider is not
																									// working
	public void verifyOutofRangeReaders() throws Exception {
		try {
			readersPage.waitForSettings();
			setSnsitivityto(0);
//			readersPage.clickSettings();
//			Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
//			settings.clickPreferences();
//			Assert.assertEquals(preferences.getHeaderText(), ObjectMap.getvalue("Preferences_Header_Txt"),
//					"Unable to navigate Preferences page");
//			preferences.clickSensitivity();
//			Thread.sleep(3000);
//			Assert.assertEquals(sensitivity.getTitleText(), ObjectMap.getvalue("Sensitivity_Title_Txt"),
//					"Unable to navigate Sensitivity page");
//			sensitivity.setMinvalToOverallSlider();
//			sa.assertEquals(sensitivity.getOverallSliderVal(), "0%",
//					"sensitivity for overall slider is not set to minimum");
//			sensitivity.clickBack();
//			Assert.assertEquals(preferences.getHeaderText(), ObjectMap.getvalue("Preferences_Header_Txt"),
//					"Unable to navigate Preferences page");
//			preferences.clickBack();
//			Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
//			settings.clickCloseButton();
			sa.assertTrue(readersPage.isSearching());
			Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers page");
			sa.assertAll();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Assert.fail();
		}
	}

	@Test(description = "Verfiy readers are displayed on in range")
	public void verifyReadersAfterInrange() throws Exception {
		try {
//			verifyOutofRangeReaders();
			setSnsitivityto(60);
			sa.assertFalse(readersPage.isSearching());
			Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers page");
			sa.assertAll();
		} catch (Exception e) {
// TODO Auto-generated catch block
			e.printStackTrace();
			Assert.fail();
		}
	}

	public void setSnsitivityto(int Percentage) {
		try {
			readersPage.clickSettings();
			Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
			settings.clickPreferences();
			Assert.assertEquals(preferences.getHeaderText(), ObjectMap.getvalue("Preferences_Header_Txt"),
					"Unable to navigate Preferences page");
			preferences.clickSensitivity();
			Thread.sleep(3000);
			Assert.assertEquals(sensitivity.getTitleText(), ObjectMap.getvalue("Sensitivity_Title_Txt"),
					"Unable to navigate Sensitivity page");
			sensitivity.setOverallSliderValue(Percentage);
//			sa.assertEquals(sensitivity.getOverallSliderVal(), "60%",
//					"sensitivity for overall slider is not set to 60%");
			sensitivity.clickBack();
			Assert.assertEquals(preferences.getHeaderText(), ObjectMap.getvalue("Preferences_Header_Txt"),
					"Unable to navigate Preferences page");
			preferences.clickBack();
			if(config.isiOS()) {
			Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
			settings.clickCloseButton();
			Thread.sleep(20000);
			}
//			sa.assertFalse(readersPage.isSearching());
			Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers page");
//			sa.assertAll();
		} catch (Exception e) {
// TODO Auto-generated catch block
			e.printStackTrace();
			Assert.fail();
		}
	}

	@Test(description = "Verfiy the renaming a favorite reader")
	public void verifyRenameFavoriteReader() throws Exception {
		readersPage.waitForSettings();
		List<MobileElement> readersList = readersPage.getFavoriteReadersList();
		if (!(readersList.size() > 0)) {
			verifyFavoriteReader();
			readersList = readersPage.getFavoriteReadersList();
		}
		if (readersList.size() > 0) {
			String reader = readersList.get(0).getText();
			readersPage.selectReaderforEdit(readersList.get(0));
			Assert.assertTrue(rename.waitforRenameHeader(), "Rename reader screen is not displayed");
			sa.assertEquals(reader, rename.getEditboxText().trim(),
					"reader name is not matching with reader list screen");
			String input = RandomStringUtils.randomAlphabetic(3) + " " + RandomStringUtils.randomAlphabetic(3);
			rename.enterReaderName(input);
			rename.clickSave();
			Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate to reders list screen");
			if (!(readersPage.getFavoriteReaders().contains(input))) {
				sa.fail("Renamed reader is not displayed in favorite reader list");
			}
		} else {
			throw new SkipException("Skipping the testcases as the normal readers list is empty");
		}
		sa.assertAll();
	}

	// Not applicable for 2.1.5
	@Test(description = "Verfiy swaping a favorite reader")
	public void verifySwapFavoriteReader() throws Exception {
		readersPage.waitForSettings();
		while (readersPage.getFavoriteReadersList().size() < 2) {
			if (readersPage.getReadersList().size() > 0) {
				verifyFavoriteReader();
			} else
				break;
		}
		List<MobileElement> readersList = readersPage.getFavoriteReadersList();
		// if (!(readersList.size() > 0)) {
		// verifyFavoriteReader();
		// readersList = readersPage.getFavoriteReadersList();
		// }
		if (readersList.size() > 1) {
			String reader1 = readersList.get(0).getText();
			String reader2 = readersList.get(1).getText();
			readersPage.swapReaders(reader1, reader2);
			sa.assertEquals(reader2, readersPage.getFavoriteReaders().get(0), "favorite order is not changed");
		} else {
			throw new SkipException("Skipping the testcases as the favourite readers list is empty/only one reader");
		}
		sa.assertAll();
	}

	// Not applicable for 2.1.5
	@Test(description = "Verfiy the quick link enabled readers are displayed with quick link icon")
	public void verifyQuicklinkFavoriteReader() throws Exception {
		readersPage.waitForSettings();
		readersPage.clearallFavReaders();
		List<MobileElement> readersList = readersPage.getFavoriteReadersList();
		if (!(readersList.size() > 0)) {
			verifyFavoriteReader();
		}
		readersList = readersPage.getFavoriteReadersList();
		if (readersList.size() > 0) {
			String reader = readersList.get(0).getText();
			// readersPage.
			readersPage.quicklinkFavReader(readersList.get(0));
			// Thread.sleep(20000);
			// sa.assertTrue(readersPage.isQuicConnecting(0), reader +"is not displayed with
			// quick connecting");
			// sa.assertTrue(readersPage.isQuicConnectReady(0), reader +"is not displayed
			// with quick connect ready");
			sa.assertTrue(readersPage.isQuicConnectEnabled(0), reader + "iis not displayed with quick connect enabled");
		} else {
			throw new SkipException("Skipping the testcases as the normal readers list is empty");
		}
		sa.assertAll();
	}

	// Not applicable for 2.1.5
	@Test(description = "Verfiy  Un-link for favorite readers")
	public void verifyUnlinkFavoriteReader() throws Exception {
		verifyQuicklinkFavoriteReader();
		List<MobileElement> readersList = readersPage.getFavoriteReadersList();
		if (readersList.size() > 0) {
			String reader = readersList.get(0).getText();
			// readersPage.
			readersPage.unlinkFavReader(readersList.get(0));
			// Thread.sleep(20000);
			// sa.assertTrue(readersPage.isQuicConnecting(0), reader +"is not displayed with
			// quick connecting");
			// sa.assertTrue(readersPage.isQuicConnectReady(0), reader +"is not displayed
			// with quick connect ready");
			sa.assertFalse(readersPage.isQuicConnectEnabled(0),
					reader + "iis not displayed with quick connect enabled");
		} else {
			throw new SkipException("Skipping the testcases as the normal readers list is empty");
		}
		sa.assertAll();
	}

	@Test(description = "Verfiy the selected reader is unlocked after selecting lock icon")
	public void verifyUnlockReader() throws Exception {
		readersPage.waitForSettings();
		navigateFromHomeToFavorites();
		fav.DeleteAllReaders();
		navigateFromFavoritesToHome();
		List<MobileElement> readersList = readersPage.getReadersList();
		if (readersList.size() > 0) {
			readersPage.clickReader(readersList.get(0));
			sa.assertEquals(readersList.get(0).getText(), readersPage.getSelectedReaderText(),
					"Selected reader text is not displayed as expected");
		} else {
			throw new SkipException("Skipping the testcases as the list is empty");
		}
		readersPage.clickUnlockBtn();
		// sa.assertTrue(readersPage.waitForAnimation(), "Animation is not displayed");
		// sa.assertEquals(readersPage.getDoorStatus(),
		// ObjectMap.getvalue("status_unclocking"),
		// "Unlocking text is expected");
		sa.assertEquals(readersPage.getSelectedReaderText(), readersList.get(0).getText(),
				"Selected reader text is not displayed during unlocking");
		// Thread.sleep(3000);
		// sa.assertEquals(readersPage.getDoorStatus(),
		// ObjectMap.getvalue("status_unclocked"));

		sa.assertAll();
	}

	@Test(description = "Verfiy the user able to perform unlocking operation")
	public void verifyCancelUnlockOperation() throws Exception {
		readersPage.waitForSettings();
		navigateFromHomeToFavorites();
		fav.DeleteAllReaders();
		navigateFromFavoritesToHome();
		Thread.sleep(3000);
		// List<MobileElement> readersList = readersPage.getReadersList();
		// if (readersList.size() > 0) {
		// readersPage.clickReader(readersList.get(0));
		// sa.assertEquals(readersList.get(0).getText(),
		// readersPage.getSelectedReaderText(),
		// "Selected reader text is not displayed as expected");
		// } else {
		// throw new SkipException("Skipping the testcases as the list is empty");
		// }
		verifySelectedReader();
		readersPage.clickUnlockBtn();
		// sa.assertTrue(readersPage.waitForAnimation(),"Animation is not displayed");
		// sa.assertEquals(readersPage.getDoorStatus(),
		// ObjectMap.getvalue("status_unclocking"),"Unlocking message is not
		// displayed");
		// sa.assertEquals(readersList.get(0).getText(),
		// readersPage.getSelectedReaderText(),
		// "Selected reader text is not displayed during unlocking");
		readersPage.clickUnlockBtn();
		Assert.assertTrue(err.waitForErrorHintIcon(), "error icon is not displayed");
		sa.assertEquals(err.getErrorHintTitle(), ObjectMap.getvalue("errormessage_UnlockCancelled"),
				"error message is not valid");
		sa.assertAll();
	}

	@Test(description = "Verfiy the user able to cancel unlocking favorite door")
	public void verifyCancelUnlockFavorite() throws Exception {
		List<MobileElement> readersList = readersPage.getFavoriteReadersList();
		if (!(readersList.size() > 0)) {
			verifyFavoriteReader();
			readersList = readersPage.getFavoriteReadersList();
		}
		Thread.sleep(3000);
		readersPage.clickUnlockBtn();
		// sa.assertTrue(readersPage.waitForAnimation(),"Animation is not displayed");
		// sa.assertEquals(readersPage.getDoorStatus(),
		// ObjectMap.getvalue("status_unclocking"),"Unlocking message is not
		// displayed");
		// sa.assertEquals(readersList.get(0).getText(),
		// readersPage.getSelectedReaderText(),
		// "Selected reader text is not displayed during unlocking");
		readersPage.clickUnlockBtn();
		Assert.assertTrue(err.waitForErrorHintIcon(), "error icon is not displayed");
		sa.assertEquals(err.getErrorHintTitle(), ObjectMap.getvalue("errormessage_UnlockCancelled"),
				"error message is not valid");
		sa.assertAll();
	}

	// Not applicable for 2.1.5
	@Test(description = "Verfiy unlock cancelled fail message is displayed unlocking operation")
	public void verifyCancelFail() throws Exception {
		// readersPage.waitForSettings();
		// List<MobileElement> readersList = readersPage.getReadersList();
		// if (readersList.size() > 0) {
		// readersPage.clickReader(readersList.get(0));
		// sa.assertEquals(readersList.get(0).getText(),
		// readersPage.getSelectedReaderText(),
		// "Selected reader text is not displayed as expected");
		// } else {
		// throw new SkipException("Skipping the testcases as the list is empty");
		// }
		verifySelectedReader();
		readersPage.clickUnlockBtn();
		Thread.sleep(300);
		// sa.assertTrue(readersPage.waitForAnimation(),"Animation is not displayed");
		// sa.assertEquals(readersPage.getDoorStatus(),
		// ObjectMap.getvalue("status_unclocking"),"Unlocking message is not
		// displayed");
		// sa.assertEquals(readersList.get(0).getText(),
		// readersPage.getSelectedReaderText(),
		// "Selected reader text is not displayed during unlocking");
		readersPage.clickUnlockBtn();
		Assert.assertTrue(err.waitForErrorHintIcon(), "error icon is not displayed");
		sa.assertEquals(err.getErrorHintTitle(), ObjectMap.getvalue("errormessage_CancelFailed"),
				"error message is not valid");
		sa.assertAll();
	}

	@Test(description = "Perform BlueTooth off during unlocking operation")
	public void verifyBToffUnlock() throws Exception {
		readersPage.waitForSettings();
		navigateFromHomeToFavorites();
		fav.DeleteAllReaders();
		navigateFromFavoritesToHome();
		verifySelectedReader();
		readersPage.clickUnlockBtn();
		verifyReaderListOnBTOff();
	}

	@Test(description = "Verfiy user can unpin any favorite reader")
	public void verifyFavoriteReaderUnpin() throws Exception {
		readersPage.waitForSettings();
		List<MobileElement> readersList = readersPage.getFavoriteReadersList();
		if (!(readersList.size() > 0)) {
			verifyFavoriteReader();
		}
		readersList = readersPage.getFavoriteReadersList();
		if (readersList.size() > 0) {
			String reader = readersList.get(0).getText();
			// readersPage.
			readersPage.removeReaderfromFavorite(readersList.get(0));
			// Thread.sleep(20000);
			if (!readersPage.getReaders().contains(reader)) {
				sa.fail("selected reader is not added to favorite reader list");
			}
			readersPage.clickSettings();
			Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
			settings.clickPreferences();
			Assert.assertEquals(preferences.getHeaderText(), ObjectMap.getvalue("Preferences_Header_Txt"),
					"Unable to navigate Preferences page");
			preferences.clickFavorites();
			Assert.assertEquals(fav.getHeaderText(), ObjectMap.getvalue("Favorites_Title_Txt"),
					"Unable to navigate Favorites page");
			if (fav.getFavoriteReaders().contains(reader)) {
				Assert.fail("un fav reader is displayed in favorite page");
			}
			fav.clickBack();
			Assert.assertEquals(preferences.getHeaderText(), ObjectMap.getvalue("Preferences_Header_Txt"),
					"Unable to navigate Preferences page");
			preferences.clickBack();
			Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
			settings.clickCloseButton();
			Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers page");

		} else {
			throw new SkipException("Skipping the testcases as the normal readers list is empty");
		}
		sa.assertAll();
	}

	@Test(description = "Verfiy the reader list is displayed on turning on the device bluetooth from off state")
	public void verifyReaderListOnBTOn() throws Exception {
		readersPage.disableDeviceBluetooth();
		readersPage.enableDeviceBluetooth();
		sa.assertTrue(readersPage.waitForSettings(), "Unable to navigate to readers screen");
		sa.assertFalse(err.waitForErrorHintIcon(), "Error icon is displayed");
		Thread.sleep(50000);
		if (!(readersPage.getReadersList().size() > 0)) {
			sa.fail("Readers list should not be empty");
		}
		sa.assertAll();
	}

	@Test
	public void navigateToCredentialsPage() {
		try {
			readersPage.waitForSettings();
			readersPage.clickSettings();
			Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
			settings.clickCredentials();
			Assert.assertTrue(credentials.waitforCredentialsHeader(), "Unable to navigate Credentials page");
			sa.assertEquals(ObjectMap.getvalue("Credentials_Header_Txt"), credentials.getHeaderText());
//			sa.assertEquals(ObjectMap.getvalue("Credentials_CompanyInformation_Txt"),
//					credentials.getCompanyInformationTxt());
			sa.assertEquals(ObjectMap.getvalue("Credentials_CredentialID_Txt"), credentials.getCredentialIDTxt());
			// sa.assertEquals(ObjectMap.getvalue("Credentials_Select_Txt"),credentials.getSelectTxt());
			credentials.clickBack();
			sa.assertAll();
			Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
			settings.clickCloseButton();
			Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers page");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Assert.fail();
		}
	}

	@Test(description = "Verfiy update success meesage after complete of sync")
	public void verifyUpdateCredentials() {
		try {
			credentials.enableDeviceWifi();
			readersPage.waitForSettings();
			readersPage.clickSettings();
			Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
			settings.clickCredentials();
			Assert.assertTrue(credentials.waitforCredentialsHeader(), "Unable to navigate Credentials page");
			credentials.clickUpdateCredentials();
			sa.assertTrue(credentials.waitforLoadingIndicator(),
					"Loading Indicator is not displayed after clicking Update Credentials");
			sa.assertEquals(ObjectMap.getvalue("update_updatingtxt"), credentials.getUpdatingCredentialsMsg(),
					"Updating meesage");
			credentials.waitforLoaderDismiss();
//			sa.assertEquals(credentials.getUpdatingCredentialsMsg(), ObjectMap.getvalue("update_successMessage"),
//					"update failed");
			credentials.clickBack();
			sa.assertAll();
			Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
			settings.clickCloseButton();
			Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers page");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Assert.fail();
		}
	}

	@Test(description = "Verfiy update fail meesage when the device wi-fi is disabled")
	public void verifyUpdateCredentialFail() {
		try {
			readersPage.waitForSettings();
			readersPage.clickSettings();
			Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
			settings.clickCredentials();
			Assert.assertTrue(credentials.waitforCredentialsHeader(), "Unable to navigate Credentials page");
			credentials.disableDeviceWifi();
			credentials.clickUpdateCredentials();
//			 sa.assertTrue(credentials.waitforLoadingIndicator(),
//			 "Loading Indicator is not displayed after clicking Update Credentials");
			credentials.waitforLoaderDismiss();
			if (err.waitForErrorHintIcon()) {
				err.clickErrorHintIcon();
				Gestures.clickScreenWindow();
			} else {
				sa.fail("error hint icon is not displayed");
			}
			sa.assertEquals(credentials.getUpdatingCredentialsMsg(), ObjectMap.getvalue("update_failMessage"),
					"update failed message is not displayed");
			credentials.clickBack();
			Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
			settings.clickCloseButton();
			Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers page");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Assert.fail();
		}
//		finally {
//			try {
//				credentials.disableDeviceWifi();
//			} catch (Exception e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}
	}

	@Test(description = "Verfiy update error hint description is displayed on selecting error hint icon")
	public void verifyCredentialFailDescription() {
		try {
			readersPage.waitForSettings();
			readersPage.clickSettings();
			Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
			settings.clickCredentials();
			Assert.assertTrue(credentials.waitforCredentialsHeader(), "Unable to navigate Credentials page");
			credentials.disableDeviceWifi();
			credentials.clickUpdateCredentials();
//			 sa.assertTrue(credentials.waitforLoadingIndicator(),
//			 "Loading Indicator is not displayed after clicking Update Credentials");
			credentials.waitforLoaderDismiss();
			sa.assertEquals(credentials.getUpdatingCredentialsMsg(), ObjectMap.getvalue("update_failMessage"),
					"update failed message is not displayed");
			if (err.waitForErrorHintIcon()) {
				err.clickErrorHintIcon();
				sa.assertTrue(err.isErrorDescription(), "error description is not displayed");
				sa.assertEquals(err.getErrorDescription(), ObjectMap.getvalue("update_failDescription"));
				Gestures.clickScreenWindow();
			} else {
				sa.fail("error hint icon is not displayed");
			}
			credentials.clickBack();
			Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
			settings.clickCloseButton();
			Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers page");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Assert.fail();
		}
	}

	@Test(description = "Verfiy user able to enter text in credential screen text field")
	public void verifyCredentialName() {
		try {
			readersPage.waitForSettings();
			readersPage.clickSettings();
			Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
			settings.clickCredentials();
			Assert.assertTrue(credentials.waitforCredentialsHeader(), "Unable to navigate Credentials page");
			credentials.clickEditButton();
			sa.assertTrue(GenericFunctions.getInstance().isKeyboard(), "keyboard is not displayed");
			credentials.enterCredentailName("test");
			sa.assertEquals(credentials.getCredentialName(), "test", "credential name is not updated as expected");
			credentials.clickBack();
			Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
			settings.clickCloseButton();
			Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers page");
			sa.assertAll();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Assert.fail();
		}
	}

	// @Test
	// public void navigateToCredentialDetailsPage() {
	// try {
	// readersPage.waitForSettings();
	// readersPage.clickSettings();
	// Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate
	// Settings page");
	// settings.clickCredentials();
	// Assert.assertTrue(credentials.waitforCredentialsHeader(), "Unable to navigate
	// Credentials page");
	// credentials.clickBadgeNumber();
	// ;
	// Assert.assertTrue(credentialDetails.waitforCredentialDetailsHeader(),
	// "Unable to navigate CredentialDetails page");
	// credentialDetails.clickBack();
	// Assert.assertTrue(credentials.waitforCredentialsHeader(), "Unable to navigate
	// Credentials page");
	// credentials.clickBack();
	// Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate
	// Settings page");
	// settings.clickCloseButton();
	// Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers
	// page");
	// } catch (Exception e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// Assert.fail();
	// }
	// }

	@Test(description = "59535: Verfiy dragged reader is removed from favorite reader and added to the pathway list "
			+ "59536: Deleted reader from pathway list is added back to favourite" + "59313" + "59314" + "58335"
			+ "58339" + "58342" + "")
	public void verifyDragDrop() {
		try {
			readersPage.waitForSettings();
			List<MobileElement> favreadersList = readersPage.getFavoriteReadersList();
			if (!(favreadersList.size() > 0)) {
				verifyFavoriteReader();
			}
			deletePathway();
			readersPage.clickPathwayIcon();
			Assert.assertTrue(welcome.waitforPathwayWelcomeTitle(), "Unable to navigate PathwayWelcomeTitle page");
			welcome.clickbtnGetStarted();
			Thread.sleep(1000);
			// Assert.assertTrue(dragDrop.waitfordragAndDropHint(), "Unable to navigate Drag
			// and Drop page");
			List<String> favouriteReaders = dragDrop.getFavouriteReaderNames();
			String favReader = favouriteReaders.get(0);
			dragDrop.addReaderToPathway(favReader);
			sa.assertFalse(dragDrop.VerifyFavoriteReaderList(favReader),
					"Favorite reader is not removed from the list");
			sa.assertTrue(dragDrop.VerifyPathwayReaderList(favReader),
					"Favorite reader is not added to the pathway list");
			String pathwayReader = dragDrop.getPathwayReaderNames().get(0);
			dragDrop.deleteReaderfromPathway(pathwayReader);
			sa.assertFalse(dragDrop.VerifyPathwayReaderList(pathwayReader),
					"pathway reader is not removed from the pathway list");
			sa.assertTrue(dragDrop.VerifyFavoriteReaderList(favReader),
					"pathway reader is not added to favourite list");
			dragDrop.clickClose();
			Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers page");
			sa.assertAll();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Assert.fail();
		}
	}

	@Test(description = "58334: Verify user can able to add the reader from favorites to pathway"
			+ "58338 : Verify added reader is displayed with single letter")
	public void addReadertoPathway() {
		try {
			readersPage.waitForSettings();
			// List<MobileElement> favreadersList = readersPage.getFavoriteReadersList();
			// if (!(favreadersList.size() > 0)) {
			deletePathway();
			verifyFavoriteReader();
			// }
			readersPage.clickPathwayIcon();
			Assert.assertTrue(welcome.waitforPathwayWelcomeTitle(), "Unable to navigate PathwayWelcomeTitle page");
			welcome.clickbtnGetStarted();
			Thread.sleep(1000);
			// Assert.assertTrue(dragDrop.waitfordragAndDropHint(), "Unable to navigate Drag
			// and Drop page");
			List<String> favouriteReaders = dragDrop.getFavouriteReaderNames();
			String favReader = favouriteReaders.get(0);
			dragDrop.addReaderToPathway(favReader);
			sa.assertFalse(dragDrop.VerifyFavoriteReaderList(favReader),
					"Favorite reader is not removed from the list");
			sa.assertTrue(dragDrop.VerifyPathwayReaderList(favReader),
					"Favorite reader is not added to the pathway list");
			dragDrop.clickClose();
			Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers page");
			sa.assertAll();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Assert.fail();
		}
	}

	@Test(description = "58334: Verify user can able to add the reader from favorites to pathway"
			+ "58338 : Verify added reader is displayed with single letter")
	public void addReaderbetweenPathway() {
		try {
			readersPage.waitForSettings();
			while (readersPage.getFavoriteReadersList().size() < 2) {
				if (readersPage.getReadersList().size() > 0) {
					verifyFavoriteReader();
				} else
					break;
			}
			renameFavReader(readersPage.getFavoriteReaders().get(0), 2);
			// renameFavReader(readersPage.getFavoriteReaders().get(1), 2);
			// renameFavReader(readersPage.getFavoriteReaders().get(2), 3);
			deletePathway();
			readersPage.clickPathwayIcon();
			// Assert.assertTrue(welcome.waitforPathwayWelcomeTitle(), "Unable to navigate
			// PathwayWelcomeTitle page");
			welcome.clickbtnGetStarted();
			pathmanage.clickbtnCreatePathway();
			Thread.sleep(1000);
			Assert.assertTrue(dragDrop.waitforbtnFinish(), "Unable to navigate Drag and Drop page");
			List<String> favouriteReaders = dragDrop.getFavouriteReaderNames();
			String favReader = favouriteReaders.get(0);
			String favReader1 = favouriteReaders.get(1);
			// String favReader2 = favouriteReaders.get(2);
			dragDrop.addReaderToPathway(favReader);
			sa.assertFalse(dragDrop.VerifyFavoriteReaderList(favReader),
					"Favorite reader is not removed from the list");
			sa.assertTrue(dragDrop.VerifyPathwayReaderList(favReader),
					"Favorite reader is not added to the pathway list");
			sa.assertTrue(dragDrop.isbtnFinishEnabled(), "Finish button should be enabled");
			dragDrop.addReaderToPathway(favReader1);
			sa.assertFalse(dragDrop.VerifyFavoriteReaderList(favReader1),
					"Favorite reader is not removed from the list");
			sa.assertTrue(dragDrop.VerifyPathwayReaderList(favReader1),
					"Favorite reader is not added to the pathway list");
			// dragDrop.addReaderToPathway(favReader2,1);
			dragDrop.swapReaders(favReader, favReader1);
			List<String> dragNdDropPathwaylist = new ArrayList<>();
			dragNdDropPathwaylist.add(favReader1);
			// dragNdDropPathwaylist.add(favReader2);
			dragNdDropPathwaylist.add(favReader);
			dragDrop.clickbtnFinish();
			Assert.assertTrue(pathcreate.waitforbtnSave(), "Unable to navigate to create pathway screen");
			String PathwayName = RandomStringUtils.randomAlphabetic(5) + " Automation";
			pathcreate.enterPathwayName(PathwayName);
			String PathwayTime = "20 minutes";
			pathcreate.setTime(PathwayTime);
			sa.assertEquals(PathwayTime, pathcreate.getlblPathTimerValueText(),
					"Pathway Timer is not chaged/ set correctly");
			sa.assertTrue(pathcreate.verifyOrderOfReaders(dragNdDropPathwaylist), "Not matched");
			sa.assertTrue(pathcreate.isbtnSaveEnabled(), "Save button is not enabled");
			pathcreate.clickbtnSave();
			// pathcreate.clickClose();
			// Assert.assertTrue(dragDrop.waitforbtnFinish(), "Unable to navigate Drag and
			// Drop page");
			// dragDrop.clickClose();
			if(GenericFunctions.isIOS())
			GenericFunctions.declineAlert();
			Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers page");
			readersPage.clickFavouriteReader(favReader1);
			sa.assertTrue(readersPage.isStartPathwayVisible(), "Start pathway button is not visible");
			sa.assertEquals(ObjectMap.getvalue("ReadersList_txt_StartPathway") + " " + PathwayName,
					readersPage.getTextFromStartPathway(), "pathway name is not matching with create pathway screen");
			readersPage.clickBtnStartPathway();
			Thread.sleep(1000);
			int expectedTime = Integer.parseInt(readersPage.getTextFromStartPathway().split("\\:")[1].trim());
			int time = Integer.parseInt(PathwayTime.split("\\s")[0].trim()) - 1;
			sa.assertEquals(time, expectedTime, "Time after starting pathway does not match with pathway time");
			sa.assertFalse(readersPage.isPathwayIconVisible(),
					"Pahway icon should not be displayed after starting the pathway");
			sa.assertTrue(readersPage.isimgCancelPathwayVisible(), "Cancel pathway button is not visible");
			readersPage.clickimgCancelPathway();
			Gestures.clickScreenWindow();
			// Thread.sleep(1000);
			sa.assertTrue(readersPage.isPathwayIconVisible(),
					"Pahway icon should be displayed after cancelling/Completing the pathway");
			sa.assertFalse(readersPage.isimgCancelPathwayVisible(),
					"Cancel pathway button should not be displayed after cancelling/Completing the pathway");
			navigateToSettingsPathway();
			sa.assertTrue(pathSetting.getPathwayNames().contains(PathwayName),
					"created pathway name is displayed in settings page");
			navigateFromSettingsPathwaytoMainScreen();
			sa.assertAll();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Assert.fail();
		}
	}

	public static String pathwayName;
	public static String pathwayTime;
	public static String startPathwyaReader;
	public static String secondPathwyaReader;

	
	public void createPathway(int count) throws Exception {
		SoftAssert sa = new SoftAssert();
		if (readersPage.getFavoriteReadersList().size() + readersPage.getReadersList().size() >= count) {
			while (readersPage.getFavoriteReadersList().size() < count) {
				if (readersPage.getReadersList().size() > 0) {
					verifyFavoriteReader();
				} else
					break;
			}
			readersPage.clickPathwayIcon();
			// Assert.assertTrue(welcome.waitforPathwayWelcomeTitle(), "Unable to navigate
			// PathwayWelcomeTitle page");
			welcome.clickbtnGetStarted();
			pathmanage.clickbtnCreatePathway();
			Thread.sleep(1000);
			Assert.assertTrue(dragDrop.waitforbtnFinish(), "Unable to navigate Drag and Drop page");
			List<String> favouriteReaders = dragDrop.getFavouriteReaderNames();
			startPathwyaReader = favouriteReaders.get(count - 1);
			// secondPathwyaReader = favouriteReaders.get(1);
			dragDrop.addReaderToPathway(startPathwyaReader);
			sa.assertFalse(dragDrop.VerifyFavoriteReaderList(startPathwyaReader),
					"Favorite reader is not removed from the list");
			sa.assertTrue(dragDrop.VerifyPathwayReaderList(startPathwyaReader),
					"Favorite reader is not added to the pathway list");
			sa.assertTrue(dragDrop.isbtnFinishEnabled(), "Finish button should be enabled");
			// dragDrop.addReaderToPathway(secondPathwyaReader);
			// sa.assertFalse(dragDrop.VerifyFavoriteReaderList(secondPathwyaReader),
			// "Favorite reader is not removed from the list");
			// sa.assertTrue(dragDrop.VerifyPathwayReaderList(secondPathwyaReader),
			// "Favorite reader is not added to the pathway list");
			List<String> dragNdDropPathwaylist = new ArrayList<>();
			dragNdDropPathwaylist.add(startPathwyaReader);
			// dragNdDropPathwaylist.add(secondPathwyaReader);
			dragDrop.clickbtnFinish();
			Assert.assertTrue(pathcreate.waitforbtnSave(), "Unable to navigate to create pathway screen");
			pathwayName = RandomStringUtils.randomAlphabetic(5) + " Automation";
			pathcreate.enterPathwayName(pathwayName);
			pathwayTime = "20 "+ObjectMap.getvalue("Pathway_timer_minutes_txt");
			pathcreate.setTime(pathwayTime);
			String StartingReader = pathcreate.getPathwayReaderNames().get(0);
			sa.assertEquals(pathwayTime, pathcreate.getlblPathTimerValueText(),
					"Pathway Timer is not chaged/ set correctly");
			sa.assertTrue(pathcreate.verifyOrderOfReaders(dragNdDropPathwaylist), "Not matched");
			sa.assertTrue(pathcreate.isbtnSaveEnabled(), "Save button is not enabled");
			pathcreate.clickbtnSave();
			GenericFunctions.declineAlert();
			Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers page");
			readersPage.clickFavouriteReader(startPathwyaReader);
			//adding 2.3 validation
			sa.assertTrue(readerHnF.isDottedimgDisplayed(),"dotted is not displayed in footer");
			readerHnF.Swipefooter();
			sa.assertTrue(readerHnF.isPathwayimgDisplayed(),"pathway icon is not displayed");
			sa.assertEquals(readerHnF.getFooterPathwayStatus(), ObjectMap.getvalue("status_pathwaystart"));
			sa.assertEquals(readerHnF.getpathwayName(), pathwayName);
			sa.assertEquals(readerHnF.getstartingReaderName(), ObjectMap.getvalue("status_pathwaystartingat")+" "+StartingReader);
			sa.assertAll();
		} else {
			throw new SkipException(
					"Skipping the testcase as the favorite readers are less to create a pathway given with count"
							+ count);
		}
	}

	@Test(description = "Verify user able to start pathway from action menu")
	public void startPathwayfromActionMenu() throws Exception {
		readersPage.waitForSettings();
		deletePathway();
		createPathway(1);
		Thread.sleep(2000);
		readersPage.clickFavouriteReader(startPathwyaReader);
		sa.assertTrue(readersPage.isStartPathwayVisible(), "Start pathway button is not visible");
		sa.assertEquals(ObjectMap.getvalue("ReadersList_txt_StartPathway") + " " + pathwayName,
				readersPage.getTextFromStartPathway(), "pathway name is not matching with create pathway screen");
		readersPage.startPathway(startPathwyaReader);
		Thread.sleep(1000);
		int expectedTime = Integer.parseInt(readersPage.getTextFromStartPathway().split("\\:")[1].trim());
		int time = Integer.parseInt(pathwayTime.split("\\s")[0].trim()) - 1;
		sa.assertEquals(time, expectedTime, "Time after starting pathway does not match with pathway time");
		sa.assertFalse(readersPage.isPathwayIconVisible(),
				"Pahway icon should not be displayed after starting the pathway");
		sa.assertTrue(readersPage.isimgCancelPathwayVisible(), "Cancel pathway button is not visible");
		if (readersPage.isimgCancelPathwayVisible())
			readersPage.clickimgCancelPathway();
		Thread.sleep(2000);
		sa.assertAll();
	}

	@Test(description = "Verify user able to start pathway from Manage pathwy screen")
	public void startPathwayfromManageScreen() throws Exception {
		readersPage.waitForSettings();
		deletePathway();
		createPathway(1);
		readersPage.clickPathwayIcon();
		Assert.assertTrue(pathmanage.waitforManagePathwayTitle(), "Unable to navigate to ManagePathway Screen");
//		Assert.assertTrue(pathmanage.getPathwayNames().contains(pathwayName));
		pathmanage.clickPathway(pathwayName);
		Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers page");
		sa.assertFalse(readersPage.isPathwayIconVisible(),
				"Pahway icon should not be displayed after starting the pathway");
//		sa.assertTrue(readersPage.isimgCancelPathwayVisible(), "Cancel pathway button is not visible");
//		int expectedTime = Integer.parseInt(readersPage.getTextFromStartPathway().split("\\:")[1].trim());
//		int time = Integer.parseInt(pathwayTime.split("\\s")[0].trim()) - 1;
//		String expectedName = readersPage.getTextFromStartPathway().split("\\:")[0].trim();
//		sa.assertEquals(time, expectedTime, "Time after starting pathway does not match with pathway time");
//		sa.assertEquals(pathwayName, expectedName,
//				"pathway name after starting pathway does not match with create pathway name");
		readersPage.clickimgCancelPathway();
		sa.assertAll();
	}

	public static String pathwayEditedName;
	public static String pathwayEditedTime;

	@Test(description = "Verify user able to start pathway from Manage pathwy screen")
	public void editPathwayfromManageScreen() throws Exception {
		readersPage.waitForSettings();
		deletePathway();
//		readersPage.clickPathwayIcon();
		createPathway(1);
		readersPage.clickPathwayIcon();
		Assert.assertTrue(pathmanage.waitforManagePathwayTitle(), "Unable to navigate to ManagePathway Screen");
		Assert.assertTrue(pathmanage.getPathwayNames().contains(pathwayName));
		pathmanage.clickbtnManagePathway();
		Assert.assertEquals(pathSetting.getHeaderText(), ObjectMap.getvalue("Pathways_Header_Txt"),
				"Unable to navigate Pathways page");
		Assert.assertTrue(pathSetting.getPathwayNames().contains(pathwayName),
				"created pathway name is displayed in settings page");
		pathSetting.clickEditIcon(pathSetting.getPathwayNames().indexOf(pathwayName));
		Assert.assertTrue(pathcreate.waitforbtnSave(), "Unable to navigate to create pathway screen");
		pathwayEditedName = RandomStringUtils.randomAlphabetic(5) + " Edit Name";
		pathcreate.enterPathwayName(pathwayEditedName);
		pathwayEditedTime = "30 minutes";
		pathcreate.setTime(pathwayEditedTime);
		sa.assertEquals(pathwayEditedTime, pathcreate.getlblPathTimerValueText(),
				"Pathway Timer is not chaged/ set correctly");
		// sa.assertTrue(pathcreate.verifyOrderOfReaders(dragNdDropPathwaylist),"Not
		// matched");
		sa.assertTrue(pathcreate.isbtnSaveEnabled(), "Save button is not enabled");
		pathcreate.clickbtnSave();
		GenericFunctions.declineAlert();
		Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers page");
		readersPage.clickFavouriteReader(startPathwyaReader);
		sa.assertTrue(readersPage.isStartPathwayVisible(), "Start pathway button is not visible");
		sa.assertEquals(ObjectMap.getvalue("ReadersList_txt_StartPathway") + " " + pathwayEditedName,
				readersPage.getTextFromStartPathway(), "pathway name is not matching with Edit pathway screen");
		readersPage.clickBtnStartPathway();
		Thread.sleep(1000);
		int expectedTime = Integer.parseInt(readersPage.getTextFromStartPathway().split("\\:")[1].trim());
		int time = Integer.parseInt(pathwayEditedTime.split("\\s")[0].trim()) - 1;
		sa.assertEquals(time, expectedTime, "Time after starting pathway does not match with pathway time");
		sa.assertFalse(readersPage.isPathwayIconVisible(),
				"Pahway icon should not be displayed after starting the pathway");
		sa.assertTrue(readersPage.isimgCancelPathwayVisible(), "Cancel pathway button is not visible");
		Gestures.clickScreenWindow();
		// Thread.sleep(1000);
		readersPage.clickimgCancelPathway();
		sa.assertTrue(readersPage.isPathwayIconVisible(),
				"Pahway icon should be displayed after cancelling/Completing the pathway");
		sa.assertFalse(readersPage.isimgCancelPathwayVisible(),
				"Cancel pathway button should not be displayed after cancelling/Completing the pathway");
		navigateToSettingsPathway();
		Assert.assertTrue(pathSetting.getPathwayNames().contains(pathwayEditedName),
				"Edited pathway name is displayed in settings page");
		navigateFromSettingsPathwaytoMainScreen();
		sa.assertAll();
	}

	@Test(description = "delete all the pathways in the settings screen")
	public void deletePathway() {
		try {
			readersPage.waitForSettings();
			readersPage.clickSettings();
			Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
			settings.clickPreferences();
			Assert.assertEquals(preferences.getHeaderText(), ObjectMap.getvalue("Preferences_Header_Txt"),
					"Unable to navigate Preferences page");
			preferences.clickPathways();
			Assert.assertEquals(pathSetting.getHeaderText(), ObjectMap.getvalue("Pathways_Header_Txt"),
					"Unable to navigate Pathways page");
			pathSetting.deleteAllpAthways();
			navigateFromPathwayPageToMainPage();
			// pathSetting.clickBack();
			// Assert.assertEquals(preferences.getHeaderText(),
			// ObjectMap.getvalue("Preferences_Header_Txt"),
			// "Unable to navigate Preferences page");
			// preferences.clickBack();
			// Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate
			// Settings page");
			// settings.clickCloseButton();
			// Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers
			// page");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Assert.fail();
		}
	}

	@Test(description = "swap the given pathways in the settings screen")
	public void swapPathways() throws Exception {
		// try {
		deletePathway();
		navigateFromMainPageToPathwayPage();
		// readersPage.waitForSettings();
		// readersPage.clickSettings();
		// Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate
		// Settings page");
		// settings.clickPreferences();
		// Assert.assertEquals(preferences.getHeaderText(),
		// ObjectMap.getvalue("Preferences_Header_Txt"),
		// "Unable to navigate Preferences page");
		// preferences.clickPathways();
		// Assert.assertEquals(pathSetting.getHeaderText(),
		// ObjectMap.getvalue("Pathways_Header_Txt"),
		// "Unable to navigate Pathways page");
		List<String> pathwayNames = pathSetting.getPathwayNames();
		int count = pathwayNames.size();
		if (pathwayNames.size() < 2) {
			navigateFromPathwayPageToMainPage();
			while (count < 2) {
				createPathway(++count);
			}
			navigateFromMainPageToPathwayPage();
		}
		if (pathSetting.getPathwayNames().size() > 1) {
			String pathway1 = pathwayNames.get(0);
			String Pathway2 = pathwayNames.get(1);
			pathSetting.swapPathwayNames(pathway1, Pathway2);
			sa.assertEquals(Pathway2, pathSetting.getPathwayNames().get(0), "pathways order is not changed");
		} else
			throw new SkipException("Skipping the testcase as the pathway list is empty/only single pathway");
		navigateFromPathwayPageToMainPage();
		// pathSetting.clickBack();
		// Assert.assertEquals(preferences.getHeaderText(),
		// ObjectMap.getvalue("Preferences_Header_Txt"),
		// "Unable to navigate Preferences page");
		// preferences.clickBack();
		// Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate
		// Settings page");
		// settings.clickCloseButton();
		// Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers
		// page");
		// } catch (Exception e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// Assert.fail();
		// }
	}

	public void navigateFromPathwayPageToMainPage() throws Exception {
		pathSetting.clickBack();
		Assert.assertEquals(preferences.getHeaderText(), ObjectMap.getvalue("Preferences_Header_Txt"),
				"Unable to navigate Preferences page");
		preferences.clickBack();
		if(config.isiOS()) {
		Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
		settings.clickCloseButton();
		}
		Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers page");
	}

	public void navigateFromMainPageToPathwayPage() throws Exception {
		readersPage.waitForSettings();
		readersPage.clickSettings();
		Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
		settings.clickPreferences();
		Assert.assertEquals(preferences.getHeaderText(), ObjectMap.getvalue("Preferences_Header_Txt"),
				"Unable to navigate Preferences page");
		preferences.clickPathways();
		Assert.assertEquals(pathSetting.getHeaderText(), ObjectMap.getvalue("Pathways_Header_Txt"),
				"Unable to navigate Pathways page");
	}

	Prefereneces_Gestures gesture = new Prefereneces_Gestures();

	@Test(description = "delete all the phone as a badge enabled readers in the settings screen")
	public void deletePhaab() {
		try {
			readersPage.waitForSettings();
			navigateToPHAAB();
			// readersPage.clickSettings();
			// Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate
			// Settings page");
			// settings.clickPreferences();
			// Assert.assertEquals(preferences.getHeaderText(),
			// ObjectMap.getvalue("Preferences_Header_Txt"),
			// "Unable to navigate Preferences page");
			// preferences.clickGestures();
			// Assert.assertEquals(Sphaab.getHeaderManageText(),
			// ObjectMap.getvalue("PAAB_Manage_Txt"),
			// "Unable to Phone as a badge page");
			gesture.enablePhoneAsBadge();
			gesture.deleteAllPAABs();
			navigateFromPHAABtoMainScreen();
			// Sphaab.clickBack();
			// Assert.assertEquals(preferences.getHeaderText(),
			// ObjectMap.getvalue("Preferences_Header_Txt"),
			// "Unable to navigate Preferences page");
			// preferences.clickBack();
			// Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate
			// Settings page");
			// settings.clickCloseButton();
			// Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers
			// page");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Assert.fail();
		}
	}

	public void navigateToPHAAB() throws Exception {
		readersPage.waitForSettings();
//		Thread.sleep(2000);
//		new Gestures().scrollFromLeftToRightOfScreen();
		readersPage.clickSettings();
		Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
		settings.clickPreferences();
		Assert.assertEquals(preferences.getHeaderText(), ObjectMap.getvalue("Preferences_Header_Txt"),
				"Unable to navigate Preferences page");
		preferences.clickGestures();
		Assert.assertEquals(gesture.getPhaabHeaderText(), ObjectMap.getvalue("Gestures_PHHAB_Txt"),
				"Unable to Phone as a badge page");
	}

	public void enablePHAAB() throws Exception {
		navigateToPHAAB();
		gesture.enablePhoneAsBadge();
		navigateFromPHAABtoMainScreen();
	}

	public void navigateFromPHAABtoMainScreen() throws Exception {
		gesture.clickBack();
		Assert.assertEquals(preferences.getHeaderText(), ObjectMap.getvalue("Preferences_Header_Txt"),
				"Unable to navigate Preferences page");
		preferences.clickBack();
		Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
		settings.clickCloseButton();
		Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers page");
	}

	public void navigateToSettingsPathway() throws Exception {
		Thread.sleep(2000);
		new Gestures().scrollFromLeftToRightOfScreen();
		readersPage.clickSettings();
		Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
		settings.clickPreferences();
		Assert.assertEquals(preferences.getHeaderText(), ObjectMap.getvalue("Preferences_Header_Txt"),
				"Unable to navigate Preferences page");
		preferences.clickPathways();
		Assert.assertEquals(pathSetting.getHeaderText(), ObjectMap.getvalue("Pathways_Header_Txt"),
				"Unable to Pathways page");
	}

	public void navigateFromSettingsPathwaytoMainScreen() throws Exception {
		pathSetting.clickBack();
		Assert.assertEquals(preferences.getHeaderText(), ObjectMap.getvalue("Preferences_Header_Txt"),
				"Unable to navigate Preferences page");
		preferences.clickBack();
		Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
		settings.clickCloseButton();
		Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers page");
	}

	public PHAAB phaab = new PHAAB();

	// Need to change he code for fav image detection
	@Test(description = "Verfiy the phaab enabled readers are displayed with icon")
	public void verifyPHAABFavoriteReader() throws Exception {
		readersPage.waitForSettings();
		deletePhaab();
		deleteAllFavReaders();
		// readersPage.clearallPHAABFavReaders();
		List<MobileElement> readersList = readersPage.getFavoriteReadersList();
		if (!(readersList.size() > 0)) {
			verifyFavoriteReader();
		}
		readersList = readersPage.getFavoriteReadersList();
		if (readersList.size() > 0) {
			String reader = readersList.get(0).getText();
			Boolean addToPhaab = readersPage.addReaderasPHAAB(readersList.get(0));
			if (addToPhaab) {
				readersPage.clikcEnablePhaab();
				Thread.sleep(5000);
				Assert.assertEquals(phaab.getTapToStartMsgtext(), ObjectMap.getvalue("PhoneAsABadge_TapToStart_txt"),
						"Unable to Phone as a badge page");

				phaab.clickStart();
				if (GenericFunctions.isAndroid()) {
					sa.assertEquals(reader.toUpperCase(), phaab.GetPopupReaderName(),
							"Reader name is not displayed in pop-up");
				} else {
					sa.assertEquals(reader, phaab.GetPopupReaderName(), "Reader name is not displayed in pop-up");
				}
				phaab.selectReader();
				sa.assertEquals(phaab.getSuccesstext(), ObjectMap.getvalue("PhoneAsABadge_success_txt"),
						"Success message is not displayed");
				phaab.clickDone();
				// sa.assertTrue(readersPage.isQuicConnecting(0), reader +"is not displayed with
				// quick connecting");
				// sa.assertTrue(readersPage.isQuicConnectReady(0), reader +"is not displayed
				// with quick connect ready");
				sa.assertTrue(readersPage.isPHAABEnabledforFavoriteReader(0),
						reader + " is not displayed with phaab icon");
				Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers page");
				navigateToPHAAB();
				sa.assertTrue(gesture.getPHAABReaderNames().contains(reader),
						"Reader name : " + reader + " is not displayed in tha PHAAB list");
				navigateFromPHAABtoMainScreen();
			} else {
				throw new SkipException("Skipping the testcases as the fav reader is Turnstile reader");
			}
		} else {
			throw new SkipException("Skipping the testcases as the normal readers list is empty");
		}
		sa.assertAll();
	}

	@Test(description = "Verfiy  remove PHHAB for favorite readers")
	public void verifyRemovePHAABFavoriteReader() throws Exception {
		verifyPHAABFavoriteReader();
		List<MobileElement> readersList = readersPage.getFavoriteReadersList();
		if (readersList.size() > 0) {
			String reader = readersList.get(0).getText();
			// readersPage.
			readersPage.removeReaderfromPHAAB(readersList.get(0));
			// Thread.sleep(20000);
			// sa.assertTrue(readersPage.isQuicConnecting(0), reader +"is not displayed with
			// quick connecting");
			// sa.assertTrue(readersPage.isQuicConnectReady(0), reader +"is not displayed
			// with quick connect ready");
			sa.assertFalse(readersPage.isPHAABEnabledforFavoriteReader(0), reader + " is displayed with phaab icon");
			Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers page");
			navigateToPHAAB();
			sa.assertFalse(gesture.getPHAABReaderNames().contains(reader),
					"Reader name : " + reader + " is still displayed in tha PHAAB list");
			navigateFromPHAABtoMainScreen();
		} else {
			throw new SkipException("Skipping the testcases as the normal readers list is empty");
		}
		sa.assertAll();
	}

	@Test(description = "Verfiy  edit PHHAB for favorite readers")
	public void verifyEditPHAABFavoriteReader() throws Exception {
		verifyPHAABFavoriteReader();
		navigateToPHAAB();
		String reader = gesture.getPHAABReaderNames().get(0).toUpperCase();
		gesture.clickEditIcon(0);
		Assert.assertEquals(phaab.getTapToStartMsgtext(), ObjectMap.getvalue("PhoneAsABadge_TapToStart_txt"),
				"Unable to Phone as a badge page");
		phaab.clickStart();
		if (GenericFunctions.isAndroid()) {
			sa.assertEquals(reader.toUpperCase(), phaab.GetPopupReaderName(), "Reader name is not displayed in pop-up");
		} else {
			sa.assertEquals(reader, phaab.GetPopupReaderName(), "Reader name is not displayed in pop-up");
		}
		sa.assertEquals(phaab.getSuccesstext(), ObjectMap.getvalue("PhoneAsABadge_success_txt"),
				"Success message is not displayed");
		phaab.clickDone();
		navigateFromPHAABtoMainScreen();
		Thread.sleep(3000);
		sa.assertTrue(readersPage.isPHAABEnabledforFavoriteReader(0), reader + " is not displayed with phaab icon");
		sa.assertAll();
	}

	@Test(description = "Verfiy the phaab enabled normal readers are displayed with icon")
	public void verifyPHAABNormalReader() throws Exception {
		readersPage.waitForSettings();
		deletePhaab();
		navigateFromHomeToFavorites();
		fav.DeleteAllReaders();
		navigateFromFavoritesToHome();
		List<MobileElement> readersList = readersPage.getReadersList();
		int i = 0;
		String reader;
		Boolean status;
		if (readersList.size() > 0) {
			// readersPage.clearallPHAABNormalReaders();
			do {
				reader = readersList.get(i).getText();
				status = readersPage.addReaderasPHAAB(readersList.get(i));
				i++;
				if (readersList.size() <= i)
					throw new SkipException("Only turnstile readers are visible, so unable to enable phaab");
			} while (!status);
			readersPage.clikcEnablePhaab();
			Assert.assertEquals(phaab.getTapToStartMsgtext(), ObjectMap.getvalue("PhoneAsABadge_TapToStart_txt"),
					"Unable to Phone as a badge page");
			phaab.clickStart();
			if (GenericFunctions.isAndroid()) {
				sa.assertEquals(reader.toUpperCase(), phaab.GetPopupReaderName(),
						"Reader name is not displayed in pop-up");
			} else {
				sa.assertEquals(reader, phaab.GetPopupReaderName(), "Reader name is not displayed in pop-up");
			}
			phaab.selectReader();
			sa.assertEquals(phaab.getSuccesstext(), ObjectMap.getvalue("PhoneAsABadge_success_txt"),
					"Success message is not displayed");
			phaab.clickDone();
			// Thread.sleep(20000);
			// sa.assertTrue(readersPage.isPHAABEnabledforNormalReader(0), reader +" is not
			// displayed with phaab icon");
			Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers page");
			navigateToPHAAB();
			sa.assertTrue(gesture.getPHAABReaderNames().contains(reader),
					"Reader name : " + reader + " is not displayed in tha PHAAB list");
			navigateFromPHAABtoMainScreen();
		} else {
			throw new SkipException("Skipping the testcases as the normal readers list is empty");
		}
		sa.assertAll();
	}

	@Test(description = "Verfiy  remove PHHAB for Normal readers")
	public void verifyRemovePHAABNormalReader() throws Exception {
		verifyPHAABNormalReader();
		navigateFromHomeToFavorites();
		fav.DeleteAllReaders();
		navigateFromFavoritesToHome();
		List<MobileElement> readersList = readersPage.getReadersList();
		if (readersList.size() > 0) {
			String reader = readersList.get(0).getText();
			readersPage.removeReaderfromPHAAB(readersList.get(0));
			// Thread.sleep(20000);
			// sa.assertTrue(readersPage.isQuicConnecting(0), reader +"is not displayed with
			// quick connecting");
			// sa.assertTrue(readersPage.isQuicConnectReady(0), reader +"is not displayed
			// with quick connect ready");
			sa.assertFalse(readersPage.isPHAABEnabledforNormalReader(0), reader + " is displayed with phaab icon");
			Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers page");
			navigateToPHAAB();
			sa.assertFalse(gesture.getPHAABReaderNames().contains(reader),
					"Reader name : " + reader + " is still displayed in tha PHAAB list");
			navigateFromPHAABtoMainScreen();
		} else {
			throw new SkipException("Skipping the testcases as the normal readers list is empty");
		}
		sa.assertAll();
	}

	@Test(description = "Verfiy the phaab enabled for all readers")
	public void verifyPHAABAllReader() throws Exception {
		deletePhaab();
		readersPage.waitForSettings();
		List<MobileElement> readersList = readersPage.getReadersList();
		if (readersList.size() > 0) {
			// readersPage.clearallPHAABNormalReaders();
			String reader = readersList.get(0).getText();
			System.out.println(reader);
			Boolean addToPhaab = readersPage.addReaderasPHAAB(readersList.get(0));
			if (addToPhaab) {
				readersPage.clikcEnablePhaab();
				Assert.assertEquals(phaab.getTapToStartMsgtext(), ObjectMap.getvalue("PhoneAsABadge_TapToStart_txt"),
						"Unable to Phone as a badge page");
				phaab.clickStart();
				if (GenericFunctions.isAndroid()) {
					sa.assertEquals(reader.toUpperCase(), phaab.GetPopupReaderName(),
							"Reader name is not displayed in pop-up");
				} else {
					sa.assertEquals(reader, phaab.GetPopupReaderName(), "Reader name is not displayed in pop-up");
				}

				phaab.SelectAllreaders();
				sa.assertEquals(phaab.getSuccesstext(), ObjectMap.getvalue("PhoneAsABadge_success_txt"),
						"Success message is not displayed");
				phaab.clickDone();
				// Thread.sleep(20000);
				sa.assertFalse(readersPage.isPHAABEnabledforNormalReader(0), reader + " is displayed with phaab icon");
				Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers page");
				navigateToPHAAB();
				sa.assertTrue(
						gesture.getPHAABReaderNames().contains(ObjectMap.getvalue("PhoneAsABadge_AlertOption1_txt")),
						"Reader name : " + ObjectMap.getvalue("PhoneAsABadge_AlertOption1_txt")
								+ " is not displayed in tha PHAAB list");
				navigateFromPHAABtoMainScreen();
			} else {
				throw new SkipException("Skipping the testcases as the fav reader is Turnstile reader");
			}
		} else {
			throw new SkipException("Skipping the testcases as the normal readers list is empty");
		}
		sa.assertAll();
	}

//	Note: widget need to be added manually before executing the cases
	@Test(description = "Verfiy the Fav Readers is displayed and able to unlock the reader")
	public void verifyWidgetUnlockFavReader() throws Exception {
		readersPage.waitForSettings();
		if (readersPage.getFavoriteReadersList().size() <= 0) {
			verifyFavoriteReader();
		}
		// List<String> favReaders = readersPage.getFavoriteReaders();
		Setup.driver.runAppInBackground(Duration.ofSeconds(-1));
		Thread.sleep(8000);
		GenericFunctions.navigateToWidget();
		widget.clickShowMore();
		Thread.sleep(5000);
		List<String> widgetFavReaders = widget.getFavoriteReaders();
		String readerToClick = widgetFavReaders.get(0);
		// sa.assertTrue(favReaders.equals(widgetFavReaders));
		widget.clickReader(readerToClick);
		// sa.assertTrue(readersPage.waitForAnimation(), "Animation is not displayed");
		sa.assertEquals(readerToClick, readersPage.getSelectedReaderText(),
				"Selected reader text is not displayed during unlocking");
		sa.assertAll();
	}

	@Test(description = "Verfiy the pathways displayed and able to start the pathway")
	public void verifyWidgetStartPathway() throws Exception {
		readersPage.waitForSettings();
		readersPage.clickPathwayIcon();
		List<String> pathways = null;
		if (pathmanage.waitforManagePathwayTitle()) {
			pathways = pathmanage.getPathwayNames();
			pathmanage.clickClose();
		} else {
			welcome.clickClose();
			createPathway(1);
			readersPage.clickPathwayIcon();
			pathways = pathmanage.getPathwayNames();
			pathmanage.clickClose();
		}
		Setup.driver.runAppInBackground(Duration.ofSeconds(-1));
		Thread.sleep(10000);
		GenericFunctions.navigateToWidget();
		widget.clickShowMore();
		String pathwayToClick = pathways.get(0);
		List<String> widgetPathways = widget.getPathways();
		sa.assertTrue(pathways.equals(widgetPathways));
		widget.clickPathway(pathwayToClick);
		// int expectedTime =
		// Integer.parseInt(readersPage.getTextFromStartPathway().split("\\:")[1].trim());
		// int time = Integer.parseInt(pathwayTime.split("\\s")[0].trim()) - 1;
		String expectedName = readersPage.getTextFromStartPathway().split("\\:")[0].trim();
		// sa.assertEquals(time, expectedTime, "Time after starting pathway does not
		// match with pathway time");
		sa.assertEquals(pathwayToClick, expectedName,
				"pathway name after starting pathway does not match with create pathway name");
		sa.assertTrue(readersPage.isimgCancelPathwayVisible(), "Cancel pathway button is not visible");
		readersPage.clickimgCancelPathway();
		sa.assertAll();
	}

	@Test(description = "Verfiy the message displayed when the pathways and fav readers are empty")
	public void verifyWidgtEmptyReaderNdPathway() throws Exception {
		readersPage.waitForSettings();
		deleteAllFavReaders();
		Setup.driver.runAppInBackground(Duration.ofSeconds(-1));
		Thread.sleep(12000);
		GenericFunctions.navigateToWidget();
		widget.clickShowMore();
		sa.assertEquals(ObjectMap.getvalue("Widget_Emptypathways_txt"), widget.getEmptyPathwaysText(),
				"Empty pathway text is not displayed");
		sa.assertEquals(ObjectMap.getvalue("Widget_EmptyReaders_txt"), widget.getEmptyReadersText(),
				"Empty Readers text is not displayed");
		sa.assertAll();
	}

	@Test(description = "Verfiy the message displayed in widget when the ble is set to off")
	public void verifyWidgtBLEoff() throws Exception {
		readersPage.waitForSettings();
		readersPage.disableDeviceBluetooth();
		new Gestures().minimizeTheApp();
//		Setup.driver.runAppInBackground(Duration.ofSeconds(-1));
		Thread.sleep(12000);
		GenericFunctions.navigateToWidget();
		widget.clickShowMore();
		sa.assertTrue(widget.isimgBluetoothDisplayed(), "BLE image is not displayed");
		sa.assertEquals(ObjectMap.getvalue("Widget_BLEoffHeader_txt"), widget.getNoBluetoothText(),
				"Empty pathway text is not displayed");
		sa.assertEquals(ObjectMap.getvalue("Widget_GoToSettingsMsg_txt"), widget.getGoToSettingsMsgText(),
				"Empty Readers text is not displayed");
		sa.assertEquals(ObjectMap.getvalue("Widget_BLEoffMessage_txt"), widget.getNoBluetoothMsgText(),
				"Empty pathway text is not displayed");
		sa.assertEquals(ObjectMap.getvalue("Widget_GoToSettingsBtn_txt"), widget.getGoToSettingsBtnText(),
				"Empty Readers text is not displayed");
//		sa.assertTrue(widget.isimgGoToSettingsDisplayed(),"Settings icon is not displayed");
		widget.clickShowLess();
		sa.assertEquals(ObjectMap.getvalue("Widget_BLENotEnable_txt"), widget.getHintText(),
				"Bluetooth not enabled text is not displayed in show less mode");
		sa.assertAll();
	}

	public void deleteAllFavReaders() throws Exception { // will remove both fav readers and pathways
		List<MobileElement> readersList = readersPage.getFavoriteReadersList();
		for (int i = 0; i < readersList.size(); i++) {
			readersPage.removeReaderfromFavorite(readersPage.getFavoriteReadersList().get(0));
			readersPage.waitForSettings();
		}
	}

	@Test(description = "Verfiy user is navigated to readers page on selecting Nearby and pathways screen on selecting pathway from widget show more view")
	public void verifyWidgetNearbyNdPathwaysClick() throws Exception {
		readersPage.waitForSettings();
		Setup.driver.runAppInBackground(Duration.ofSeconds(-1));
		// Thread.sleep(12000);
		GenericFunctions.navigateToWidget();
		widget.clickShowMore();
		if (widget.waitForlblEmptyPathways()) {
			widget.clickPathways();
			Thread.sleep(5000);
			Assert.assertTrue(welcome.waitforPathwayWelcomeTitle(), "Unable to navigate Pathway Welcome page");
		} else {
			widget.clickPathways();
			Thread.sleep(5000);
			Assert.assertTrue(pathmanage.waitforManagePathwayTitle(), "Unable to navigate Manage pathway page");
		}
		Setup.driver.runAppInBackground(Duration.ofSeconds(-1));
		GenericFunctions.navigateToWidget();
		widget.clickShowMore();
		widget.clickNearby();
		Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate to readers page");
		sa.assertAll();
	}

	@Test(description = "Verfiy user is navigated to readers page on selecting Nearby and pathways screen on selecting pathway from widget show less view")
	public void verifyWidgetShowLessNearbyNdPathwaysClick() throws Exception {
		readersPage.waitForSettings();
		Setup.driver.runAppInBackground(Duration.ofSeconds(-1));
		// Thread.sleep(12000);
		GenericFunctions.navigateToWidget();
		widget.clickShowMore();
		int pathwayCount;
		if (widget.waitForlblEmptyPathways()) {
			pathwayCount = 0;
		} else {
			pathwayCount = 1;
		}
		widget.clickShowLess();
		widget.clickPathways();
		if (pathwayCount == 0) {
			Assert.assertTrue(welcome.waitforPathwayWelcomeTitle(), "Unable to navigate Pathway Welcome page");
		} else {
			Assert.assertTrue(pathmanage.waitforManagePathwayTitle(), "Unable to navigate Manage pathway page");
		}
		Setup.driver.runAppInBackground(Duration.ofSeconds(-1));
		GenericFunctions.navigateToWidget();
		widget.clickShowLess();
		sa.assertTrue(widget.isimgArrowDisplayed(), "arrow icon is not displayed in show less view");
		sa.assertEquals(ObjectMap.getvalue("Widget_DisplayReaders_txt"), widget.getHintText(),
				"Display readers text is not displayed in show less mode");
		widget.clickNearby();
		Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate to readers page");
		sa.assertAll();
	}

}
