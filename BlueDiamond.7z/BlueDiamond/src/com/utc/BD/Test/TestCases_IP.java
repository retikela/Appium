package com.utc.BD.Test;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import com.appium.Common.Element;
import com.appium.Common.GenericFunctions;
import com.appium.Common.ObjectMap;
import com.utc.BD.Pages.BrowseCampuses;
import com.utc.BD.Pages.BrowseFloors;
import com.utc.BD.Pages.BrowsePoints;
import com.utc.BD.Pages.ConsentAndroid;
import com.utc.BD.Pages.GetDirections;
import com.utc.BD.Pages.MapPage;
import com.utc.BD.Pages.IndoorLocOptInScreen;
import com.utc.BD.Pages.LocationSettings;
import com.utc.BD.Pages.Preferences;
import com.utc.BD.Pages.ReadersList;
import com.utc.BD.Pages.RoutePage;
import com.utc.BD.Pages.Sensitivity;
import com.utc.BD.Pages.Settings;
import com.utc.BD.Pages.Setup;
import com.utc.BD.Pages.WalkThrough;
import com.utc.BD.Pages.routePreview;

public class TestCases_IP extends Setup {

	MapPage map = new MapPage();
	WalkThrough walk = new WalkThrough();
	BrowsePoints points = new BrowsePoints();
	BrowseCampuses campus = new BrowseCampuses();
	GetDirections directions = new GetDirections();
	BrowseFloors floors = new BrowseFloors();
	ReadersList readersPage = new ReadersList();
	Settings settings = new Settings();
	Preferences preferences = new Preferences();
	Sensitivity sensitivity = new Sensitivity();
	LocationSettings location = new LocationSettings();
	IndoorLocOptInScreen opt = new IndoorLocOptInScreen();
	routePreview route = new routePreview();
	ConsentAndroid consentform = new ConsentAndroid();
	RoutePage rp = new RoutePage();

	// Indoor Positioning test cases

	@Test(description = "Verfiy home page features")
	public void verifyHomeScreen() throws Exception {
		try {
			sa.assertEquals(map.waitForLoading(), true, "Progress bar didn't disappear within mentioned time.");
			map.clickReaders();
			sa.assertTrue(map.btnPathway().isDisplayed(), "Unable to navigate to Readers tab");
			map.clickMaps();
			sa.assertEquals(map.waitForLoading(), true, "Progress bar didn't disappear within mentioned time.");
			sa.assertEquals(map.waitForSearchIconToAppear(), true, "Search icon didn't appear within mentioned time.");
			sa.assertTrue(map.btnSearch().isDisplayed(), "Unable to navigate to Maps tab");
			sa.assertTrue(map.btnSearch().isDisplayed(), "Search option is not available in Maps tab");
			sa.assertTrue(map.btnDirections().isDisplayed(), "Directions option is not available in Maps tab");
			sa.assertTrue(map.btnCampuses().isDisplayed(), "Campuses option is not available in Maps tab");
			sa.assertTrue(map.btnFloors().isDisplayed(), "Floors option is not available in Maps tab");

			map.verifyEndFromPOICard();
			directions.clickCancel();
			sa.assertEquals(map.waitForLoading(), true, "Progress bar didn't disappear within mentioned time.");
			sa.assertEquals(map.waitForSearchIconToAppear(), true, "Search icon didn't appear within mentioned time.");

			map.verifyEndFromDirections();
			directions.clickCancel();
			sa.assertEquals(map.waitForLoading(), true, "Progress bar didn't disappear within mentioned time.");
			sa.assertEquals(map.waitForSearchIconToAppear(), true, "Search icon didn't appear within mentioned time.");

			sa.assertAll();
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
	}

	@Test(description = "Verfiy Browse points functionality")
	public void verifyBrowsePoints() throws Exception {
		try {
			sa.assertEquals(map.waitForLoading(), true, "Progress bar didn't disappear within mentioned time.");
			sa.assertEquals(map.waitForSearchIconToAppear(), true, "Search icon didn't appear within mentioned time.");
			map.clickSearch();
			Assert.assertEquals(ObjectMap.getvalue("points_pageTitle_txt"), points.verifyPageTitle());

			sa.assertTrue(points.btn_thisFloor().isDisplayed(),
					"This Floor option is not available in Browse Points screen");
			sa.assertTrue(points.btn_allFloors().isDisplayed(),
					"All Floors option is not available in Browse Points screen");
			sa.assertTrue(points.btn_filter().isDisplayed(), "Filter option is not available in Browse Points screen");

			String selctedPOITxt = points.selectRandomPOIForStart();
			sa.assertEquals(map.waitForLoading(), true, "Progress bar didn't disappear within mentioned time.");
			sa.assertEquals(map.waitForSearchIconToAppear(), true, "Search icon didn't appear within mentioned time.");
			sa.assertTrue(map.poiCard().isDisplayed(), "Poi card is not available in Maps screen");
			Reporter.log("POI info card is displayed in Maps screen");
			sa.assertEquals(map.getSelectedPoiText(), selctedPOITxt, "Selected POI and card on Maps are not equal");
			Reporter.log("POI name displayed on the card is as expected");

			sa.assertTrue(map.btnSearch().isDisplayed(), "Unable to navigate to Maps tab");
			map.clickSearch();
			Assert.assertEquals(ObjectMap.getvalue("points_pageTitle_txt"), points.verifyPageTitle());

			points.verifySearch();
			sa.assertTrue(points.clearText().isDisplayed(), "Clear text icon is not available in the search field");
			points.clickClearText();

			points.clickFilter();
			points.selectPoiType();
			sa.assertTrue(points.clearFilter().isDisplayed(),
					"Clear filter option is not available in the search field");
			points.clickApply();
			sa.assertTrue(points.resultPoiType().isDisplayed(),
					"Search result based on poi type selection is not as expected");
			sa.assertTrue(points.filterApplied().isDisplayed(), "Filter applied icon is not available");

			sa.assertTrue(points.btn_cancel().isDisplayed(), "Cancel button is not available in Browse Points screen");

			// Validate cancel button functionality
			points.clickCancel();
			sa.assertEquals(map.waitForLoading(), true, "Progress bar didn't disappear within mentioned time.");
			sa.assertEquals(map.waitForSearchIconToAppear(), true, "Search icon didn't appear within mentioned time.");

			// Validate back button functionality
			if (GenericFunctions.isAndroid()) {
				map.clickSearch();
				map.clickDeviceBackButton();
				sa.assertEquals(map.waitForLoading(), true, "Progress bar didn't disappear within mentioned time.");
				sa.assertEquals(map.waitForSearchIconToAppear(), true,
						"Search icon didn't appear within mentioned time.");
			}

			sa.assertAll();
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
	}

	@Test(description = "Verfiy Browse Campuses functionality")
	public void verifyBrowseCampuses() throws Exception {
		try {
			sa.assertEquals(map.waitForLoading(), true, "Progress bar didn't disappear within mentioned time.");
			sa.assertEquals(map.waitForSearchIconToAppear(), true, "Search icon didn't appear within mentioned time.");
			map.clickCampuses();
			Assert.assertEquals(ObjectMap.getvalue("campuses_pageTitle_txt"), campus.verifyPageTitle());
			sa.assertTrue(campus.search_campus().isDisplayed(),
					"Cancel button is not available in Browse Campuses screen");
			sa.assertTrue(campus.btn_cancel().isDisplayed(),
					"Cancel button is not available in Browse Campuses screen");
			sa.assertTrue(campus.search().isDisplayed(), "Search field is not available in Browse Campuses screen");
			sa.assertTrue(campus.campusName().isDisplayed(),
					"Building number is not available in Campuses floors screen");

			// Retrieve campus name and verify
			String campusName = campus.getCampusName();
			campus.selectCampus();
			sa.assertTrue(campus.buildingNumber().isDisplayed(),
					"Building number is not available in Campuses floors screen");
			sa.assertEquals(campus.getSelectedCampusName(), campusName, "Selected Campus is as expected");

			// Retrieve Building name and verify
			String buildingName = campus.getBuildingName();
			campus.clickPreference();
			sa.assertEquals(campus.getSelectedBuildingName(), buildingName, "Selected Campus is as expected");
			sa.assertTrue(campus.floorNumber().isDisplayed(),
					"Floor number is not available in Browse Campuses screen");
			campus.clickPreference();
			sa.assertEquals(map.waitForLoading(), true, "Progress bar didn't disappear within mentioned time.");
			sa.assertEquals(map.waitForSearchIconToAppear(), true, "Search icon didn't appear within mentioned time.");

			map.clickCampuses();
			sa.assertTrue(campus.campusName().isDisplayed(),
					"Building number is not available in Campuses floors screen");
			campus.selectCampus();
			sa.assertTrue(campus.buildingNumber().isDisplayed(),
					"Building number is not available in Campuses floors screen");
			campus.clickPreference();
			sa.assertTrue(campus.floorNumber().isDisplayed(),
					"Floor number is not available in Browse Campuses screen");
			campus.clickBackArrow();
			sa.assertTrue(campus.buildingNumber().isDisplayed(),
					"Building number is not available in Campuses floors screen");
			if (GenericFunctions.isAndroid()) {
				campus.clickBackArrow();
			} else {
				campus.clickBackArrowToCampus();
			}
			sa.assertTrue(campus.campusName().isDisplayed(),
					"Building number is not available in Campuses floors screen");

			// Validate cancel functionality
			campus.clickCancel();
			sa.assertEquals(map.waitForLoading(), true, "Progress bar didn't disappear within mentioned time.");
			sa.assertEquals(map.waitForSearchIconToAppear(), true, "Search icon didn't appear within mentioned time.");

			// Validate back button functionality
			if (GenericFunctions.isAndroid()) {
				map.clickCampuses();
				map.clickDeviceBackButton();
				sa.assertEquals(map.waitForLoading(), true, "Progress bar didn't disappear within mentioned time.");
				sa.assertEquals(map.waitForSearchIconToAppear(), true,
						"Search icon didn't appear within mentioned time.");
			}

			sa.assertAll();
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
	}

	@Test(description = "Verfiy Browse Floors functionality")
	public void verifyBrowseFloors() throws Exception {
		try {
			sa.assertEquals(map.waitForLoading(), true, "Progress bar didn't disappear within mentioned time.");
			sa.assertEquals(map.waitForSearchIconToAppear(), true, "Search icon didn't appear within mentioned time.");
			String floorNumber = map.getFloorNumber();
			map.clickFloors();
			Assert.assertEquals(ObjectMap.getvalue("floors_pageTitle_txt"), floors.verifyPageTitle());
			// sa.assertTrue(floors.buildingNumber().isDisplayed(), "Building number is not
			// available in Browse floors screen");
			sa.assertTrue(floors.floorNumber().isDisplayed(), "Floor number is not available in Browse floors screen");
			sa.assertTrue(floors.search().isDisplayed(), "Search field is not available in Browse floors screen");
			sa.assertTrue(floors.btn_cancel().isDisplayed(), "Cancel button is not available in Browse floors screen");
			floors.searchFloor();
			sa.assertTrue(floors.floorNumber().isDisplayed(), "Floor number is not available in Browse floors screen");
			sa.assertEquals(floors.getFloorNumber(), floorNumber,
					"Floor number displayed is not as expected in Browse floors screen");
			Assert.assertEquals(floors.clearText().isDisplayed(), true,
					"Clear text icon is not displayed in serach field");
			floors.clickClearBtn();

			// Validate cancel button functionality
			floors.clickCancel();
			sa.assertEquals(map.waitForLoading(), true, "Progress bar didn't disappear within mentioned time.");
			sa.assertEquals(map.waitForSearchIconToAppear(), true, "Search icon didn't appear within mentioned time.");

			// Validate back button functionality
			if (GenericFunctions.isAndroid()) {
				map.clickFloors();
				map.clickDeviceBackButton();
				sa.assertEquals(map.waitForLoading(), true, "Progress bar didn't disappear within mentioned time.");
				sa.assertEquals(map.waitForSearchIconToAppear(), true,
						"Search icon didn't appear within mentioned time.");
			}

			sa.assertAll();
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
	}

	@Test(description = "Verfiy Get Directions functionality")
	public void verifyGetDirections() throws Exception {
		try {
			sa.assertEquals(map.waitForLoading(), true, "Progress bar didn't disappear within mentioned time.");
			sa.assertEquals(map.waitForSearchIconToAppear(), true, "Search icon didn't appear within mentioned time.");
			Thread.sleep(1000);
			map.clickDirections();
			Assert.assertEquals(ObjectMap.getvalue("directions_pageTitle_txt"), directions.verifyPageTitle());
			sa.assertTrue(directions.btn_cancel().isDisplayed(),
					"Cancel button is not available in Get Direactions screen");

			sa.assertTrue(directions.imgDirection().isDisplayed(),
					"Directions image is not available in Get Direactions screen");
			Assert.assertEquals(ObjectMap.getvalue("directions_lbl_txt"), directions.getVerbiage(),
					"Verbiage displayed is not as expected");

			// Choose Start
			directions.clickOnStartFiled();
			String poiInStart = directions.selectRandomPOIForStart();
			sa.assertTrue(directions.btnClearStart().isDisplayed(),
					"Directions image is not available in Get Direactions screen");

			// Choose End
			directions.clickOnEndFiled();
			directions.selectRandomPOIEnd(poiInStart);
			sa.assertTrue(directions.btnClearEnd().isDisplayed(),
					"Directions image is not available in Get Direactions screen");

			if (GenericFunctions.isIOS()) {
				sa.assertTrue(directions.imgDirection().isDisplayed(),
						"Directions image is not available in Get Direactions screen");
				// sa.assertFalse(directions.verbiage().isDisplayed(), "Verbiage is available
				// even after both Start and End are choosen in Get Direactions screen");
			}
			sa.assertTrue(directions.btnPreviewRoute().isDisplayed(),
					"Preview Route button is not available in Get Direactions screen");

			directions.clickCancel();
			sa.assertEquals(map.waitForLoading(), true, "Progress bar didn't disappear within mentioned time.");
			sa.assertEquals(map.waitForSearchIconToAppear(), true, "Search icon didn't appear within mentioned time.");

			// Validate back button functionality
			if (GenericFunctions.isAndroid()) {
				map.clickDirections();
				map.clickDeviceBackButton();
				sa.assertEquals(map.waitForLoading(), true, "Progress bar didn't disappear within mentioned time.");
				sa.assertEquals(map.waitForSearchIconToAppear(), true,
						"Search icon didn't appear within mentioned time.");
			}

			sa.assertAll();

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
	}

	@Test
	public void verifyLocationSettings() throws Exception {
		try {
			sa.assertEquals(map.waitForLoading(), true, "Progress bar didn't disappear within mentioned time.");
			sa.assertEquals(map.waitForSearchIconToAppear(), true, "Search icon didn't appear within mentioned time.");
			readersPage.waitForSettings();
			readersPage.clickSettings();
			settings.clickPreferences();
			Thread.sleep(2000);
			Assert.assertEquals(preferences.getHeaderText(), ObjectMap.getvalue("Preferences_Header_Txt"),
					"Unable to navigate Preferences page");
			preferences.clickLocationSettings();
			Thread.sleep(2000);
			Assert.assertEquals(location.getPageTitle(), ObjectMap.getvalue("locationSettings_Title_Txt"),
					"Unable to navigate to location settings page");
			sa.assertTrue(location.showMaps().isDisplayed(), "Unable to navigate to Maps tab");
			sa.assertTrue(location.location().isDisplayed(), "Unable to navigate to Maps tab");
			sa.assertTrue(location.checkBoxLiveNavigation().isDisplayed(),
					"Live Navigation checkbox is not availabe under location settings.");
			if (GenericFunctions.isAndroid()) {
				sa.assertTrue(location.backGroundServices().isDisplayed(),
						"Background services checkbox is not availabe under location settings.");
			}
			sa.assertTrue(location.geoFences().isDisplayed(),
					"Geofence checkbox is not availabe under location settings.");
			if (GenericFunctions.isIOS()) {
				sa.assertTrue(location.backGroundServicesToggle().isDisplayed(),
						"Background service toggle is not available");
			}
			sa.assertTrue(location.backButton().isDisplayed(), "Back button is not available");
			location.clickShowMaps();
			sa.assertFalse(opt.checkBoxLiveNavigation().isEnabled(),
					"Live Navigation checkbox is not availabe under location settings.");
			location.clickBack();
			location.clickBack();
			sa.assertEquals(map.waitForLoading(), true, "Progress bar didn't disappear within mentioned time.");
			sa.assertFalse(map.verifySearchAvailibility(), "Unable to navigate to Maps tab");

			readersPage.waitForSettings();
			readersPage.clickSettings();
			settings.clickPreferences();
			Assert.assertEquals(preferences.getHeaderText(), ObjectMap.getvalue("Preferences_Header_Txt"),
					"Unable to navigate Preferences page");
			preferences.clickLocationSettings();
			Thread.sleep(1000);
			Assert.assertEquals(location.getPageTitle(), ObjectMap.getvalue("locationSettings_Title_Txt"),
					"Unable to navigate to location settings page");
			location.clickShowMaps();
			sa.assertTrue(opt.verifyCheckBoxState(opt.checkBoxLiveNavigation()),
					"Live Navigation checkbox is not availabe under location settings.");

			// Disable live navigation check box and verify for snag bar in Maps screen
			location.clickLiveNavigation();
			sa.assertFalse(opt.verifyCheckBoxState(opt.checkBoxLiveNavigation()),
					"Geofence checkbox didn't get turn off");

			location.clickBack();
			location.clickBack();
			sa.assertEquals(map.waitForLoading(), true, "Progress bar didn't disappear within mentioned time.");
			sa.assertEquals(map.waitForSearchIconToAppear(), true, "Search icon didn't appear within mentioned time.");
			sa.assertFalse(map.verifySnagBarAvailibility(),
					"Snag bar related to location is still available on the Maps screen");

			// Enable live navigation check box
			readersPage.waitForSettings();
			readersPage.clickSettings();
			settings.clickPreferences();
			Assert.assertEquals(preferences.getHeaderText(), ObjectMap.getvalue("Preferences_Header_Txt"),
					"Unable to navigate Preferences page");
			preferences.clickLocationSettings();
			Thread.sleep(1000);
			Assert.assertEquals(location.getPageTitle(), ObjectMap.getvalue("locationSettings_Title_Txt"),
					"Unable to navigate to location settings page");

			location.clickLiveNavigation();
			sa.assertTrue(opt.verifyCheckBoxState(opt.checkBoxLiveNavigation()),
					"Live Navigation checkbox is not availabe under location settings.");

			sa.assertAll();
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
	}

	@Test(description = "Verfiy Get Directions functionality")
	public void verifyOptInScreen() throws Exception {
		try {
			sa.assertEquals(map.waitForLoading(), true, "Progress bar didn't disappear within mentioned time.");
			sa.assertTrue(opt.imgToggle().isDisplayed(), "Unable to navigate to location opt in screen.");
			sa.assertEquals(ObjectMap.getvalue("optin_title_Txt"), opt.getPageTitle(),
					"Screen title is not as expected");
			sa.assertEquals(ObjectMap.getvalue("optin_toggleText_Txt"), opt.getToggleText(),
					"Toggle text not as expected");
			// opt.clickToggle();
			sa.assertFalse(opt.verifyLiveNavigationAvailibility(), "Toggle functionality is not working as expected.");
			opt.clickToggle();

			sa.assertTrue(opt.checkBoxLiveNavigation().isDisplayed(), "Live Navigation checkbox is not available");
			opt.clickLiveNavigation();
			sa.assertFalse(opt.verifyCheckBoxState(opt.checkBoxLiveNavigation()),
					"Live Navigation checkbox didn't get turn off");
			opt.clickLiveNavigation();
			sa.assertTrue(opt.verifyCheckBoxState(opt.checkBoxLiveNavigation()),
					"Live Navigation checkbox didn't get turn On");

			if (GenericFunctions.isAndroid()) {
				sa.assertTrue(opt.checkBoxBGService().isDisplayed(), "Background Services checkbox is not available");
				opt.clickBGService();
				sa.assertFalse(opt.verifyCheckBoxState(opt.checkBoxBGService()),
						"Background Services checkbox didn't get turn off");
				opt.clickBGService();
				sa.assertTrue(opt.verifyCheckBoxState(opt.checkBoxBGService()),
						"Background Services checkbox didn't get turn On");
			}

			sa.assertTrue(opt.checkBoxGeofence().isDisplayed(), "Geofence checkbox is not available");
			opt.clickGeoFence();
			sa.assertFalse(opt.verifyCheckBoxState(opt.checkBoxGeofence()), "Geofence checkbox didn't get turn off");
			opt.clickGeoFence();
			sa.assertTrue(opt.verifyCheckBoxState(opt.checkBoxGeofence()), "Geofence checkbox didn't get turn On");

			if (GenericFunctions.isAndroid()) {
				sa.assertEquals(ObjectMap.getvalue("optin_verbiage_txt"), opt.getverbiage(),
						"Verbiage present in the location opt in screen not as expected");
			} else {
				sa.assertEquals(ObjectMap.getvalue("optin_verbiageiOS_txt"), opt.getverbiage(),
						"Verbiage present in the location opt in screen not as expected");
			}
			sa.assertTrue(opt.btnContinue().isDisplayed(), "Continue button is not available");
			sa.assertAll();
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
	}

	@Test(description = "Verfiy Get Directions functionality")
	public void verifyNoThanksFlowInOptInScreen() throws Exception {
		try {
			sa.assertTrue(opt.imgToggle().isDisplayed(), "Unable to navigate to location opt in screen.");
			// opt.clickToggle();
			sa.assertFalse(opt.imgToggle().isEnabled(), "Unable to toggle off the Location Services");

			sa.assertTrue(opt.btnNoThanks().isDisplayed(), "Unable to navigate to location opt in screen.");
			sa.assertEquals(ObjectMap.getvalue("optin_btn_noThanks_txt"), opt.getNoThanksBtnTxt(),
					"Button text for No Thanks is not as expected.");
			opt.clickNoThanks();

			sa.assertEquals(ObjectMap.getvalue("optin_verbiageNoThanks_txt"), opt.getMessageFromAlert(),
					"Verbiage on No Thanks alert is not as expected.");

			sa.assertTrue(opt.btnNoThanksInAlert().isDisplayed(), "Button 'No Thank you' is not available in alert");
			sa.assertEquals(ObjectMap.getvalue("optin_btnNoThanks_txt"), opt.getBtn2TextOnNoThanksAlert(),
					"Button 2 text is not as expected.");

			sa.assertTrue(opt.btnEnableInAlert().isDisplayed(), "Button 'Enable' is not available in alert");
			sa.assertEquals(ObjectMap.getvalue("optin_btnEnable_txt"), opt.getBtn1TextOnNoThanksAlert(),
					"Button 1 text 'Enable' is not as expected.");

			// Validate Enable button functionality
			opt.clickEnableInAlert();
			sa.assertTrue(opt.imgToggle().isEnabled(), "Location Services toggle didn't get turn ON");

			// Validate 'No Thank you' button functionality
			opt.clickToggle();
			opt.clickNoThanks();
			opt.clickNoThanksInAlert();
			sa.assertEquals(map.waitForLoading(), true, "Progress bar didn't disappear within mentioned time.");
			sa.assertFalse(map.verifySearchAvailibility(), "Unable to navigate to Maps tab");

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
	}

	@Test(description = "Verify RoutePreview flow")
	public void RoutePreviewFlow() throws Exception {
		try {
			sa.assertEquals(map.waitForLoading(), true, "Progress bar didn't disappear within mentioned time.");
			Assert.assertEquals(ObjectMap.getvalue("Preview_Title_txt"), route.getHeaderText());
			sa.assertTrue(route.cancelButton().isDisplayed(), "Unable to navigate to route preview");
			sa.assertTrue(route.btnRoutePreviewSteps().isDisplayed(), "Unable to find steps icon");
			sa.assertTrue(route.btnStartRoute().isDisplayed(), "Unable to find start route button");
			route.clickRoutePreviewSteps();
			Assert.assertEquals(ObjectMap.getvalue("Routepreview_Title_txt"), route.getHeaderText());
			sa.assertTrue(route.cancelButton().isDisplayed(),
					"Cancel button is not available in Route preview steps screen");
			sa.assertTrue(route.btnStartRoute().isDisplayed(),
					"Start Route button is not available in Route preview steps screen");
			sa.assertTrue(route.btnStartRouteicon().isDisplayed(),
					"Start Route icon button is not available in Route preview steps screen");
			route.clickbtnStartRouteicon();
			Thread.sleep(5000);
			route.clickbtnStartRoute();
			sa.assertTrue(route.cardsimage().isDisplayed(), "cards of directionot available in Route ");
			sa.assertTrue(route.floornumber().isDisplayed(), "Floor number is not available in Browse floors screen");
			// Verify Floor number
			route.clickRoutePreviewSteps();
			Assert.assertEquals(ObjectMap.getvalue("Routepreview_Title_txt"), route.getHeaderText());
			sa.assertTrue(route.cancelButton().isDisplayed(),
					"Cancel button is not available in Route preview steps screen");
			sa.assertFalse(route.verifyStartRouteAvailibility(),
					"Start Route button is  available in live Route screen");
			route.clickbtnStartRouteicon();
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
	}

	@Test(description = "Verify RoutePreview Cancel flow")
	public void RoutePreviewCancel() throws Exception {
		try {

			// Validate cancel button functionality from Preview Route
			sa.assertEquals(route.waitForStepsIconToAppear(), true, "Steps icon didn't appear within mentioned time.");
			Assert.assertEquals(ObjectMap.getvalue("Preview_Title_txt"), route.getHeaderText());
			sa.assertTrue(route.cancelButton().isDisplayed(), "Unable to navigate to route preview");
			sa.assertTrue(route.btnRoutePreviewSteps().isDisplayed(), "Unable to find steps icon");
			sa.assertTrue(route.btnStartRoute().isDisplayed(), "Unable to find start route button");
			route.clickBack();

			Assert.assertEquals(ObjectMap.getvalue("directions_pageTitle_txt"), directions.verifyPageTitle());
			sa.assertTrue(directions.btnPreviewRoute().isDisplayed(),
					"preview route is not disaplyed in getdirections screen");
			sa.assertTrue(directions.btn_cancel().isDisplayed(), "Unable to navigate to directions screen");
			directions.clickPreviewRoute();

			// Validate cancel button functionality from Steps screen
			sa.assertEquals(route.waitForStepsIconToAppear(), true, "Steps icon didn't appear within mentioned time.");
			Assert.assertEquals(ObjectMap.getvalue("Preview_Title_txt"), route.getHeaderText());
			sa.assertTrue(route.cancelButton().isDisplayed(), "Unable to navigate to route preview");
			sa.assertTrue(route.btnRoutePreviewSteps().isDisplayed(), "Unable to find steps icon");
			sa.assertTrue(route.btnStartRoute().isDisplayed(), "Unable to find start route button");

			route.clickRoutePreviewSteps();
			route.clickBack();
			Assert.assertEquals(ObjectMap.getvalue("directions_pageTitle_txt"), directions.verifyPageTitle());
			sa.assertTrue(directions.btnPreviewRoute().isDisplayed(),
					"preview route is not disaplyed in getdirections screen");
			sa.assertTrue(directions.btn_cancel().isDisplayed(), "Unable to navigate to directions screen");

			// Validate cancel button functionality from Start Route screen
			directions.clickPreviewRoute();
			sa.assertEquals(route.waitForStepsIconToAppear(), true, "Steps icon didn't appear within mentioned time.");
			route.clickbtnStartRoute();
			route.clickBack();
			Assert.assertEquals(ObjectMap.getvalue("directions_pageTitle_txt"), directions.verifyPageTitle());
			sa.assertTrue(directions.btnPreviewRoute().isDisplayed(),
					"preview route is not disaplyed in getdirections screen");
			sa.assertTrue(directions.btn_cancel().isDisplayed(), "Unable to navigate to directions screen");

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
	}

	@Test(description = "Verify Door Open functionality from Maps")
	public void validateDoorOpen() throws Exception {

		try {
			System.out.println("Start");
			sa.assertEquals(map.waitForLoading(), true, "Progress bar didn't disappear within mentioned time.");
			sa.assertEquals(map.waitForSearchIconToAppear(), true, "Search icon didn't appear within mentioned time.");

			map.clickReaders();
			String readerNameFromReadersTab = map.getReaderNameReaderTab();

			map.clickMaps();
			sa.assertEquals(map.waitForLoading(), true, "Progress bar didn't disappear within mentioned time.");
			sa.assertEquals(map.waitForSearchIconToAppear(), true, "Search icon didn't appear within mentioned time.");

			sa.assertTrue(map.doorOpenCard().isDisplayed(), "Card realted to door open didn't appear");
			sa.assertTrue(map.imgCloseCard().isDisplayed(), "Close icon on the door open card didn't appear");
			sa.assertTrue(map.imgDoorOpen().isDisplayed(), "Door Open status image didn't appear");
			sa.assertTrue(map.lblDoorName().isDisplayed(), "Door name didn't appear on the card");
			sa.assertTrue(map.lblDoorVerb().isDisplayed(), "Door name didn't appear on the card");

			String readerNameFromDoorOpenCard = map.getReaderName();
			sa.assertEquals(readerNameFromReadersTab, readerNameFromDoorOpenCard,
					"Door name didn't appear on the card");
			map.clickCloseIconOnDoorOpenCard();

			sa.assertTrue(map.pathwayLayout().isDisplayed(), "Pathway layout didn't appear");
			Assert.assertEquals(ObjectMap.getvalue("Home_lbl_pathwayLyout_txt"), map.getPathwayLayOutText());
			sa.assertTrue(map.imgClosePathwayLayout().isDisplayed(), "Close icon on Pathway layout didn't appear");
			sa.assertTrue(map.imgReaderPoiPathway().isDisplayed(), "Door icon on Pathway layout didn't appear");
			sa.assertTrue(map.btnUnlockDoor().isDisplayed(), "Unlock door button on Pathway layout didn't appear");
			sa.assertTrue(map.btnStartPathway().isDisplayed(), "Start pathway button on Pathway layout didn't appear");
			sa.assertTrue(map.lblPathwayLayout_readers().isDisplayed(),
					"Label Reader is not available on Pathway layout");
			sa.assertTrue(map.lblPathwayLayout_pathway().isDisplayed(),
					"Label Pathway is not available on Pathway layout");

			sa.assertTrue(map.lblReaderNameInPathwayLayout().isDisplayed(),
					"Reader Name is not available on Pathway layout");
			sa.assertTrue(map.lblPathwayNameInPathwayLayout().isDisplayed(),
					"Pathway Name is not available on Pathway layout");

			sa.assertAll();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(description = "Verify Start Pathway functionality from Maps")
	public void verifyPathwayFromMaps() throws Exception {

		try {
			sa.assertTrue(map.pathwayLayout().isDisplayed(), "Pathway layout didn't appear");
			Assert.assertEquals(ObjectMap.getvalue("Home_lbl_pathwayLyout_txt"), map.getPathwayLayOutText());
			sa.assertTrue(map.imgClosePathwayLayout().isDisplayed(), "Close icon on Pathway layout didn't appear");
			sa.assertTrue(map.imgReaderPoiPathway().isDisplayed(), "Door icon on Pathway layout didn't appear");
			sa.assertTrue(map.btnUnlockDoor().isDisplayed(), "Unlock door button on Pathway layout didn't appear");
			sa.assertTrue(map.btnStartPathway().isDisplayed(), "Start pathway button on Pathway layout didn't appear");
			sa.assertTrue(map.lblPathwayLayout_readers().isDisplayed(),
					"Label Reader is not available on Pathway layout");
			// sa.assertTrue(home.lblPathwayLayout_pathway().isDisplayed(), "Label Pathway
			// is not available on Pathway layout");

			sa.assertTrue(map.lblReaderNameInPathwayLayout().isDisplayed(),
					"Reader Name is not available on Pathway layout");
			sa.assertTrue(map.lblPathwayNameInPathwayLayout().isDisplayed(),
					"Pathway Name is not available on Pathway layout");

			sa.assertAll();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// Started Ravinder
	@Test(description = "Verify Route Preview Is  Displayed")
	public void verifyRoutepreviewisDisplayed() throws Exception {
		map.clickDirections();
		sa.assertEquals(ObjectMap.getvalue("Preview_Title_txt"), directions.btnPreviewRoutegettext());
	}

	@Test(description = "Verify Route Preview Is Not Displayed on Cliking on Direction")
	public void verifyRoutepreviewisnotDisplayed() throws Exception {
		map.clickDirections();
		sa.assertEquals(ObjectMap.getvalue("getDirection_chosestart_end_text"), directions.chooseStartandEndText());
		// sa.assertTrue(directions.btnPreviewRoutegettext().contentEquals(arg0));
		/*
		 * if(!directions) {
		 * 
		 * sa.assertTrue(arg0); System.out.println("Test pass"); }
		 * 
		 * else { System.out.println("Test Fail"); }
		 */
	}

	@Test(description = "Verify Skip btn on walkthrough ")
	public void verifySkip() throws Exception {
		walk.clickSkipbtn();
		System.out.println(opt.getPageTitle());

		if (GenericFunctions.isAndroid()) {
			System.out.println(consentform.consentformText());
			sa.assertEquals(ObjectMap.getvalue("Bluetooth_lbl_required"), consentform.consentformText());
			// a.assertEquals(ObjectMap.getvalue("optin_title_Txt"), opt.getPageTitle());
			System.out.println("Test passed");
		} else {
			System.out.println("ios Test");
			sa.assertEquals(ObjectMap.getvalue("optin_title_Txt"), opt.getPageTitle());
			System.out.println("Test passed");
		}
		/*
		 * if(consent.ConsentformHeaderText()) {
		 * 
		 * System.out.println(consent.consentformText()); ;
		 * 
		 * } else { System.out.println(opt.getPageTitle());
		 * sa.assertEquals(ObjectMap.getvalue("optin_title_Txt"), opt.getPageTitle());
		 */

		// sa.assertEquals(, arg1);
	}
//mapBackground locationLabel
//sa.assertEquals(, arg1);

	@Test()
	public void verifyContinue() throws Exception {
		verifySkip();
		if (opt.imgToggle().isEnabled())

		{
			opt.clickContinue();
		} else {
			System.out.println("Use my Location is Disabled");
		}

	}

	@Test
	public void verifySwipecards() throws Exception { // verifyGetDirections();
														// map.clickDirections();
														// map.startField();
		System.out.println("Ravinder test one ");
		System.out.println("Ravinder test one ");
		System.out.println(rp.FirstCardText());
		System.out.println(rp.NextimgText());
		rp.swipeDirectioncard();

	}

	@Test
	public void verifyApplyfilter() throws Exception {
		map.clickSearch();
	}

	@Test(description = "Verify Next Label is avaiable on on cards")
	public void VerifyNextlable() throws Exception {
		System.out.println("Ravinder test one ");
		System.out.println("Ravinder test one ");
		sa.assertEquals(ObjectMap.getvalue("Next_Title_txt"), rp.NextimgText());
	}

	// Pre requisite for VerifyNothanks change the app location setting to never to
	// run these testcase
	@Test()
	public void verifyNothanks() throws Exception {
		verifySkip();
		opt.clickNoThanks();
		System.out.println(map.mapErrormessagetext());
		sa.assertEquals(ObjectMap.getvalue("maps_erromessage"), map.mapErrormessagetext());

	}
	/*
	 * @Test() public void walkThrough() throws Exception { // TC.appLogin(); try {
	 * 
	 * sa.assertEquals(ObjectMap.getvalue("WalkthroughScreen_MapsAndDirections_txt")
	 * , walk.MapsAndDirectionsHeaderText()); sa.assertEquals(ObjectMap.getvalue(
	 * "WalkthroughScreen_mapsAndDirectionsDescription_txt"),
	 * walk.mapsandDirectionswalkthrough()); walk.skipBtn().isDisplayed();
	 * walk.clickwLearnMore(); Assert.assertTrue(help.waitforHelpHeader(),
	 * "Help page should be displayed"); help.clickBack();
	 * walk.swipewalkthroughscreen();
	 * sa.assertEquals(ObjectMap.getvalue("WalkthroughScreen_homescreen_txt"),
	 * walk.homescreenheader());
	 * sa.assertEquals(ObjectMap.getvalue("WalkThrough_homescreenDescription_txt"),
	 * walk.homescreenwalkthroughText()); walk.skipBtn().isDisplayed();
	 * walk.swipewalkthroughscreen();
	 * sa.assertEquals(ObjectMap.getvalue("WalkthroughScreen_menu_txt"),
	 * walk.menuheader());
	 * sa.assertEquals(ObjectMap.getvalue("WalkThrough_menuDescription_txt"),
	 * walk.menuwalkthroughText()); walk.skipBtn().isDisplayed();
	 * walk.swipewalkthroughscreen();
	 * sa.assertEquals(ObjectMap.getvalue("WalkthroughScreen_readeroptions_txt"),
	 * walk.readeroptionsheader());
	 * sa.assertEquals(ObjectMap.getvalue("WalkThrough_readeroptionsDescription_txt"
	 * ), walk.readeroptionswalkthroughText()); walk.skipBtn().isDisplayed();
	 * walk.swipewalkthroughscreen();
	 * sa.assertEquals(ObjectMap.getvalue("WalkthroughScreen_gesturesheader_txt"),
	 * walk.gesturesheader());
	 * sa.assertEquals(ObjectMap.getvalue("WalkThrough_gesturesDescription_txt"),
	 * walk.gestureswalkthroughText()); walk.skipBtn().isDisplayed();
	 * walk.swipewalkthroughscreen();
	 * sa.assertEquals(ObjectMap.getvalue("WalkthroughScreen_pathwaysheader_txt"),
	 * walk.pathwaysheader());
	 * sa.assertEquals(ObjectMap.getvalue("WalkThrough_pathwaysDescription_txt"),
	 * walk.pathwayswalkthroughText()); walk.skipBtn().isDisplayed();
	 * walk.swipewalkthroughscreen(); sa.assertEquals(ObjectMap.getvalue(
	 * "WalkthroughScreen_twofactorauthenticationheader_txt"),
	 * walk.twofactorauthenticationheader()); sa.assertEquals(ObjectMap.getvalue(
	 * "WalkThrough_twofactorauthenticationDescription_txt"),
	 * walk.twofactorauthenticationwalthroughText()); walk.skipBtn().isDisplayed();
	 * walk.swipewalkthroughscreen(); sa.assertEquals(ObjectMap.getvalue(
	 * "WalkthroughScreen_Health&SafetyTracking_txt"),
	 * walk.HealthAndSafetyTrackingHeader()); sa.assertEquals(ObjectMap.getvalue(
	 * "WalkthroughScreen_Health&SafetyTrackingDescription_txt"),
	 * walk.HealthAndSafetyTrackingwalkthroughText());
	 * 
	 * // walk.clickwLearnMore(); //Assert.assertTrue(help.waitforHelpHeader(),
	 * "Help page should be displayed"); // help.clickBack(); // walk.rclickDone();
	 * sa.assertAll(); } catch (Exception e) { // TODO Auto-generated catch block
	 * e.printStackTrace(); } }
	 */ // End Ravinder

	@Test(description = "Verfiy Get Directions functionality Fliter")
	public void verifyGetDirectionsFilter() throws Exception {
		try {
			sa.assertEquals(map.waitForLoading(), true, "Progress bar didn't disappear within mentioned time.");
			sa.assertEquals(map.waitForSearchIconToAppear(), true, "Search icon didn't appear within mentioned time.");
			Thread.sleep(1000);
			map.clickDirections();
			Assert.assertEquals(ObjectMap.getvalue("directions_pageTitle_txt"), directions.verifyPageTitle());
			sa.assertTrue(directions.btn_cancel().isDisplayed(),
					"Cancel button is not available in Get Direactions screen");

			sa.assertTrue(directions.imgDirection().isDisplayed(),
					"Directions image is not available in Get Direactions screen");
			Assert.assertEquals(ObjectMap.getvalue("directions_lbl_txt"), directions.getVerbiage(),
					"Verbiage displayed is not as expected");

			// Choose Start

			directions.clickOnStartFiled();
			directions.clickonFilter();
			sa.assertTrue(directions.btnFliterApply().isDisplayed(), "Filters apply button is not visible");
			// directions.clickConfernceRoom();
			// directions.clickClearfilter();
			directions.clickFilterApply();
			directions.clickFilterAllfloors();
			directions.clickCancel();
			sa.assertEquals(map.waitForLoading(), true, "Progress bar didn't disappear within mentioned time.");
			sa.assertEquals(map.waitForSearchIconToAppear(), true, "Search icon didn't appear within mentioned time.");

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}

	}

	@Test(description = "Verify directions card in the route preview screen. "
			+ "TC4752, TC4782, TC4784, TC4754, TC4670, TC4778, TC4671, TC4779, TC4986")
	public void verifyDirectionCard() throws Exception {

		try {

			int cardSize = route.getCardsSize();

			route.verifyCardSwipeMovement(cardSize);

			sa.assertTrue(route.lblCurrentStep().isDisplayed(), "Label Current step is not available on the card");
			sa.assertTrue(route.imgDirection().isDisplayed(), "Image direction is not available on the card");
			sa.assertTrue(route.lblNext().isDisplayed(), "Label Next is not available on the card");
			sa.assertTrue(route.imgNextDirection().isDisplayed(), "Image next direction is not available on the card");
			sa.assertTrue(route.lblNextStep().isDisplayed(), "Label next step is not available on the card");

			sa.assertAll();
			
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
	}

}
