package com.appium.Common;

import java.time.Duration;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;

public class Element {
	static Duration dt = Duration.ofSeconds(2);
	private static List<MobileElement> elements;
	private static MobileElement element;
	private static MobileElement childelement;
	static WebDriverWait wait = new WebDriverWait(AppiumSetup.driver,
			Integer.parseInt(new Configure().getDefaultWait()));

	static WebDriverWait customwait(int time) {
		return new WebDriverWait(AppiumSetup.driver, time);

	}

	// public static WebElement getElement() {
	// return element;
	// }
	//
	// public static WebElement setElement(WebElement element) {
	// Element.element = element;
	// return element;
	// }

	public static boolean waitForName(String text) throws Exception {
		return waitforVisible("name", text);
	}

	public static boolean waitForName(String text, int time) {
		return waitforVisible("name", text, time);
	}

	public static boolean waitForClass(String className) throws Exception {
		return waitforVisible("class", className);
	}

	public static boolean waitForClass(String className, int time) {
		return waitforVisible("class", className, time);
	}

	public static boolean waitForid(String id) throws Exception {
		return waitforVisible("id", id);
	}

	public static boolean waitForid(String id, int time) {
		return waitforVisible("id", id, time);
	}

	private static MobileElement findElement(String locatortype, String locator) throws Exception {
		switch (locatortype) {
		case "xpath":
			element = AppiumSetup.driver.findElement(By.xpath(locator));
			break;
		case "id":
			element = AppiumSetup.driver.findElement(By.id(locator));
			break;
		case "name":
			element = AppiumSetup.driver.findElement(By.name(locator));
			break;
		case "class":
			element = AppiumSetup.driver.findElement(By.className(locator));
			break;
		case "tag":
			element = AppiumSetup.driver.findElement(By.tagName(locator));
			break;
		}
		return element;
	}

	private static List<MobileElement> findElements(String locatortype, String locator) throws Exception {
		switch (locatortype) {
		case "xpath":
			elements = AppiumSetup.driver.findElements(By.xpath(locator));
			break;
		case "id":
			elements = AppiumSetup.driver.findElements(By.id(locator));
			break;
		case "name":
			elements = AppiumSetup.driver.findElements(By.name(locator));
			break;
		case "class":
			elements = AppiumSetup.driver.findElements(By.className(locator));
			break;
		case "tag":
			elements = AppiumSetup.driver.findElements(By.tagName(locator));
			break;
		}
		return elements;
	}

	private static List<MobileElement> findChildElements(String locatortype, String locator) throws Exception {
		switch (locatortype) {
		case "xpath":
			elements = element.findElements(By.xpath(locator));
			break;
		case "id":
			elements = element.findElements(By.id(locator));
			break;
		case "name":
			elements = element.findElements(By.name(locator));
			break;
		case "class":
			elements = element.findElements(By.className(locator));
			break;
		}
		return elements;
	}

	private static MobileElement findChildElement(String locatortype, String locator) throws Exception {
		switch (locatortype) {
		case "xpath":
			childelement = element.findElement(By.xpath(locator));
			break;
		case "id":
			childelement = element.findElement(By.id(locator));
			break;
		case "name":
			childelement = element.findElement(By.name(locator));
			break;
		case "class":
			childelement = element.findElement(By.className(locator));
			break;
		}
		return childelement;
	}

	public static MobileElement findElementbyID(String id) throws Exception {
		return findElement("id", id);
	}
	
	public static MobileElement findElementbyTag(String tagName) throws Exception {
		return findElement("tag", tagName);
	}

	public static MobileElement findElementbyClass(String className) throws Exception {
		return findElement("class", className);
	}

	public static MobileElement findElementbyXpath(String xpath) throws Exception {
		return findElement("xpath", xpath);
	}

	public static MobileElement findElementbyName(String name) throws Exception {
		return findElement("name", name);
	}

	public static List<MobileElement> findElementsbyID(String id) throws Exception {
		return findElements("id", id);
	}
	
	public static List<MobileElement> findElementsbyTag(String tagName) throws Exception {
		return findElements("tag", tagName);
	}

	public static List<MobileElement> findElementsbyName(String name) throws Exception {
		return findElements("name", name);
	}

	public static List<MobileElement> findChildElementsbyID(MobileElement webelement, String id) throws Exception {
		Element.element = webelement;
		return findChildElements("id", id);
	}

	public static MobileElement findChildElementbyID(MobileElement webelement, String id) throws Exception {
		Element.element = webelement;
		return findChildElement("id", id);
	}

	public static List<MobileElement> findChildElementsbyClass(MobileElement webelement, String className)
			throws Exception {
		Element.element = webelement;
		return findChildElements("class", className);
	}

	public static MobileElement findChildElementbyClass(MobileElement webelement, String className) throws Exception {
		Element.element = webelement;
		return findChildElement("class", className);
	}

	public static List<MobileElement> findChildElementsbyXpath(MobileElement webelement, String xpath)
			throws Exception {
		Element.element = webelement;
		return findChildElements("xpath", xpath);
	}

	public static List<MobileElement> findChildElementsbyName(MobileElement webelement, String text) throws Exception {
		Element.element = webelement;
		return findChildElements("name", text);
	}

	public static List<MobileElement> findElementsbyClass(String className) throws Exception {
		return findElements("class", className);
	}

	public static MobileElement findElementbyClassIndex(String className, int index) throws Exception {
		return findElements("class", className).get(index);
	}

	public static MobileElement findElementbyIdIndex(String id, int index) throws Exception {
		return findElements("id", id).get(index);
	}

	public static List<MobileElement> findElementsbyXpath(String xpath) throws Exception {
		return findElements("xpath", xpath);
	}

	public static List<MobileElement> findElemenstbyName(String name) throws Exception {
		return findElements("name", name);
	}

	public static MobileElement findElemenstbyNameIndex(String name, int index) throws Exception {
		return findElements("name", name).get(index);
	}

	public static boolean waitForElement(MobileElement ele) {
		try {
			wait.until(ExpectedConditions.visibilityOf(ele));
		} catch (Exception e) {
			System.out.println("element not found :" + ele);
			return false;
		}
		return true;
	}

	public static boolean waitForElement(MobileElement ele, int sec) {
		try {
			customwait(sec).until(ExpectedConditions.elementToBeClickable(ele));
		} catch (Exception e) {
			System.out.println("element not found :" + ele);
			return false;
		}
		return true;
	}

	public static boolean waitforInVisibility(String locatorType, String locator, int time) {

		try {
			switch (locatorType) {
			case "xpath":
				customwait(time).until(ExpectedConditions.invisibilityOfElementLocated(MobileBy.xpath(locator)));
				break;
			case "class":
				customwait(time).until(ExpectedConditions.invisibilityOfElementLocated(MobileBy.className(locator)));
				break;
			case "id":
				customwait(time).until(ExpectedConditions.invisibilityOfElementLocated(MobileBy.id(locator)));
				break;
			case "name":
				customwait(time).until(ExpectedConditions.visibilityOfElementLocated(MobileBy.name(locator)));
				break;
			}
		} catch (Exception e) {
			System.out.println("element not found :" + locator);
			return false;
		}
		return true;
	}

	public static boolean waitForElementInvisible(MobileElement ele, int sec) {
		try {
			customwait(sec).until(ExpectedConditions.invisibilityOf(ele));
		} catch (Exception e) {
			System.out.println("element not found :" + ele);
			return false;
		}
		return true;
	}

	public static String getAttribute(MobileElement ele, String AttributeName) {
		return ele.getAttribute(AttributeName);
	}

	public static Boolean getCheckBoxStatus(MobileElement ele) {
//		boolean t=Boolean.parseBoolean(GenericFunctions.getInstance().isCheckBoxSelected(ele));
		return Boolean.parseBoolean(GenericFunctions.getInstance().isCheckBoxSelected(ele));
	}

	public static String getElementText(MobileElement ele) {
		return ele.getText();
	}

	public static String getTextfromTextbx(MobileElement ele) {
		return GenericFunctions.getInstance().getTextfromTextBox(ele);
	}

	public static boolean isVisible(MobileElement ele) {
		if (GenericFunctions.isIOS()) {
			return Boolean.valueOf(ele.getAttribute("visible"));
		} else if (GenericFunctions.isAndroid()) {

		}
		return false;
	}

	public static boolean isEnabled(MobileElement ele) {
//		if (GenericFunctions.isIOS()) {
			return Boolean.valueOf(ele.getAttribute("enabled"));
//		} else if (GenericFunctions.isAndroid()) {
//
//		}
//		return false;
	}

	public static void type(MobileElement ele, String text) throws Exception {

		try {
			ele.clear();
			ele.sendKeys(text);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (GenericFunctions.isAndroid()) {
				GenericFunctions.pressBack();
			}
			if (GenericFunctions.isIOS()) {
				findElementbyID("Done").click();
			}

		}

	}

	public static void selectFromListBox(String value) throws Exception {
		if (GenericFunctions.isIOS()) {
			findElementsbyClass("UIAPickerWheel").get(0).sendKeys(value);
			findElementbyID("Toolbar").findElementByClassName(GenericFunctions.getInstance().getButtonClass()).click();
			Thread.sleep(1000);
		} else if (GenericFunctions.isAndroid()) {
			findElementbyName(value).click();
			GenericFunctions.acceptAlert();
		}
	}

	public static boolean waitforVisible(String locatorType, String locator) throws Exception {

		try {
			switch (locatorType) {
			case "xpath":
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(locator)));
				break;
			case "class":
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.className(locator)));
				break;
			case "id":
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(locator)));
				break;
			case "name":
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.name(locator)));
				break;
			}
		} catch (Exception e) {
			System.out.println("element not found :" + locator);
			return false;
		}
		return true;
	}
	
	
	public static boolean waitforElementPresent(String locatorType, String locator) throws Exception {

		try {
			switch (locatorType) {
			case "xpath":
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(locator)));
				break;
			case "class":
				wait.until(ExpectedConditions.presenceOfElementLocated(By.className(locator)));
				break;
			case "id":
				wait.until(ExpectedConditions.presenceOfElementLocated(By.id(locator)));
				break;
			case "name":
				wait.until(ExpectedConditions.presenceOfElementLocated(By.name(locator)));
				break;
			}
		} catch (Exception e) {
			System.out.println("element not found :" + locator);
			return false;
		}
		return true;
	}

	public static boolean waitforVisible(String locatorType, String locator, int time) {

		try {
			switch (locatorType) {
			case "xpath":
				customwait(time).until(ExpectedConditions.visibilityOfElementLocated(MobileBy.xpath(locator)));
				break;
			case "class":
				customwait(time).until(ExpectedConditions.visibilityOfElementLocated(MobileBy.className(locator)));
				break;
			case "id":
				customwait(time).until(ExpectedConditions.visibilityOfElementLocated(MobileBy.id(locator)));
				break;
			case "name":
				customwait(time).until(ExpectedConditions.visibilityOfElementLocated(MobileBy.name(locator)));
				break;
			}
		} catch (Exception e) {
			System.out.println("element not found :" + locator);
			return false;
		}
		return true;
	}

	public static String getPopupText() throws Exception {
		if (GenericFunctions.isIOS()) {
			waitForClass("UIAAlert", 5);
			String alertText = null;
			MobileElement alertElement = findElementbyClass("UIAAlert");
			Alert alert = AppiumSetup.driver.switchTo().alert();
			String alertTitle = alertElement.getText();
			alertText = alert.getText();
			System.out.println(alertTitle.length());
			if (alertTitle.length() != 0)
				alertText = alertText.replace(alertTitle + " ", "");
			System.out.println("Alert Text : " + alertText);
			return alertText;
		} else {
			if (waitForClass("android.widget.FrameLayout")) {
				MobileElement alertElement = findElementbyClass("android.widget.TextView");
				return alertElement.getText();
			} else {
				System.out.println("Alert not found");
			}
			return null;
		}
	}

	public static void swipeUp(int percent) throws Exception {
		System.out.println("swipeUp");
		Dimension resolution = getScreenResolution();
		int startx, starty, endx, endy;
//		int heightToSwipe = percent * resolution.height / 100;
		starty = (int) (resolution.height * 0.2);
		endy = (int) (resolution.height * percent / 100);
		startx = (int) (resolution.width * 0.8);
		endx = (int) (resolution.width * 0.8);
		// Handle worst boundary case.
		if (endy > resolution.height) {
			endy = endy - 10;
		}
//		swipe((int) (resolution.width * 0.8), (int) (resolution.height * 0.1), (int) (resolution.width * 0.8),(int) (resolution.height * 0.9));
//		swipe((int)(startx/13), (int)(starty*0.60), (int)(endx/13), (int)(endy*(0.30)));
		swipe(startx, starty, endx, endy);
	}

	public static void swipeDown(int percent) throws Exception {
		System.out.println("swipeDown");
		Dimension resolution = getScreenResolution();
		int startx, starty, endx, endy;
		int heightToSwipe = percent * resolution.height / 100;
		starty = resolution.height - ((resolution.height - heightToSwipe) / 2);
		endy = starty - heightToSwipe;
		startx = resolution.width / 2;
		endx = resolution.width / 2;
		// Handle worst boundary case.
		if (endy <= 0) {
			endy = 10;
		}
		swipe(startx, starty, endx, endy);
	}

	public static void swipeLeft(MobileElement ele, int percentWidthToSwipe) throws Exception {
		System.out.println("swipeLeft");
	    Dimension resolution = ele.getSize();
		int startx, starty, endx, endy;
		starty = (int) (resolution.height * 0.8);
		endy = (int) (resolution.height * 0.8);
		endx = (int) (resolution.width * 0.1);
		startx = (int) (resolution.width * percentWidthToSwipe / 100);
		// Handle worst boundary case.
//		if (endx <= 0) {
//			endx = 10;
//		}
		swipe(startx, starty, endx, endy);
//		Dimension resolution = getScreenResolution();
//		Dimension size = ele.getSize();
//		Point centerPoint = new Point(0, 0);
//		centerPoint = getCenter(ele);
//		int startx, starty, endx, endy;
//		int widthToSwipe = percentWidthToSwipe * size.width / 100;
//		starty = centerPoint.y;
//		endy = centerPoint.y;
//		startx = centerPoint.x + widthToSwipe / 2;
//		endx = centerPoint.x - widthToSwipe / 2;
//		// Handle worst boundary case.
//		if (endx <= 0) {
//			endx = 10;
//		}
//		if (startx > resolution.width) {
//			startx = resolution.width - 10;
//		}
//		// if () {
//		// Need to write code for ios
//		// } else {
//		swipe(startx, starty, endx-startx, endy-starty);
//		// }
	}

	static boolean scrollTo(String value) {
		while (AppiumSetup.driver.findElements(By.id(value)).size() == 0) {
			Dimension dimensions = AppiumSetup.driver.manage().window().getSize();
			Double screenHeightStart = dimensions.getHeight() * 0.5;
			int scrollStart = screenHeightStart.intValue();
			Double screenHeightEnd = dimensions.getHeight() * 0.2;
			int scrollEnd = screenHeightEnd.intValue();
			new TouchAction(AppiumSetup.driver).press(Gestures.getPointOption(0, scrollStart)).waitAction()
					.moveTo(Gestures.getPointOption(0, scrollEnd)).release().perform();
		}
		if (AppiumSetup.driver.findElements(By.id(value)).size() > 0) {
			return true;
		} else
			return false;
	}

	public static void swipeSliderLeft(MobileElement ele, int percentWidthToSwipe) throws Exception {
		MobileElement slider = ele;
		Dimension size = slider.getSize();
		String seekBarPosition = slider.getAttribute("value");
		double seekabrPoint = Double.parseDouble(seekBarPosition.substring(0, seekBarPosition.length() - 1)) / 100;
//	        ElementOption press = Gestures.getElementOption(slider, (int)(size.width *((float)seekabrPoint))+ 1, size.height / 2);
//	        ElementOption move = Gestures.getElementOption(slider, (int)((size.width)*((float)percentWidthToSwipe/100)), size.height / 2);
//
//	        new TouchAction(AppiumSetup.driver).longPress(press)
//	                .waitAction(Gestures.getWaitOption(dt))
//	                .moveTo(move).release().perform();

//	        swipe.perform();
		MobileElement seek_bar = ele;
		System.out.println(ele.getText());
		// get location of seek bar from left
		int start = (int) (seek_bar.getSize().getWidth() * ((float) seekabrPoint)) + seek_bar.getLocation().getX();
		System.out.println("Startpoint - " + start);

		// get location of seekbar from top
		int y = seek_bar.getLocation().getY();
		System.out.println("Yaxis - " + y);

		// Get total width of seekbar
		int end = seek_bar.getSize().getWidth();
		System.out.println("End point - " + end);

//        TouchAction action=new TouchAction(Setup.driver);
		// move slider to 70% of width
		int moveTo = (int) (end * (float) percentWidthToSwipe / 100) + seek_bar.getLocation().getX();
		System.out.println("move to point - " + moveTo);
ele.setValue("0.5");
		swipe(start, y, moveTo, y, 20);
//        action.longPress(seek_bar).moveTo(seek_bar, 1, 0).release().perform();
//        action.longPress(start,y).moveTo(moveTo,y).release().perform();
	}

	public static void swipeSliderRight(MobileElement ele, int percentWidthToSwipe) throws Exception {
		MobileElement seek_bar = ele;
		String seekBarPosition = seek_bar.getAttribute("value");
		double seekabrPoint = Double.parseDouble(seekBarPosition.substring(0, seekBarPosition.length() - 1)) / 100;
		// get location of seek bar from left
		int start = (int) (seek_bar.getSize().width * ((float) seekabrPoint));
		System.out.println("Startpoint - " + start);

		// get location of seekbar from top
		int y = seek_bar.getLocation().getY();
		System.out.println("Yaxis - " + y);

		// Get total width of seekbar
		int end = seek_bar.getSize().getWidth();
		System.out.println("End point - " + end);

		int moveTo = (int) ((seek_bar.getSize().width) * ((float) percentWidthToSwipe / 100));

//        int start=seek_bar.getLocation().getX();
//        System.out.println("Startpoint - " + start);
//        
//        //get location of seekbar from top
//        int y=seek_bar.getLocation().getY();
//        System.out.println("Yaxis - "+ y);
//        
//        //Get total width of seekbar
//        int end=seek_bar.getSize().getWidth();
//        System.out.println("End point - "+ end);
//        
//        int moveTo=(int)(end*0.3);

		swipe(start, y, moveTo, y);
	}
	
	
	
	public static void setSliderVal(MobileElement ele, int percentWidthToset) throws Exception {
		MobileElement slider = ele;
		Dimension size = slider.getSize();
		String seekBarPosition = slider.getAttribute("value");
		double seekabrPoint;
		if(new Configure().isiOS())
			try {
				seekabrPoint = Double.parseDouble(seekBarPosition.substring(0, seekBarPosition.length() - 1)) / 100;
			}catch (Exception e) {
				try {
					seekabrPoint = Double.parseDouble(seekBarPosition.substring(0, seekBarPosition.length() - 2)) / 100;
				}catch (Exception ex) {
					seekabrPoint = Double.parseDouble(seekBarPosition.substring(1, seekBarPosition.length())) / 100;
				}
			}
			
		else
			seekabrPoint = seekBarPosition.length()-1/100;
//	        ElementOption press = Gestures.getElementOption(slider, (int)(size.width *((float)seekabrPoint))+ 1, size.height / 2);
//	        ElementOption move = Gestures.getElementOption(slider, (int)((size.width)*((float)percentWidthToSwipe/100)), size.height / 2);
//
//	        new TouchAction(AppiumSetup.driver).longPress(press)
//	                .waitAction(Gestures.getWaitOption(dt))
//	                .moveTo(move).release().perform();

//	        swipe.perform();
		MobileElement seek_bar = ele;
		System.out.println(ele.getText());
//		ele.click();
		// get location of seek bar from left
		int start = (int) (seek_bar.getSize().getWidth() * ((float) seekabrPoint) + seek_bar.getLocation().getX());
		if(start>seek_bar.getSize().getWidth())
		{
			start = seek_bar.getSize().getWidth();
		}
		System.out.println("Startpoint - " + start);

		// get location of seekbar from top
		int y = (int)(seek_bar.getLocation().getY()+seek_bar.getSize().getHeight()* 0.5);
		System.out.println("Yaxis - " + y);

		// Get total width of seekbar
		int end = (int) (((int) ((seek_bar.getSize().width) * ((float) percentWidthToset / 100)) )+( seek_bar.getSize().width / (11-(float) percentWidthToset/100)));
		System.out.println("End point - " + end);

//        TouchAction action=new TouchAction(Setup.driver);
		// move slider to 70% of width
		int moveTo = (int) (end * (float) percentWidthToset / 100) + seek_bar.getLocation().getX();
		System.out.println("move to point - " + moveTo);
//		if(start>end) {
//			end=+(int)(seek_bar.getSize().getWidth()/ 100);
//		}
//		else
//		{
//			end=end+end / 100;
//		}

		swipe(start, y, end, y, 20);
//        action.longPress(seek_bar).moveTo(seek_bar, 1, 0).release().perform();
//        action.longPress(start,y).moveTo(moveTo,y).release().perform();
	}
	

	public static void swipeTop(MobileElement ele, int percentHeightToSwipe) throws Exception {
		Dimension resolution = getScreenResolution();
		Dimension size = ele.getSize();
		Point centerPoint = new Point(0, 0);
		centerPoint = getCenter(ele);
		int startx, starty, endx, endy;
		int heightToSwipe = percentHeightToSwipe * size.height / 100;
		startx = centerPoint.x;
		endx = centerPoint.x;
		starty = centerPoint.y + heightToSwipe / 2;
		endy = centerPoint.y - heightToSwipe / 2;
		// Handle worst boundary case.
		if (starty <= 0) {
			starty = 10;
		}
		if (endy > resolution.height) {
			endy = resolution.height - 10;
		}
		// if () {
		// Need to write code for ios
		// } else {
		swipe(startx, starty, endx, endy);
		// }
	}

	public static Dimension getScreenResolution() {
		System.out.println("Obtaining Device screen resolution");
		//SwitchContext.switchToNativeContext();
		Dimension dimension = AppiumSetup.driver.manage().window().getSize();
		// SwitchContext.switchToWebViewContext();
		// dimension = getNewDimension(dimension);
		return dimension;
	}

	public static void swipe(int startx, int starty, int endx, int endy) {
//		TouchAction swipe = new TouchAction(AppiumSetup.driver).longPress(Gestures.getPointOption(startx, starty))
//				.waitAction(Gestures.getWaitOption(dt)).moveTo(Gestures.getPointOption(endx, endy)).release();
//		swipe.perform();

		new TouchAction<>(AppiumSetup.driver).press(PointOption.point(startx, starty))
				.waitAction(WaitOptions.waitOptions(Duration.ofMillis(1000))).moveTo(PointOption.point(endx, endy))
				.release().perform();
	}

	public static void swipe(int startx, int starty, int endx, int endy, int time) {

		TouchAction swipe = new TouchAction(AppiumSetup.driver).longPress((Gestures.getPointOption(startx, starty)))
				.waitAction(Gestures.getWaitOption(Duration.ofSeconds(time)))
				.moveTo(Gestures.getPointOption(endx, endy)).release();
		swipe.perform();
	}

	public static Point getCenter(MobileElement element) throws Exception {
		Point upperLeft = element.getLocation();
		Dimension dimensions = element.getSize();
		return new Point(upperLeft.getX() + dimensions.getWidth() / 2, upperLeft.getY() + dimensions.getHeight() / 2);
	}

	public static void scrollTO(MobileElement ele) {
		HashMap<String, String> arguments = new HashMap<String, String>();
		arguments.put("element", ele.getAttribute("id"));
		JavascriptExecutor js = (JavascriptExecutor) (AppiumSetup.driver);
		js.executeScript("mobile: scrollTo", arguments);
	}

	public static boolean scrollUntilVisibleBy(String direction, String locatorType, String locator) throws Exception {
		System.out.println("scrollUntilVisibleBy");
		int scrollCount = 6;
		int count = 0;
		do {
			// See if the element is visible.
			try {
				if (Element.waitForElement(Element.findElement(locatorType, locator), 1) && !GenericFunctions.isIOS()) {
					return true;
				}
			} catch (Exception e) {
			}
			if (GenericFunctions.isIOS()) {
				// For iOS we could simply scrollTo given element.
				scrollTO(Element.findElement(locatorType, locator));
			} else {
				switch (direction) {
				case "UP":
					swipeUp(70);
					break;
				case "DOWN":
					swipeDown(70);
					break;
				case "RIGHT":
					// swipeRight();
					break;
				case "LEFT":
					// swipeLeft(ele, 70);
					break;
				default:
					throw new Exception(
							"Invalid direction received. Only UP, DOWN, RIGHT, LEFT are allowed. Current value is : "
									+ direction);
				}
			}
			// We try 5 times, each time there is enough timeout in finding
			// elements. This must be more than enough.
			count++;
		} while (count < scrollCount);
		return false;
	}

//	public static void clickonElementWithPosition(MobileElement ele,int x, int y) {
//		TouchAction swipe = new TouchAction(AppiumSetup.driver).tap(Gestures.getElementOption(ele, ele.getSize().getHeight(), ele.getSize().width)).perform();
//	}
}
