package com.appium.Common;

import io.appium.java_client.MobileElement;
import io.appium.java_client.clipboard.HasClipboard;

public class IOSWidget extends GenericFunctions {

	public String getLableClass() throws Exception {
		return "XCUIElementTypeStaticText";
	}
	
	public String getViewClass() throws Exception {
		return "XCUIElementTypeStaticText";
	}

	public String getButtonClass() throws Exception {
		return "XCUIElementTypeButton";
	}

	public String getTableCellClass() {
		return "XCUIElementTypeCell";
	}

	public String getWindowClass() {
		return "XCUIElementTypeWindow";
	}

	public String getTableClass() {
		return "XCUIElementTypeTable";
	}

	public boolean isKeyboard() throws Exception {
		return Element.waitForClass("XCUIElementTypeKeyboard");
	}

	public MobileElement deviceBluetoth() throws Exception {
		// int OS = Integer.parseInt(new
		// Configure().getMobileOSVersion().split("\\.")[0]);
		if (getMobileVersion() < 10)
			return Element.findElementbyID("Bluetooth");
		else
			return Element.findElementbyID("bluetooth-button");
	}

	public int getMobileVersion() {
		int OS = Integer.parseInt(new Configure().getMobileOSVersion().split("\\.")[0]);
		return OS;
	}

	public MobileElement deviceWifi() throws Exception {
		// int OS = Integer.parseInt(new
		// Configure().getMobileOSVersion().split("\\.")[0]);
		if (getMobileVersion() < 10)
			return Element.findElementbyID("Wi-Fi");
		else
			return Element.findElementbyID("wifi-button");
	}

	@Override
	public String getAlertMessage() throws Exception {
//		String alertTitle;
		String alertText;
		if (getMobileVersion() < 10) {
//			alertTitle = Element.findElementbyClass("UIAAlert").getText();
			alertText = AppiumSetup.driver.switchTo().alert().getText();
//			if (alertTitle.length() != 0)
//				alertText = alertText.replace(alertTitle + " ", "");
			return alertText;
		} else {
			alertText = Element.findElementbyClass("XCUIElementTypeAlert").findElementsByClassName(getLableClass()).get(1).getText();
//			alertText = AppiumSetup.driver.switchTo().alert().getText();
//			if (alertTitle.length() != 0)
//				alertText = alertText.replace(alertTitle + " ", "");
			return alertText;
		}
	}
	
	@Override
	public String getAlertTitle() throws Exception {
		String alertTitle;
		if (getMobileVersion() < 10) {
			alertTitle = Element.findElementbyClass("UIAAlert").getText();
			return alertTitle;
		} else {
			alertTitle = Element.findElementbyClass("XCUIElementTypeAlert").findElementsByClassName(getLableClass()).get(0).getText();
			return alertTitle;
		}
	}

	@Override
	public String isCheckBoxSelected(MobileElement ele) {
		return Element.getAttribute(ele, "label");
	}

	@Override
	public void pasteText(String s) {
		((HasClipboard) AppiumSetup.driver).setClipboardText(s);
		
	}
	
	public static MobileElement Settings() throws Exception {
		try {
			return Element.findElementbyID("Settings");
		}catch (Exception e) {
			return null;
		}
	}
	
	@Override
	public void NavigateToSettingsPage() throws Exception {
		try {
				int count=0;
				while (!Element.waitForElement(Settings(), 1)) {
					new Gestures().scrollFromLeftToRightOfScreen();
					count++;
					if (count > 10)
						break;
				}
				Settings().click();
				while (!Element.waitForElement(iOSsettingsMainPage(), 1)) {
					Element.findElementsbyClass(GenericFunctions.getInstance().getButtonClass()).get(0).click();
				}

				while (!Element.waitForElement(BluetoothCell(), 1)) {
					Element.swipeUp(90);
				}
				// Element.scrollUntilVisibleBy("DOWN", "xpath",
				// "//XCUIElementTypeCell[@name=\"Bluetooth\"]");
				// Element.scrollTO(Element.findElementbyXpath("//XCUIElementTypeCell[@name=\"Bluetooth\"]"));
		} catch (Exception e) {

		}
	}

	@Override
	public String getImageButtonClass() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean getBluetoothStatus() {
		String Status = null;
		try {
			Status = Element.findElementbyXpath("//XCUIElementTypeCell[@name=\"Bluetooth\"]")
					.findElementsByClassName(GenericFunctions.getInstance().getLableClass()).get(1).getText();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (Status.equalsIgnoreCase("OFF")) {
			return false;
		} else {
			return true;
		}
	}

	@Override
	protected void clickBluetoothSwitch() {
		try {
			Element.findElementbyID("Bluetooth").click();
			Element.findElementbyXpath("//XCUIElementTypeSwitch[@name=\"Bluetooth\"]").click();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public Boolean getWifiStatus() {
		String Status = null;
		
			try {
				Status = Element.getTextfromTextbx(Element.findElementbyID("Wi-Fi"));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (Status.equalsIgnoreCase("OFF")) {
				return false;
			} else {
				return true;
			}
		
				
	}

	@Override
	protected void clickWifiSwitch() {
		try {
			Element.findElementbyID("Wi-Fi").click();
			Element.findElementbyXpath("//XCUIElementTypeSwitch[@name=\"Wi-Fi\"]").click();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public String getTextfromTextBox(MobileElement ele) {
		return ele.getAttribute("value");
	}

	@Override
	public String getProgressBarClass() {
		// TODO Auto-generated method stub
		return "UIAImage";
	}

	@Override
	public String getDialogClass() {
		// TODO Auto-generated method stub
		return null;
	}

	

}
