package com.appium.Common;

import java.util.Set;

import io.appium.java_client.MobileElement;
/**
 * @author SPA_Web_QA_team
 * adopted as per requirements of Stargate
 * This class is useful in switching context when working on SPA automation
 */
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;

public class SwitchContext {
	public enum Context {
		NATIVE(0), WEB(1);
		private int value;

		private Context(int value) {
			this.value = value;
		}

		public int getValue() {
			return this.value;
		}
	};

	public static void switchToNativeContext() {
		switchContext(Context.NATIVE);
	}

	public static void switchToWebViewContext() {
		try {
			if (GenericFunctions.isAndroid()) {
				if (((AndroidDriver<MobileElement>)AppiumSetup.driver).getContext().equals(
						"NATIVE_APP")) {
					switchContext(Context.WEB);
				}
			}  else {
				if (((IOSDriver<MobileElement>)AppiumSetup.driver).getContext().equals("NATIVE_APP")) {
					switchContext(Context.WEB);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void switchContext(Context context) {
		try {
			if (GenericFunctions.isAndroid()) {
				Set<String> contextNames = ((AndroidDriver<MobileElement>)AppiumSetup.driver)
						.getContextHandles();
				((AndroidDriver<MobileElement>)AppiumSetup.driver).context((String) contextNames
						.toArray()[context.getValue()]);
			} else {
				Set<String> contextNames = ((IOSDriver<MobileElement>)AppiumSetup.driver)
						.getContextHandles();
				((IOSDriver<MobileElement>)AppiumSetup.driver).context((String) contextNames
						.toArray()[context.getValue()]);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
	
	
	public static String getContext() {
//		try {
			if (GenericFunctions.isAndroid()) {
				return ((AndroidDriver<MobileElement>)AppiumSetup.driver).getContext();
//				if (((AndroidDriver<MobileElement>)AppiumSetup.driver).getContext().equals(
//						"NATIVE_APP")) {
//					switchContext(Context.WEB);
//				}
			}  else {
				return ((IOSDriver<MobileElement>)AppiumSetup.driver).getContext();
//				if (((IOSDriver<MobileElement>)AppiumSetup.driver).getContext().equals("NATIVE_APP")) {
//					switchContext(Context.WEB);
//				}
			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return null;
	}

}
