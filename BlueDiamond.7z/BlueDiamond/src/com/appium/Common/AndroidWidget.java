package com.appium.Common;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import io.appium.java_client.MobileElement;

public class AndroidWidget extends GenericFunctions{

	public  String getLableClass() throws Exception {
		return "android.widget.TextView";
	}
	
	public  String getDialogClass() {
		return "android.app.Dialog";
	}
	
	public  String getViewClass() throws Exception {
		return "android.view.View";
	}
	
	public  String getProgressBarClass(){
		return "android.widget.ProgressBar";
	}

	public  String getButtonClass() throws Exception {
			return "android.widget.Button";
	}
	
	public   String getTableCellClass(){
			return ""; //Need to enter table cell name for android
	}
	
	public   String getWindowClass(){
			return ""; //Need to enter table cell name for android
	}
	
	public   String getTableClass(){
			return ""; //Need to enter table cell name for android
	}
	
	public  boolean isKeyboard() throws Exception{
		return false; //need to write code for android
	}
	
	public MobileElement deviceBluetoth() throws Exception{
//		need to implement android code
		int OS = Integer.parseInt(new Configure().getMobileOSVersion().split(".")[0]);
		if(OS<10)
		return Element.findElementbyID("Bluetooth");
		else
			return Element.findElementbyID("bluetooth-button");	
	}
	
	public MobileElement deviceWifi() throws Exception{
		int OS = Integer.parseInt(new Configure().getMobileOSVersion().split(".")[0]);
		if(OS<10)
		return Element.findElementbyID("Wi-Fi");
		else
			return Element.findElementbyID("wifi-button");	
	}

	/*@Override
	public String getAlertMessage() throws Exception {
		return Element.findElementbyClass("android.widget.TextView")
				.getText();
	}*/

	@Override
	public String getAlertTitle() throws Exception {
		return Element.findElementsbyClass("android.widget.TextView").get(0)
				.getText();

	}
	
	public String getAlertMessage() throws Exception {
		return Element.findElementsbyClass("android.widget.TextView").get(1)
				.getText();
	}
	
	@Override
	public String isCheckBoxSelected(MobileElement ele) {
		return Element.getAttribute(ele, "checked");
	}

	@Override
	public void pasteText(String s) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void NavigateToSettingsPage() throws Exception {
//		AppiumSetup.driver.activateApp("com.android.settings");
//		AppiumSetup.driver.executeScript(script, args);
		 try {
	          Runtime.getRuntime().exec("adb shell am start -a android.settings.SETTINGS");
	     } catch (Exception e) {
	        e.printStackTrace();
	     }
		 Element.findElementsbyID("title").get(0).click();
//		adb shell am start -a android.intent.action.MAIN -n com.android.settings/.wifi.WifiSettings
		// TODO Auto-generated method stub
		
	}
	
	

	@Override
	public String getImageButtonClass() throws Exception {
		return "android.widget.ImageButton";
	}

	public MobileElement getBluetoothSwitch() {
		try {
			return Element.findElementsbyID("switch_widget").get(1);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public MobileElement getWifiSwitch() {
		try {
			return Element.findElementsbyID("switch_widget").get(0);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	@Override
	public Boolean getBluetoothStatus() {
		String Status = null;
		try {
			Status = getBluetoothSwitch().getAttribute("checked");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return Boolean.valueOf(Status);
	}

	@Override
	protected void clickBluetoothSwitch() {
		getBluetoothSwitch().click();
	}
	
	@Override
	public Boolean getWifiStatus() {
		String Status = null;
		try {
			Status = getWifiSwitch().getAttribute("checked");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return Boolean.valueOf(Status);
	}

	@Override
	protected void clickWifiSwitch() {
		getWifiSwitch().click();
	}

	@Override
	public String getTextfromTextBox(MobileElement ele) {
		return ele.getText();
	}
	
}
