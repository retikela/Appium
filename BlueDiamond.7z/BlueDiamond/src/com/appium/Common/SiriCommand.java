package com.appium.Common;

import java.util.HashMap;

import org.openqa.selenium.JavascriptException;
import org.openqa.selenium.JavascriptExecutor;

import io.appium.java_client.MobileElement;
import io.appium.java_client.ios.IOSDriver;

public class SiriCommand {

	public void testSiriCommand(String command) {
		try {
			HashMap<String, String> args = new HashMap<>();
			args.put("text", command);
			JavascriptExecutor js = (JavascriptExecutor) AppiumSetup.driver;
			js.executeScript("mobile: siriCommand", args);
		} catch (JavascriptException e) {
			AppiumSetup.driver.executeScript("seetest:client.activateVoiceAssistance(" + command + ");");
		}
		try {
			Element.waitforElementPresent(command, "id");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//        wait.until(ExpectedConditions.presenceOfElementLocated(siriCalcA));
	}

	public static void shake() {
//		JavascriptExecutor js = (JavascriptExecutor) AppiumSetup.driver;
//		js.executeScript("seetest:client.shake();");
		IOSDriver<MobileElement> ios = (IOSDriver<MobileElement>) AppiumSetup.driver;
		ios.executeScript("seetest:client.shake();");
//		AppiumSetup.driver.executeScript("seetest:client.run(adb shell input keyevent 82);");
	}
}
