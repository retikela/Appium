package com.appium.Common;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.time.Duration;
import java.util.List;

import io.appium.java_client.MobileElement;

public abstract class GenericFunctions {
	private static GenericFunctions instance;

	protected GenericFunctions() {
	}

	public static GenericFunctions getInstance() {
		if (isIOS()) {
			instance = new IOSWidget();
		} else {
			instance = new AndroidWidget();
		}
		return instance;
	}

	static Configure config = new Configure();

	public static String executeCommand(Boolean waitFor, String command) {

		StringBuffer output = new StringBuffer();

		Process p;
		try {
			p = Runtime.getRuntime().exec(command);
			p.waitFor();
			BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));

			String line = null;
			while ((line = reader.readLine()) != null) {
				output.append(line);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		String response = output.toString();
		return response;
	}

	public static void pressBack() {
		AppiumSetup.driver.hideKeyboard();
		// if (isAndroid()) {
		// ((PressesKeyCode) Setup.driver).pressKeyCode(AndroidKeyCode.BACK);
		// } else if (isIOS())
		// ((PressesKeyCode) Setup.driver).pressKeyCode(IOSKeyCode.RETURN);
	}

	public static boolean isIOS() {
		if (config.getMobileOS().equalsIgnoreCase("iOS")) {
			return true;
		} else
			return false;
	}

	public static boolean isAndroid() {
		if (config.getMobileOS().equalsIgnoreCase("Android")) {
			return true;
		} else
			return false;
	}

	static int acceptalertindex = 0;
	
	public static void acceptAlert() throws Exception {
		// AppiumSetup.driver.switchTo().alert().accept();
		// AppiumSetup.driver.switchTo().defaultContent();
		if (isAndroid()) {
			Element.findElementbyID("android:id/button1").click();
		} else if (isIOS()) {
			Element.findChildElementsbyClass(Element.findElementbyClass("XCUIElementTypeAlert"),
					"XCUIElementTypeButton").get(acceptalertindex).click();
			Thread.sleep(1000);
		}
	}

	public static void clickAlertButton(int buttonId) throws Exception {
		// AppiumSetup.driver.switchTo().alert().accept();
		// AppiumSetup.driver.switchTo().defaultContent();
		if (isAndroid()) {
			Element.findElementbyID("android:id/button" + String.valueOf(buttonId)).click();
		} else if (isIOS()) {
			Element.findChildElementsbyClass(Element.findElementbyClass("XCUIElementTypeAlert"),
					"XCUIElementTypeButton").get(buttonId).click();
			Thread.sleep(1000);
		}
	}

//	public static void NavigateToSettingsPageinOS() {
//		try {
//			if (isIOS()) {
//				int count=0;
//				while (!Element.waitForElement(Settings()), 1)) {
//					new Gestures().scrollFromLeftToRightOfScreen();
//					count++;
//					if (count > 10)
//						break;
//				}
//				Element.findElementbyID("Settings").click();
//				while (!Element.waitForElement(iOSsettingsMainPage(), 1)) {
//					Element.findElementsbyClass(GenericFunctions.getInstance().getButtonClass()).get(0).click();
//				}
//
//				while (!Element.waitForElement(BluetoothCell(), 1)) {
//					Element.swipeUp(90);
//				}
//				// Element.scrollUntilVisibleBy("DOWN", "xpath",
//				// "//XCUIElementTypeCell[@name=\"Bluetooth\"]");
//				// Element.scrollTO(Element.findElementbyXpath("//XCUIElementTypeCell[@name=\"Bluetooth\"]"));
//			}
//		} catch (Exception e) {
//
//		}
//	}

	public static MobileElement iOSsettingsMainPage() {

		try {
			if (isIOS())
				return Element.findElementbyXpath("//XCUIElementTypeNavigationBar[@name=\"Settings\"]");
		} catch (Exception e) {
			return null;
		}
		return null;
	}

	public static MobileElement BluetoothCell() {

		try {
			if (isIOS())
				return Element.findElementbyXpath("//XCUIElementTypeCell[@name=\"Bluetooth\"]");
		} catch (Exception e) {
			return null;
		}
		return null;
	}

	public static String getAcceptAlertText() throws Exception {
		if (isAndroid()) {
			// Element.findElementbyID("android:id/button1").click();
			return Element.findElementbyID("android:id/button1").getText();
		} else if (isIOS()) {
			// Element.findChildElementsbyClass(Element.findElementbyClass("XCUIElementTypeAlert"),"XCUIElementTypeButton").get(1).click();
			// Thread.sleep(1000);
			return Element.findChildElementsbyClass(Element.findElementbyClass("XCUIElementTypeAlert"),
					"XCUIElementTypeButton").get(acceptalertindex).getText();
		}
		return null;
	}
	
	public static String getCancelAlertText() throws Exception {
		if (isAndroid()) {
			// Element.findElementbyID("android:id/button1").click();
			return Element.findElementbyID("android:id/button2").getText();
		} else if (isIOS()) {
			// Element.findChildElementsbyClass(Element.findElementbyClass("XCUIElementTypeAlert"),"XCUIElementTypeButton").get(1).click();
			// Thread.sleep(1000);
			return Element.findChildElementsbyClass(Element.findElementbyClass("XCUIElementTypeAlert"),
					"XCUIElementTypeButton").get(1).getText();
		}
		return null;
	}

	public static String getAlertMsg() throws Exception {
		try {
			return GenericFunctions.getInstance().getAlertMessage();
		} catch (Exception e) {
			throw new Exception("Alert not found");
		}
	}
	
	public static String getAlertTitleMessage() throws Exception {
		try {
			return GenericFunctions.getInstance().getAlertTitle();
		} catch (Exception e) {
			throw new Exception("Alert not found");
		}
	}

	public static void minimiseApplication(String seconds) {
		if (seconds != null)
			AppiumSetup.driver.runAppInBackground(Duration.ofSeconds(Long.parseLong(seconds)));
		else
			AppiumSetup.driver.runAppInBackground(null);
	}

	public static MobileElement widgetContainer() {
		try {
			if (isAndroid())
				return Element.findElementbyClass("android.appwidget.AppWidgetHostView");
			else {
				if (Integer.parseInt(new Configure().getMobileOSVersion()) > 13) {
					return Element.findElementbyID("left-of-home-scroll-view");
				} else {
					return Element.findElementbyID("WGMajorListViewControllerView");
				}
			}
		} catch (Exception e) {
		}
		return null;
	}

	public static MobileElement btnWidgetEdit() throws Exception {
		return Element.findChildElementbyID(widgetContainer(), "Edit");
	}

	public static MobileElement lblAddWidgets() throws Exception {
		return Element.findChildElementbyID(widgetContainer(), "Add Widgets");
	}

	public static MobileElement btnAddWidgestDone() throws Exception {
		return Element.findChildElementbyID(widgetContainer(), "Done");
	}
	
	public static MobileElement AppWidget() {
		MobileElement appWidget = null;
		try {
			appWidget = Element.findElementbyXpath("//*[@class='UIAView' and @width>0 and ./*[@text='BLUEDIAMOND']]");
		}catch (Exception e) {
			// TODO: handle exception
		}
		return appWidget;
	}
	
	

	public static void navigateToWidget() throws Exception {
		int count = 0;
		if (isIOS()) {
			while (!Element.waitForElement(widgetContainer(), 1)) {
				new Gestures().scrollFromLeftToRightOfScreen();
				count++;
				if (count > 10)
					break;
			}
			if (Integer.parseInt(new Configure().getMobileOSVersion()) > 13) {
				while (!Element.waitForElement(AppWidget(), 1)) {
					Element.swipeDown(80);
					count++;
					if (count > 10)
						break;
				}
			}
		} else if (isAndroid()) {
			while (!(widgetContainer().getAttribute("contentDescription").equalsIgnoreCase("BlueDiamond"))) {
				new Gestures().scrollFromRightToLeftOfScreen();
				Thread.sleep(5000);
				count++;
				if (count > 10)
					break;
			}
		}
	}

	public static void navigateToNotificationManager() throws Exception {
		if (isIOS()) {
			new Gestures().scrollFromTopOfScreen();
		}
	}

	public List<MobileElement> getNotifications() throws Exception {
		if (isIOS()) {
			return Element.findElementsbyID("NotificationCell");
		}
		return null;
	}

	public static boolean waitforAlert() {
		if (isAndroid()) {
			return Element.waitforVisible("id", "android:id/parentPanel", 5);
		} else {
			return Element.waitforVisible("class", "XCUIElementTypeAlert", 5);
		}
	}

	public static void declineAlert() throws Exception {
		if (isAndroid()) {
			Element.findElementbyID("android:id/button2").click();
		} else if (isIOS()) {
			Element.findChildElementsbyClass(Element.findElementbyClass("XCUIElementTypeAlert"),
					"XCUIElementTypeButton").get(1).click();
			Thread.sleep(1000);
		}
		// AppiumSetup.driver.switchTo().alert().dismiss();
	}

	public abstract String getLableClass() throws Exception;
	
	public abstract String getViewClass() throws Exception;

	public abstract String getButtonClass() throws Exception;

	public abstract String getImageButtonClass() throws Exception;

	public static void waitforProgressbarDismiss() {
		if (isAndroid())
			while (Element.waitForClass("android.widget.ProgressBar", 1)) {

			}
	}
	
	public void NavigateToBLESettingsPage(){
		if(isAndroid())
		 try {
	          Runtime.getRuntime().exec("adb shell am start -a android.settings.BLUETOOTH_SETTINGS");
	     } catch (Exception e) {
	        e.printStackTrace();
	     }else {
	    	 //Need to write code for ios
	     }
	}
	
	public static void navigateBack() throws InterruptedException {
		AppiumSetup.driver.navigate().back();
		Thread.sleep(2000);
	}

	public abstract String getAlertMessage() throws Exception;

	public abstract String getTableCellClass();
	
	public abstract String getDialogClass();
	
	public abstract String getProgressBarClass();

	public abstract String getWindowClass();

	public abstract String getTableClass();

	public abstract boolean isKeyboard() throws Exception;

	public abstract MobileElement deviceBluetoth() throws Exception;

	public abstract MobileElement deviceWifi() throws Exception;

	public abstract void NavigateToSettingsPage() throws Exception;

	public abstract String getAlertTitle() throws Exception;

	public abstract String isCheckBoxSelected(MobileElement ele);

	public abstract void pasteText(String s);

	public abstract Boolean getBluetoothStatus();

	protected abstract void clickBluetoothSwitch();

	public abstract Boolean getWifiStatus();

	protected abstract void clickWifiSwitch();

	public abstract String getTextfromTextBox(MobileElement ele);

}
