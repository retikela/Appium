package com.appium.Common;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class Localization {
	static String filePath;
	static HashMap<String, String> langmap = new HashMap<String, String>();

	// public static void main(String[] args) {
	public void iosLocale() {
//		InputStream is;
		try {
			String iosPath =  "Loc/iOS/";
			String lang = new Configure().getLanguage();
			switch (lang) {
			case "es":
				filePath = iosPath+"es.XLIFF";
				break;
			case "ar":
				filePath = iosPath+"ar.XLIFF";
				break;
			case "cs":
				filePath = iosPath+"cs.XLIFF";
				break;
			case "de":
				filePath = iosPath+"de.XLIFF";
				break;
			case "fi":
				filePath = iosPath+"fi.XLIFF";
				break;
			case "fr":
				filePath = iosPath+"fr.XLIFF";
				break;
			case "he":
				filePath = iosPath+"he.XLIFF";
				break;
			case "hr":
				filePath = iosPath+"hr.XLIFF";
				break;
			case "it":
				filePath = iosPath+"it.XLIFF";
				break;
			case "ja":
				filePath = iosPath+"ja.XLIFF";
				break;
			case "ko":
				filePath = iosPath+"ko.XLIFF";
				break;
			case "lt":
				filePath = iosPath+"lt.XLIFF";
				break;
			case "nl":
				filePath = iosPath+"nl.XLIFF";
				break;
			case "pl":
				filePath = iosPath+"pl.XLIFF";
				break;
			case "pt":
				filePath = iosPath+"pt.XLIFF";
				break;
			case "ro":
				filePath = iosPath+"ro.XLIFF";
				break;
			case "ru":
				filePath = iosPath+"ru.XLIFF";
				break;
			case "sv":
				filePath = iosPath+"sv.XLIFF";
				break;
			case "tr":
				filePath = iosPath+"tr.XLIFF";
				break;
			case "zh-CHT":
				filePath = iosPath+"zh-CHT.XLIFF";
				break;
			case "zh-CN":
				filePath = iosPath+"zh-CN.XLIFF";
				break;
			default:
				filePath = iosPath+"es.XLIFF";
				return;
			}
//			chnageFile();
//			is = new FileInputStream(filePath);
//			XLIFF x;
//			x = XLiffUtils.read(is);
//			Collection<String> sources = x.getSources();
//			for (String source : sources) {
//				langmap.put(source.toUpperCase(), x.getTarget(source));
//				System.out.println(source.toUpperCase() + ":::::" + x.getTarget(source));
//			}
			InputStream fXmlFile = new FileInputStream(filePath);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(fXmlFile);

            doc.getDocumentElement().normalize();

            NodeList nList = doc.getElementsByTagName("trans-unit");
            String Source,Target;
            for (int temp = 0; temp < nList.getLength(); temp++)
            {
                Node nNode = nList.item(temp);

                if (nNode.getNodeType() == Node.ELEMENT_NODE)
                {
                    Element eElement = (Element) nNode;
//                    System.out.println("Source: " + eElement.getElementsByTagName("source").item(0).getTextContent());
                    Source = eElement.getElementsByTagName("source").item(0).getTextContent();
                    try{
//                    System.out.println("target: " + eElement.getElementsByTagName("target").item(0).getTextContent());
                    Target = eElement.getElementsByTagName("target").item(0).getTextContent();
                    }catch (Exception e){
                        System.out.println("target: " + "");
                        Target = "";
                    }
                    langmap.put(Source.toUpperCase(), Target);
                }
            }
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

//	private static void updateAttributeValue(Document doc) {
//		NodeList ids = doc.getElementsByTagName("trans-unit");
//		Element id = null;
//		for (int i = 0; i < ids.getLength(); i++) {
//			id = (Element) ids.item(i);
//			id.setAttribute("id", "");
//		}
//	}
//
//	public static void chnageFile() {
//		// String filePath = "es.xliff";
//		File xmlFile = new File(filePath);
//		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
//		DocumentBuilder dBuilder;
//		try {
//			dBuilder = dbFactory.newDocumentBuilder();
//			Document doc = dBuilder.parse(xmlFile);
//			doc.getDocumentElement().normalize();
//			// doc.getDocumentElement().normalize();
//			updateAttributeValue(doc);
//			TransformerFactory transformerFactory = TransformerFactory.newInstance();
//			Transformer transformer = transformerFactory.newTransformer();
//			DOMSource source = new DOMSource(doc);
//			StreamResult result = new StreamResult(new File(filePath));
//			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
//			transformer.transform(source, result);
//			System.out.println("XML file updated successfully");
//		} catch (ParserConfigurationException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (SAXException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (TransformerConfigurationException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (TransformerException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//	}

	public static String getLoclizedvalue(String key) {
		if (langmap.get(key.toUpperCase()) != null)
			return langmap.get(key.toUpperCase()).trim();
		else
			return "";
	}
	
	public void androidLocale(){
		try {
			String droidPath =  "Loc/android/values-";
			String lang = new Configure().getLanguage();
			switch (lang) {
			case "es":
				filePath = droidPath+lang+"/"+"strings.xml";
				break;
			default:
				return;
			}
            File fXmlFile = new File(filePath);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory
                        .newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(fXmlFile);
            doc.getDocumentElement().normalize();
            NodeList nList = doc.getElementsByTagName("string");
            System.out.println("----------------------------");
            for (int temp = 0; temp < nList.getLength(); temp++) {
                  Node nNode = nList.item(temp);
                  if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                        Element eElement = (Element) nNode;
                        langmap.put(eElement.getAttribute("name").toUpperCase(),nNode.getTextContent());
                        System.out.println(eElement.getAttribute("name").toUpperCase()+"::"+nNode.getTextContent());
                  }
            }
            System.out.println(langmap.values());
      } catch (Exception e) {
            System.out.println(e.getMessage());
      }

	}

}
