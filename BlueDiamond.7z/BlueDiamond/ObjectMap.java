package com.appium.Common;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.util.TextUtils;

public class ObjectMap {
	static HashMap<String, String> objectmap = new HashMap<String, String>();

	static {
		System.out.println("In readPropertyFile method");
		Properties prop = new Properties();

		Properties property = new Properties();
		Set<String> propertyNames;
		FileInputStream file;
		Localization l = new Localization();
		try {
			file = new FileInputStream("Common.properties");
			prop.load(file);
			propertyNames = prop.stringPropertyNames();
			String ln = new Configure().getLanguage();
			if (!ln.equalsIgnoreCase("en")) {
				if (GenericFunctions.isIOS())
					l.iosLocale();
				else if (GenericFunctions.isAndroid())
					l.androidLocale();
			}
			for (String Property : propertyNames) {
				if (ln.equalsIgnoreCase("en")) {
					objectmap.put(Property, prop.getProperty(Property));
				} else {
					if (Localization.getLoclizedvalue(prop.getProperty(Property)).isEmpty()) {
						objectmap.put(Property, prop.getProperty(Property));
					} else {
						objectmap.put(Property, Localization.getLoclizedvalue(prop.getProperty(Property)));
					}
				}

			}
			System.out.println("Common Property File Loaded Succesfully");
			if (GenericFunctions.isAndroid()) {
				FileInputStream androidfile = new FileInputStream("Android.properties");
				property.load(androidfile);
				Set<String> android = property.stringPropertyNames();
				for (String Property : android) {
					
					String propertyValue =  property.getProperty(Property); 
					
					if(!StringUtils.isNumeric(propertyValue)) {
						propertyValue = new StringBuffer().append(new Configure().getAppPackage()).append(":id/").append(propertyValue).toString();
					}
					
					objectmap.put(Property, propertyValue);

				}
				System.out.println("Android Phone Property File Loaded Succesfully");
			} else if (GenericFunctions.isIOS()) {
				FileInputStream iosfile = new FileInputStream("iOS.properties");
				property.load(iosfile);
				Set<String> ios = property.stringPropertyNames();
				for (String Property : ios) {
					objectmap.put(Property, property.getProperty(Property));
				}
				System.out.println("iPhone Property File Loaded Succesfully");
			}
			System.out.println(objectmap.values());
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

	public void setvalue(String key, String value) {
		// TODO Auto-generated method stub
		objectmap.put(key, value);
	}

	public static String getvalue(String key) {
		// TODO Auto-generated method stub
		return objectmap.get(key).trim();
	}
}
