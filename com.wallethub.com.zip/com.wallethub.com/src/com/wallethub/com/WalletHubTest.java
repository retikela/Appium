package com.wallethub.com;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class WalletHubTest extends WalletHubMethods  {
	
	public static WebDriver driver;
	
	@BeforeTest
	public void Launch_App() {
		driver = webdriver;
	}
	
	@Test(priority=1)
	public void create_WalletHub_Account() {
		wallethub_SignUp();
	}
	
	@Test(priority=2)
	public void validate_WalletHUb_Account() {
		verify_Wallethub_Account();
	}
	
	@Test(priority=3)
	public void submit_Review_Using_Given_Link() throws InterruptedException {
		submit_Review();
	}
	
	@Test(priority=4)
	public void validate_Submitted_Review() throws InterruptedException {
		//validate_Review();
	}
	
	@AfterTest
	public void Quit() {
		Close_Browser();
	}

}
