package com.wallethub.com;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.*;
import java.util.List;
import java.util.Properties;
 

public class Common {
    public static Properties OrProp = new Properties();
    public static Properties Prop = new Properties();
    public static String separator = System.getProperty("file.separator");
    public static String project_path = System.getProperty("user.dir");
    public static WebDriver driver;
    
    public static WebDriver setDriver(){ 
    	try{
            String OrConfigPath = project_path+separator+"Resources"+separator+"or.properties";
            OrProp.load(new FileInputStream(OrConfigPath));
            String PropConfigPath = project_path+separator+"Resources"+separator+"config.properties";
            Prop.load(new FileInputStream(PropConfigPath));
        } catch (Exception e){
            e.printStackTrace();
        }
    	String browser = Prop.getProperty("browser").toLowerCase();
    	
    	switch(browser){
    		case "chrome" :
    			System.setProperty("webdriver.chrome.driver", project_path+"/Drivers/chromedriver");
    	        driver = new ChromeDriver();
    	        //driver.get("https://www.google.com");
    			break;
    		case "firefox" :
    			System.setProperty("webdriver.gecko.driver", project_path+"/Drivers/geckodriver");
    	        driver = new FirefoxDriver();
    			break;
    			
    	} return driver;
    }
    
    public void wait_For_ElementVisibility(By by){
        new WebDriverWait(driver,60).until(ExpectedConditions.visibilityOfElementLocated(by));
    }
    
    public void sendText(String PropertyName, String Value){
        driver.findElement(By.xpath(OrProp.getProperty(PropertyName))).sendKeys(Value);
    }
    
    public String getText(String xpath){
        return driver.findElement(By.xpath(OrProp.getProperty(xpath))).getText();
    }
    
    public String get_Attribute_Value(String xpath, String attributeName){
        //wait_For_ElementVisibility(By.xpath(OrProp.getProperty(xpath)));
        return driver.findElement(By.xpath(OrProp.getProperty(xpath))).getAttribute(attributeName);
    }

    public boolean waitForJStoLoad(int waitTimeinSec){
        WebDriverWait wait = new WebDriverWait(driver,waitTimeinSec);
        //wait for jQuery to Load
        ExpectedCondition<Boolean> jQueryLoad = new ExpectedCondition<Boolean>() {

            public Boolean apply(WebDriver driver) {
                try{
                    return((Long) ((JavascriptExecutor) driver).executeScript("return jQuery.active")==0);
                } catch(Exception e) {
                    return true;
                }
            }
        };
        ExpectedCondition<Boolean> jsLoad = new ExpectedCondition<Boolean>() {

            public Boolean apply(WebDriver driver) {
                return ((JavascriptExecutor) driver).executeScript("return document.readyState").toString().equals("complete");
            }
        };
        return wait.until(jQueryLoad) && wait.until(jsLoad);
    }

    public boolean waitForJStoLoad(){
        return waitForJStoLoad(60);
    }

    public void waitAndClickUsingJS(By by){
        waitAndClickUsingJS(by, 90);
    }

    public void waitAndClickUsingJS(By by , int waitTimeInSec){
        WebElement ele = driver.findElement(by);
        waitAndClickUsingJS(ele, waitTimeInSec);
    }
    public void waitAndClickUsingJS(WebElement element, int waitTimeInSec){
        new WebDriverWait(driver,waitTimeInSec).until(ExpectedConditions.elementToBeClickable(element));
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();",element);
        waitForJStoLoad(waitTimeInSec);
    }


    public WebElement getElement(String PropertyName) {
    	return driver.findElement(By.xpath(OrProp.getProperty(PropertyName)));
    }

    public List<WebElement> getElements(String PropertyName){
        return driver.findElements(By.xpath(OrProp.getProperty(PropertyName)));
    }

    public static void WritetoFile(String FileName, String fname){
        BufferedWriter writer = null;
        try{
            writer = new BufferedWriter(new FileWriter(FileName));
            writer.write(fname);
        }catch(IOException e){
            System.err.println(e);
        }finally {
            if(writer != null){
                try{
                    writer.close();
                }catch(IOException e){
                    System.err.println(e);
                }
            }
        }
    }

    public static String readFile(String fileName) throws Exception{
        String x = null;
        File file = new File(fileName);
        BufferedReader br = new BufferedReader(new FileReader(file));
        String st;
        while((st= br.readLine()) != null)
            x=(st);
        return x;
    }

   

    public void select_Dropdown_Value (String dropdownXpath , String visibleText){
        wait_For_ElementVisibility(By.xpath(OrProp.getProperty(dropdownXpath)));
        WebElement drpdwn = driver.findElement(By.xpath(OrProp.getProperty(dropdownXpath)));
        Select sel = new Select(drpdwn);
        sel.selectByVisibleText(visibleText);
    }
}

