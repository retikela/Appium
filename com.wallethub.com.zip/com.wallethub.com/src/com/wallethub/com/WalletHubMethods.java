package com.wallethub.com;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class WalletHubMethods extends Common {

    public static String Expected_Content;
    public static WebDriver webdriver =setDriver();

    public void wallethub_SignUp(){
    	
        webdriver.get(Prop.getProperty("wallethub_URL"));
        wait_For_ElementVisibility(By.xpath(OrProp.getProperty("txt_Username")));
        sendText("txt_Username",Prop.getProperty("wallethub_Reg_Username"));
        sendText("txt_Password",Prop.getProperty("wallethub_Reg_Password"));
        sendText("txt_ConfirmPassword",Prop.getProperty("wallethub_Reg_Password"));
        String checkbox_status = get_Attribute_Value("chkbox_Creditscore","class");
        if(checkbox_status.contains("not-empty")){
        	waitAndClickUsingJS(By.xpath(OrProp.getProperty("chkbox_CrdtScr_Click")));
        }
        waitAndClickUsingJS(By.xpath(OrProp.getProperty("btn_Join")));
    }

    public void verify_Wallethub_Account(){
        
    	webdriver.get(Prop.getProperty("gmail_URL"));
        wait_For_ElementVisibility(By.xpath(OrProp.getProperty("txt_UserId")));
        sendText("txt_UserId",Prop.getProperty("gmail_Username"));
        waitAndClickUsingJS(By.xpath(OrProp.getProperty("btn_Next")));
        wait_For_ElementVisibility(By.xpath(OrProp.getProperty("txt_Pass")));
        sendText("txt_Pass", Prop.getProperty("gmail_password"));
        waitAndClickUsingJS(By.xpath(OrProp.getProperty("btn_Login")));
        wait_For_ElementVisibility(By.xpath(OrProp.getProperty("emails_Count")));
        List<WebElement> emails_Count = getElements("emails_Count");
        List<WebElement> email_Content_Columns = getElements("emails_Content");
        
//        WebElement ele = webdriver.findElement(By.xpath("//div[@id='passwordNext']"));
//        JavascriptExecutor executor = (JavascriptExecutor)webdriver;
//        executor.executeScript("arguments[0].click();", ele);
//        webdriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
        

        for(int i=0; i<emails_Count.size();i++){
            for(int j=0; j<email_Content_Columns.size();j++){
                String x = email_Content_Columns.get(j).getText();
                if(x.equalsIgnoreCase(Prop.getProperty("email_To_Validate"))){
                    email_Content_Columns.get(j).click();
                    break;
                }
            }
        }
        wait_For_ElementVisibility(By.xpath(OrProp.getProperty("link_VerifyNow")));
        waitAndClickUsingJS(By.xpath(OrProp.getProperty("link_VerifyNow")));
        webdriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        ArrayList<String> tabs = new ArrayList<String>(webdriver.getWindowHandles());
        webdriver.switchTo().window(tabs.get(1));
        wait_For_ElementVisibility(By.xpath(OrProp.getProperty("txt_Username")));
        sendText("txt_Username",Prop.getProperty("wallethub_Reg_Username"));
        sendText("txt_Password",Prop.getProperty("wallethub_Reg_Password"));
        wait_For_ElementVisibility(By.xpath(OrProp.getProperty("btn_SignIn")));
        WebElement sign_In = getElement("btn_SignIn");
        sign_In.click();
        //waitAndClickUsingJS(By.xpath(OrProp.getProperty("btn_SignIn")));
        wait_For_ElementVisibility(By.xpath(OrProp.getProperty("lbl_Verification_Msg")));
        String Expected_Message = Prop.getProperty("Expctd_EmailAccount_Verf");
        System.out.println(Expected_Message);
        String Actual_confirmation_message = getText("lbl_Verification_Msg");
        System.out.println(Actual_confirmation_message);
        Assert.assertEquals(Actual_confirmation_message, Expected_Message);
        
    }

    public void submit_Review() throws InterruptedException {
        
        webdriver.navigate().to(Prop.getProperty("wallethub_Review_URL"));
        boolean staleElement = true;
        Actions actions = new Actions(webdriver);
        waitAndClickUsingJS(By.xpath(OrProp.getProperty("tab_Reviews")));
        wait_For_ElementVisibility(By.xpath(OrProp.getProperty("rvw_Star")));
        String Expected_color= Prop.getProperty("Expected_Colour");

        while(staleElement){

            try{

                WebElement Star = getElement("rvw_Star");
                actions.moveToElement(Star).build();
                actions.moveToElement(Star).perform();
                Thread.sleep(500);
                String Actual_color = Star.getAttribute("fill");
                Assert.assertEquals(Actual_color, Expected_color);
                actions.moveToElement(Star).click().build().perform();
                System.out.println("Color after Mouse Hover : " + Actual_color);
                staleElement = false;
            } catch(StaleElementReferenceException e){
                staleElement = true;
            }

        }
        WebElement drp_down = getElement("drpDwn_Product");
        drp_down.click();
        WebElement prdct = webdriver.findElement(By.xpath(OrProp.getProperty("drpdwn_Text")));
        prdct.click();

        Expected_Content = RandomStringUtils.randomAlphabetic(200);
        
        sendText("txtarea_Review", Expected_Content);
        webdriver.findElement(By.xpath(OrProp.getProperty("btn_Submit_Review"))).click();
        wait_For_ElementVisibility(By.xpath(OrProp.getProperty("tab_Login")));
        waitAndClickUsingJS(By.xpath(OrProp.getProperty("tab_Login")));
    	wait_For_ElementVisibility(By.xpath(OrProp.getProperty("txt_Username")));
        sendText("txt_Username",Prop.getProperty("wallethub_Reg_Username"));
        sendText("txt_Password",Prop.getProperty("wallethub_Reg_Password"));
        WebElement join = getElement("btn_Join");
        join.click();
        
        WebElement profile_Name = getElement("menu_Profile");
        WebElement profile = getElement("menu_element_Profile");

        
        while(staleElement){

            try{
                actions.moveToElement(profile_Name).build();
                actions.moveToElement(profile_Name).perform();
                actions.moveToElement(profile).click().build().perform();
                staleElement = false;
            } catch(StaleElementReferenceException e){
                staleElement = true;
            }

        }
        waitAndClickUsingJS(By.xpath(OrProp.getProperty("tab_Reviews_Profile")));
    
        //String success_Msg = getText("Rvw_Success_Msg");
        //wait_For_ElementVisibility(By.xpath(OrProp.getProperty("btn_Continue")));
        //waitAndClickUsingJS(By.xpath(OrProp.getProperty("tab_Login")));
        
        webdriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        
        /*webdriver.findElement(By.xpath("//nav[@class='ng-animate-enabled basic-trans enter join']//a[contains(text(),'Login')]")).click();
        webdriver.findElement(By.xpath("//input[@placeholder='Email Address']")).sendKeys("snephew26@gmail.com");
        webdriver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys("Guesswhat?10");
        webdriver.findElement(By.xpath("//button[@class='btn blue touch-element-cl']")).click();
        webdriver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
*/
        
    }
    
    public void wallethub_SignIn(){
    	webdriver.get(Prop.getProperty("wallethub_URL"));
        wait_For_ElementVisibility(By.xpath(OrProp.getProperty("tab_Login")));
        waitAndClickUsingJS(By.xpath(OrProp.getProperty("tab_Login")));
        wait_For_ElementVisibility(By.xpath(OrProp.getProperty("txt_Username")));
        sendText("txt_Username",Prop.getProperty("wallethub_Reg_Username"));
        sendText("txt_Password",Prop.getProperty("wallethub_Reg_Password"));
        waitAndClickUsingJS(By.xpath(OrProp.getProperty("btn_Join")));
        webdriver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
        //webdriver.quit();
    }
    
    public void validate_Review() {
    	
    	webdriver.get(Prop.getProperty("wallethub_URL"));
    	wait_For_ElementVisibility(By.xpath(OrProp.getProperty("tab_Login")));
    	waitAndClickUsingJS(By.xpath(OrProp.getProperty("tab_Login")));
    	wait_For_ElementVisibility(By.xpath(OrProp.getProperty("txt_Username")));
        sendText("txt_Username",Prop.getProperty("wallethub_Reg_Username"));
        sendText("txt_Password",Prop.getProperty("wallethub_Reg_Password"));
        WebElement join = getElement("btn_Join");
        join.click();
        //waitAndClickUsingJS(By.xpath(OrProp.getProperty("btn_Join")));
        wait_For_ElementVisibility(By.xpath(OrProp.getProperty("tab_Reviews_Profile")));
        
        WebElement profile_Name = getElement("menu_Profile");
        WebElement profile = getElement("menu_element_Profile");
        boolean staleElement = true;
        Actions actions = new Actions(webdriver);
        
        while(staleElement){

            try{
                actions.moveToElement(profile_Name).build();
                actions.moveToElement(profile_Name).perform();
                actions.moveToElement(profile).click().build().perform();
                staleElement = false;
            } catch(StaleElementReferenceException e){
                staleElement = true;
            }

        }
        waitAndClickUsingJS(By.xpath(OrProp.getProperty("tab_Reviews_Profile")));
    }
    
    public void Close_Browser() {
    	webdriver.quit();
    }

    
}

