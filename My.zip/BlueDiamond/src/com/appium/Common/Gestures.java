package com.appium.Common;

import java.time.Duration;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.ios.IOSTouchAction;
import io.appium.java_client.touch.LongPressOptions;
import io.appium.java_client.touch.TapOptions;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.ElementOption;
import io.appium.java_client.touch.offset.PointOption;

public class Gestures {

	static // public static AppiumDriver<MobileElement> driver = Setup.Setup.driver;
	Duration dt = Duration.ofSeconds(2);

	// public Gestures() {
	// resolution = Element.getScreenResolution();
	// }

	public static PointOption getPointOption(int x, int y) {
		return PointOption.point(x, y);
	}

	public static ElementOption getElementOption(MobileElement ele) {
		return ElementOption.element(ele);
	}

	public static LongPressOptions getLongPressOptionsWithElement(MobileElement ele) {
		return new LongPressOptions().withElement(getElementOption(ele));
	}

	public static ElementOption getElementOption(MobileElement ele, int x, int y) {
		return ElementOption.element(ele);
	}

	public static WaitOptions getWaitOption(Duration d) {
		return WaitOptions.waitOptions(d);
	}

	public static void clickonRightSideofScreen() {
		Dimension resolution = AppiumSetup.resolution;
		TouchAction touchAction = new TouchAction(AppiumSetup.driver);
		touchAction.tap(getPointOption((int) (resolution.width * 0.95), resolution.height / 2)).perform();
	}

	public void verticalSwipe(MobileElement ele) throws Exception {
		Dimension size = ele.getSize();

		TouchAction swipe = new TouchAction(AppiumSetup.driver)
				.press(getElementOption(ele, size.width / 2, size.height - 20)).waitAction(getWaitOption(dt))
				.moveTo(getElementOption(ele, size.width / 2, size.height / 2 + 50)).release();
		swipe.perform();
	}

	public void horizontalSwipe(MobileElement ele) throws Exception {
		Dimension size = ele.getSize();

		TouchAction swipe = new TouchAction(AppiumSetup.driver).press(getElementOption(ele, 0, size.height / 2))
				.waitAction(getWaitOption(dt)).moveTo(getElementOption(ele, size.width / 2, size.height / 2)).release();
		swipe.perform();
	}

	public void draw(MobileElement ele) throws Exception {
		// Dimension size = ele.getSize();
		// TouchAction draw = new TouchAction(Setup.driver);
		Actions builder = new Actions(AppiumSetup.driver);
		Action drawAction = builder.moveToElement(ele, 135, 15) // start points x axis and y axis.
				.click().moveByOffset(200, 60) // 2nd points (x1,y1)
				.click().moveByOffset(100, 70)// 3rd points (x2,y2)
				.doubleClick().build();
		drawAction.perform();
	}

	// Will work only on XCUI mode as doubleTap is not supported by IOS/Android
	public void doubleTap(MobileElement ele) throws InterruptedException {
		new IOSTouchAction(AppiumSetup.driver).doubleTap(getElementOption(ele)).perform();
		Thread.sleep(2000);
	}

	public void longPress(MobileElement ele) throws Exception {
		Thread.sleep(5000);
		Point pointElement = ele.getLocation();
		Thread.sleep(2000);
		Dimension dimElement = ele.getSize();
		Thread.sleep(2000);
		// Point centerPoint = new Point(0, 0);
		// centerPoint = Element.getCenter(e2);
		// int x = centerPoint.getX();
		// int y = centerPoint.getY();
		int x = (int) (pointElement.getX() + dimElement.getWidth() * 0.6);
		Thread.sleep(2000);
		int y = (int) (pointElement.getY() + dimElement.getHeight() * 0.6);
		Thread.sleep(2000);
		new TouchAction<>(AppiumSetup.driver).longPress(getLongPressOptionsWithElement(ele))
				.waitAction(getWaitOption(dt)).release().perform();
	}

	public void Tap(MobileElement ele) throws InterruptedException {
		Thread.sleep(5000);
		new TouchAction<>(AppiumSetup.driver).tap(new TapOptions().withTapsCount(1).withElement(getElementOption(ele)))
				.waitAction(getWaitOption(dt)).release().perform();
	}

	public void scrollFromBottomOfScreen() throws Exception {
		Dimension resolution = AppiumSetup.resolution;
		// Element.swipe(Math.round(resolution.width/2), resolution.height, 0,
		// (0-resolution.height)/6);
		Element.swipe(0, resolution.height - 5, 0, (int) (resolution.height * 0.2));
		// Element.findElementbyID("Bluetooth").click();
	}

	public void scrollFromLeftToRightOfScreen() throws Exception {
		Dimension resolution = AppiumSetup.resolution;
		// Element.swipe(Math.round(resolution.width/2), resolution.height, 0,
		// (0-resolution.height)/6);
		Element.swipe(0, resolution.height / 2, (int) (resolution.width * 0.8), resolution.height / 2);
		// Element.findElementbyID("Bluetooth").click();
	}

	public void scrollFromRightToLeftOfScreen() throws Exception {
		Dimension resolution = AppiumSetup.resolution;
		// Element.swipe(Math.round(resolution.width/2), resolution.height, 0,
		// (0-resolution.height)/6);
		Element.swipe((int) (resolution.width * 0.9), resolution.height / 2, (int) (resolution.width * 0.2),
				resolution.height / 2);
		// Element.findElementbyID("Bluetooth").click();
	}

	public void scrollFromTopOfScreen() throws Exception {
		Dimension resolution = AppiumSetup.resolution;
		// Element.swipe(Math.round(resolution.width/2), resolution.height, 0,
		// (0-resolution.height)/6);
		Element.swipe((int) (resolution.width * 0.8), 0, (int) (resolution.width * 0.8),
				(int) (resolution.height * 0.8));
		// Element.findElementbyID("Bluetooth").click();
	}

	private MobileElement BlueTooth() throws Exception {
		return GenericFunctions.getInstance().deviceBluetoth();
	}

	private MobileElement Wifi() throws Exception {
		return GenericFunctions.getInstance().deviceWifi();
	}

	public void enableBlueTooth() throws Exception {
//		if (GenericFunctions.isIOS()) {
//			scrollFromBottomOfScreen();
//			// clickBluetooth();
//			boolean btStatus = getbluetoothStatus();
//			if (!btStatus) {
//				clickBluetooth();
//			}
//			Element.swipeUp(80);
//			// clickScreenWindow();
//		} else if (GenericFunctions.isAndroid()) {
//			// TODO
//		}
		if (GenericFunctions.isIOS())
			naviagetToDeviceSettings();
		else
			navigateToDeviceBleSettings();
//		minimizeTheApp();
//		if (GenericFunctions.isIOS()) {
//			GenericFunctions.getInstance().NavigateToSettingsPage();
//			// scrollFromBottomOfScreen();
//			// clickBluetooth();
		boolean btStatus = getbluetoothStatus();
		if (!btStatus) {
//				Element.findElementbyID("Bluetooth").click();
//				Element.findElementbyXpath("//XCUIElementTypeSwitch[@name=\"Bluetooth\"]").click();
//				clickBluetooth();
			GenericFunctions.getInstance().clickBluetoothSwitch();
		}
		maximizeTheApp();
		// Element.swipeUp(80);
		// // clickScreenWindow();
//		} else if (GenericFunctions.isAndroid()) {
//			// TODO
//		}
	}

	public void enableWifi() throws Exception {
//		minimizeTheApp();
//		if (GenericFunctions.isIOS()) {
//			GenericFunctions.getInstance().NavigateToSettingsPage();
//			// scrollFromBottomOfScreen();
//			// clickBluetooth();
		naviagetToDeviceSettings();
		boolean wifiStatus = getWifiStatus();
		if (!wifiStatus) {
			GenericFunctions.getInstance().clickWifiSwitch();
//				Element.findElementbyID("Wi-Fi").click();
//				Element.findElementbyXpath("//XCUIElementTypeSwitch[@name=\"Wi-Fi\"]").click();
			Thread.sleep(5000);
//				clickBluetooth();
		}
		maximizeTheApp();
		Thread.sleep(2000);
		if (GenericFunctions.isIOS()) {
			String wifi = "3 of 3 Wi-Fi bars";
//			Element.waitForElement(Element.findElementbyID(wifi));
		}
		// Element.swipeUp(80);
		// // clickScreenWindow();
//		} else if (GenericFunctions.isAndroid()) {
//			// TODO
//		}
//		if (GenericFunctions.isIOS()) {
//			scrollFromBottomOfScreen();
//			// clickWifi();
//			boolean wifiStatus = getWifiStatus();
//			if (!wifiStatus) {
//				clickWifi();
//			}
////			Element.swipeUp(80);
//			maximizeTheApp();
//			String wifi = "3 of 3 Wi-Fi bars";
//			Element.waitForElement(Element.findElementbyID(wifi));
//			// clickScreenWindow();
//		} else if (GenericFunctions.isAndroid()) {
//			// TODO
//		}
	}

	public void disableWifi() throws Exception {
//		minimizeTheApp();
//		if (GenericFunctions.isIOS()) {
////			scrollFromBottomOfScreen();
//			GenericFunctions.getInstance().NavigateToSettingsPage();
//			// clickWifi();
//			maximizeTheApp();
//			minimizeTheApp();
//			Element.findElementbyID("Settings").click();
////			Thread.sleep(5000);
		naviagetToDeviceSettings();
		boolean wifiStatus = getWifiStatus();
		if (wifiStatus) {
			GenericFunctions.getInstance().clickWifiSwitch();
//				maximizeTheApp();
//				minimizeTheApp();
//				Element.findElementbyID("Settings").click();
//				Element.findElementbyID("Wi-Fi").click();
//				maximizeTheApp();
//				minimizeTheApp();
//				Element.findElementbyID("Settings").click();
//				Element.findElementbyXpath("//XCUIElementTypeSwitch[@name=\"Wi-Fi\"]").click();
//				Element.findElementbyID("Settings").click();
//				clickWifi();
		}
		maximizeTheApp();
		Thread.sleep(2000);
//			Element.swipeUp(80);
		// clickScreenWindow();
//		} else if (GenericFunctions.isAndroid()) {
//			// TODO
//		}
	}

	public void naviagetToDeviceSettings() throws Exception {
		minimizeTheApp();
//		if (GenericFunctions.isIOS()) {
		GenericFunctions.getInstance().NavigateToSettingsPage();
		// scrollFromBottomOfScreen();
		// clickBluetooth();
		System.out.println("Navigated to settings page");
	}

	public void navigateToDeviceBleSettings() throws Exception {
		minimizeTheApp();
//		if (GenericFunctions.isIOS()) {
		GenericFunctions.getInstance().NavigateToBLESettingsPage();
		// scrollFromBottomOfScreen();
		// clickBluetooth();
		System.out.println("Navigated to settings page");
	}

	public void disableBlueTooth() throws Exception {
		if (GenericFunctions.isIOS())
			naviagetToDeviceSettings();
		else
			navigateToDeviceBleSettings();
		boolean btStatus = getbluetoothStatus();
		if (btStatus) {
//				Element.findElementbyID("Bluetooth").click();
//				Element.findElementbyXpath("//XCUIElementTypeSwitch[@name=\"Bluetooth\"]").click();
			GenericFunctions.getInstance().clickBluetoothSwitch();
		}
		maximizeTheApp();
//			Setup.driver.launchApp();
		// Element.swipeUp(80);
		// // clickScreenWindow();
//		} else if (GenericFunctions.isAndroid()) {
//			// TODO
//		}
	}

	public void minimizeTheApp() throws InterruptedException {
		AppiumSetup.driver.runAppInBackground(Duration.ofSeconds(-1));
		if (Integer.parseInt(new Configure().getMobileOSVersion()) > 13)
			AppiumSetup.driver.runAppInBackground(Duration.ofSeconds(-1));
//		Thread.sleep(5000);
	}

	public void maximizeTheApp() throws InterruptedException {
		AppiumSetup.driver.launchApp();
		Thread.sleep(1000);
		SwitchContext.switchToNativeContext();
//		activateApp(new Configure().getAppPackage());
	}

	boolean getbluetoothStatus() throws Exception {
		Boolean Status = GenericFunctions.getInstance().getBluetoothStatus();
		// if
		// (Integer.parseInt(Element.findElementbyXpath("//XCUIElementTypeSwitch[@name=\"Bluetooth\"]").getAttribute("value"))==0)
		// {
		// Integer.parseInt(BlueTooth().getAttribute("value")) == 0) {
//		if (Status.equalsIgnoreCase("OFF")) {
//			return false;
//		} else {
//			return true;
//		}
		// boolean btStatus = Boolean.valueOf(BlueTooth().getAttribute("value"));
		return Status;
	}

	boolean getWifiStatus() throws Exception {
		Boolean Status = GenericFunctions.getInstance().getWifiStatus();
//		String Status = Element.getElementText(Element.findElementbyID("Wi-Fi"));
////				.findElementsByClassName(GenericFunctions.getInstance().getLableClass()).get(1).getText();
//		if (Status.equalsIgnoreCase("OFF")) {
//			return false;
//		} else {
//			return true;
//		}
		return Status;
//		if (Integer.parseInt(Wifi().getAttribute("value")) == 0) {
//			return false;
//		} else {
//			return true;
//		}
		// boolean wifiStatus = Boolean.valueOf(Wifi().getAttribute("value"));
		// return wifiStatus;
	}

	void clickBluetooth() throws Exception {
		BlueTooth().click();
	}

	void clickWifi() throws Exception {
		Wifi().click();
	}

	public static void clickScreenWindow() throws Exception {
		if (GenericFunctions.isAndroid()) {
			Element.findElementbyID("com.utc.lenel.bluediamond:id/background").click();
		} else if (GenericFunctions.isIOS())
			Element.findElementbyClass(GenericFunctions.getInstance().getWindowClass()).click();
	}

	public static void dragAndDrop(MobileElement e1, MobileElement e2) throws Exception {
		dragAndDrop(e1, e2, 25);
	}

	public static void dragAndDrop(MobileElement e1, MobileElement e2, int time) throws Exception {
		Point pointElement = e2.getLocation();
		Dimension dimElement = e2.getSize();
		System.out.println(e2.getText());
		// Point centerPoint = new Point(0, 0);
		// centerPoint = Element.getCenter(e2);
		// int x = centerPoint.getX();
		// int y = centerPoint.getY();
		int x = (int) (pointElement.getX() + dimElement.getWidth() * 0.5);
		int y = (int) (pointElement.getY() + dimElement.getHeight() * 0.6);
		new TouchAction(AppiumSetup.driver).longPress(getLongPressOptionsWithElement(e1))
				.waitAction(getWaitOption(Duration.ofSeconds(time))).moveTo(getPointOption(x, y)).release().perform();
	}

	public void swipeFromRightToLeft(MobileElement ele, int percentWidthToSwipe) throws Exception {
		Dimension resolution = AppiumSetup.resolution;
		Point pointElement = ele.getLocation();
		Dimension dimElement = ele.getSize();
		int x = (int) (pointElement.getX() + dimElement.getWidth() * 0.8);
		int y = (int) (pointElement.getY() + dimElement.getHeight() * 0.5);
		int endX = resolution.width - (resolution.getWidth() * percentWidthToSwipe / 100);
		Element.swipe(x, y, endX, y,2);
	}

	public void swipeFromLeftToRight(MobileElement ele, int percentWidthToSwipe) throws Exception {
		Dimension resolution = AppiumSetup.resolution;
		Point pointElement = ele.getLocation();
		Dimension dimElement = ele.getSize();
		int x = (int) (pointElement.getX() + dimElement.getWidth() * 0.2);
		int y = (int) (pointElement.getY() + dimElement.getHeight() * 0.5);
		int endX = resolution.width + (resolution.getWidth() * percentWidthToSwipe / 100);
		Element.swipe(x, y, endX, y);
	}

}
