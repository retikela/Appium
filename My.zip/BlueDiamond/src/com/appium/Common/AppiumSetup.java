package com.appium.Common;

import java.io.File;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.Augmenter;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.asserts.SoftAssert;

import com.utc.BD.Test.ExtentReports.ExtentTestManager;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.SupportsNetworkStateManagement;
import io.appium.java_client.android.connection.ConnectionStateBuilder;
import io.appium.java_client.android.connection.HasNetworkConnection;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.service.local.AppiumDriverLocalService;

public class AppiumSetup {
	public static AppiumDriver<MobileElement> driver;
	public static DesiredCapabilities cap = new DesiredCapabilities();
	Configure config = new Configure();
	public SoftAssert sa;
	private static AppiumDriverLocalService service;
	public static String dateTime;

	@BeforeSuite(alwaysRun = true)
	public void startAppium() throws Exception {
//		Map<String, String> env = new HashMap<>(System.getenv());
//		env.put("PATH", "/usr/local/bin:" + env.get("PATH"));
//		AppiumServiceBuilder builder = new AppiumServiceBuilder().withIPAddress("127.0.0.1").usingPort(1234)
//				.withEnvironment(env).usingDriverExecutable(new File("/usr/local/bin/node")).withAppiumJS(new File(
//						"/usr/local/lib/node_modules/appium/build/lib/main.js"));
//		service = AppiumDriverLocalService.buildService(builder);
//		service.start();
//		 service = AppiumDriverLocalService.buildDefaultService();
//		 service.start();
//		if (service == null || !service.isRunning()) {
//			throw new AppiumServerHasNotBeenStartedLocallyException("An appium server node is not started!");
//		}
		if (GenericFunctions.isIOS()) {
			iOSCaps();
		} else if (GenericFunctions.isAndroid()) {
			androidCaps();
		}
		// String Version = GenericFunctions.executeCommand(false,
		// "adb shell getprop ro.build.version.release");
		// FileInputStream file;
		// file = new FileInputStream("Config.properties");
		// configprop.load(file);
		// File classpathRoot = new File(System.getProperty("user.dir"));
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd_hh-mm-ss");
		dateTime = df.format(new Date());
//				new Date()+"_"+new Date().getTime();
		driver.manage().timeouts().implicitlyWait(Integer.parseInt(config.getKeyValue("appWaitTime")),
				TimeUnit.SECONDS);
		// Thread.sleep(10000);
		// LoginPage.acceptService();
		resolution = Element.getScreenResolution();
	}

	DesiredCapabilities capabilities = new DesiredCapabilities();

	private void iOSCaps() throws MalformedURLException {
		capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, config.getMobileOS());
		capabilities.setCapability(MobileCapabilityType.UDID, config.getUDID());
		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, config.getdeviceName());
		capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, config.getAutomationName());
		capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, config.getMobileOSVersion());
		capabilities.setCapability(MobileCapabilityType.APP, config.getAppPath());
		capabilities.setCapability(MobileCapabilityType.NO_RESET, Boolean.valueOf(config.getKeyValue("noReset")));
		capabilities.setCapability(MobileCapabilityType.FULL_RESET, Boolean.valueOf(config.getKeyValue("fullReset")));
//		capabilities.setCapability("clearSystemFiles", true);
		capabilities.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, 60);
//		capabilities.setCapability(IOSMobileCapabilityType.BUNDLE_ID,config.getAppPackage());
		capabilities.setCapability("useNewWDA", false);
		capabilities.setCapability("showIOSLog", true);
		capabilities.setCapability("showXcodeLog", true);
//		capabilities.setCapability("instrumentApp", true);
//		capabilities.setCapability(MobileCapabilityType.BROWSER_NAME, "Safari");
//		capabilities.setCapability(MobileCapabilityType.AUTO_WEBVIEW, true);
		// capabilities.setCapability("xcodeConfigfile",
		// "/usr/local/lib/node_modules/appium/node_modules/appium-xcuitest-driver/WebDriverAgent/webdriver.xcconfig");
		// capabilities.setCapability("keychainPath",
		// "/Users/utcadmin/Desktop/MyPrivateKey.p12");
		capabilities.setCapability("includeSafariInWebviews", true);
		capabilities.setCapability("fullContextList", true);
//		capabilities.setCapability("xcodeOrgId", "D95W3VKE35");
//		capabilities.setCapability("xcodeSigningId", "iPhone Developer");
//		capabilities.setCapability("bootstrapPath",
//				"/usr/local/lib/node_modules/appium/node_modules/appium-xcuitest-driver/WebDriverAgent");
//		capabilities.setCapability("agentPath",
//				"/usr/local/lib/node_modules/appium/node_modules/appium-xcuitest-driver/WebDriverAgent/WebDriverAgent.xcodeproj");
		driver = new IOSDriver<MobileElement>(config.getURL(), capabilities);
	}

	private void androidCaps() throws MalformedURLException {
		File appDir = new File(config.getAppDir());
		File app = new File(appDir, config.getAppName());

//		capabilities.setCapability(CapabilityType.BROWSER_NAME, "");
		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, config.getdeviceName());
		capabilities.setCapability("avd", config.getEmulatorName());
		capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, config.getMobileOSVersion());
		capabilities.setCapability(MobileCapabilityType.NO_RESET, config.getKeyValue("noReset"));
		capabilities.setCapability(MobileCapabilityType.FULL_RESET, config.getKeyValue("fullReset"));
		capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, config.getMobileOS());
		capabilities.setCapability(MobileCapabilityType.APP, app.getAbsolutePath());
		capabilities.setCapability(AndroidMobileCapabilityType.APP_PACKAGE, config.getAppPackage());
		capabilities.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY, config.getKeyValue("appActivity"));
		capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, config.getAutomationName());
		capabilities.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, 120);
		capabilities.setCapability("�relaxed-security", true);
		capabilities.setCapability("�allow-insecure", true);
//		capabilities.setCapability(MobileCapabilityType.BROWSER_NAME, "Chrome");
		driver = new AndroidDriver<MobileElement>(config.getURL(), capabilities);
	}

	public static void disableWifi() {
		try {
			((HasNetworkConnection) driver).setConnection(new ConnectionStateBuilder().withWiFiDisabled().build());
		} catch (Exception e) {
			// TODO: handle exception
		}

	}

	public static void enaableWifi() {
		try {
			((HasNetworkConnection) driver)
					.setConnection(new ConnectionStateBuilder().withWiFiEnabled().withDataEnabled().build());
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	static Dimension resolution;

	@BeforeMethod
	public void beforeMethod(Method method) throws Exception {
		ExtentTestManager.startTest(method.getName(), method.getDeclaringClass().getName());
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		// Set method name in SgLog.
		String methodName = "ErrNotSetInBeforeMethod";
		sa = new SoftAssert();
		if (method != null) {
			methodName = method.getName();
		}
		System.out.println(
				"--------------------------------------------------------------------------------------------");
		System.out
				.println("Info Test Method Name = " + method.getDeclaringClass().getCanonicalName() + "." + methodName);
		System.out.println(
				"--------------------------------------------------------------------------------------------");

//		ArrayList<String> preLoginCases =new ArrayList<String>( Arrays.asList( "appLogin", "invalidUrlLogin", "invalidKeyLogin" ));
//		if(!preLoginCases.contains(methodName)){
//		ReadersList readersPage = new ReadersList();
//		BlueToothError bterror = new BlueToothError();
//		readersPage.waitForSettings();
//		if (bterror.isBluetoothOff()) {
//			readersPage.enableDeviceBluetooth();
//			Thread.sleep(6000);
//		}
//		}

	}

	@AfterMethod(alwaysRun = true)
	public void afterMethod(ITestResult result) throws Exception {
		if (result.getStatus() == ITestResult.FAILURE || result.getStatus() == ITestResult.SKIP) {
			WebDriver aug1 = (WebDriver) (new Augmenter().augment(driver));
			File scrFile = ((TakesScreenshot) aug1).getScreenshotAs(OutputType.FILE);
			String destDir = "test-output" + File.separator + "Screenshots" + File.separator + dateTime
					+ File.separator;
			String surefireDir = "target" + File.separator + "Screenshots" + File.separator + dateTime + File.separator;
			String methodName = result.getMethod().getMethodName();
			String fileName = destDir + methodName + ".jpg";
			String surefirefileName = surefireDir + methodName + ".jpg";
			FileUtils.copyFile(scrFile, new File(fileName));
			FileUtils.copyFile(scrFile, new File(surefirefileName));
			Reporter.setCurrentTestResult(result);
			Reporter.log("<a href=\"" + ".." + File.separator + ".." + File.separator + fileName
					+ "\"><p align=\"left\"> " + methodName + " Screenshot: " + new Date() + "</p><img src=" + ".."
					+ File.separator + ".." + File.separator + fileName + " height='500' width='300'>");
//			Reporter.log("<a href=\"" + ".." + File.separator + ".." + File.separator + fileName
//					+ "\"><p align=\"left\"> " + methodName + " Screenshot: " + new Date() + "</p><img src=" + ".."
//					+ File.separator + ".." + File.separator + surefirefileName + " height='500' width='300'>");
			if (!methodName.equalsIgnoreCase("appLogin")) {
				driver.closeApp();
				driver.launchApp();
			} else {
				tearDown();
			}
		}
	}

	@AfterSuite(alwaysRun = true)
	public void tearDown() throws InterruptedException {
		Thread.sleep(3000);
		driver.quit();
		System.out.println("tearDown() :: driver.quit() executed");
//		service.stop();
	}

}
