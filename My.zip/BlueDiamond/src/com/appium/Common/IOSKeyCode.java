package com.appium.Common;

public interface IOSKeyCode {
	int BACKSPACE = 8;
	int ENTER = 13;
	int RETURN = 13;
	int SPACE = 32;
	int A= 1;
}
