package com.appium.Common;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Properties;

public class Configure {
	FileInputStream config;
	Properties props;

	public Configure() {
		try {
			config = new FileInputStream("Config.properties");
			props = new Properties();
			props.load(config);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String getKeyValue(String key) {
		return props.getProperty(key);
	}

	public String getMobileOS() {
		return getKeyValue("platformName");
	}

	public String getMobileOSVersion() {
		return getKeyValue("platformVersion");
	}

	public String getAppDir() {
		return getKeyValue("appDir");
	}
	
	public String getAppName() {
		return getKeyValue("appName");
	}
	
	public String getdeviceName() {
		return getKeyValue("deviceName");
	}

	public String getEmulatorName() {
		return getKeyValue("EmulatorName");
	}
	
	public String getUsername() {
		return getKeyValue("Username");
	}

	public String getPassword() {
		return getKeyValue("Password");
	}

	public String getDefaultWait() {
		return getKeyValue("appWaitTime");
	}

	public String getAppPackage() {
		return getKeyValue("appPackage");
	}
	
	public String getAppActivity() {
		return getKeyValue("appActivity");
	}

	public String getAutomationName() {
		if (getMobileOS().equalsIgnoreCase("iOS"))
			return "XCUITest";
		else if (getMobileOS().equalsIgnoreCase("Android"))
			return "uiautomator2";
		return null;
	}

	public boolean isAndroid() {
		if (getMobileOS().equalsIgnoreCase("Android"))
			return true;
		return false;
	}
	
	public boolean isiOS() {
		if (getMobileOS().equalsIgnoreCase("iOS"))
			return true;
		return false;
	}
	
	public String getAppPath(){
		File appDir = new File(getAppDir());
		File app = new File(appDir, getAppName() );
		return app.getAbsolutePath();
	}
	
	
	public String getHost(){
		return getKeyValue("Host");
	}
	
	public String getPort(){
		return getKeyValue("Port");
	}
	
	public URL getURL() throws MalformedURLException{
		return new URL("http://"+getHost()+":"+getPort()+"/wd/hub");
	}

	public String getUDID() {
		return getKeyValue("udid");
	}
	
	public String getLanguage(){
		return getKeyValue("language");
	}
	
	public String getPhoneNumber(){
		return getKeyValue("phoneNumber");
	}
	
	public String getVerificationCode(){
		return getKeyValue("verificationCode");
	}
	
	public String getEmail(){
		return getKeyValue("email");
	}
	
}
