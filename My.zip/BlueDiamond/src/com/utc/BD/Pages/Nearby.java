package com.utc.BD.Pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;

import com.appium.Common.Element;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class Nearby {
	public Nearby(AppiumDriver<?> driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
//	@AndroidFindBy(id = "")
//	@iOSXCUITFindBy(accessibility = "Credential-title-label")
//	MobileElement viewsDropdown;
//	
//	public boolean waitforviewsDropdown() throws Exception {
//		return Element.waitForElement(viewsDropdown);
//	}
//	
//	public String getviewsDropdownText() throws Exception {
//		return Element.getElementText(viewsDropdown);
//		
//	}
//	
//	public void clickViewsDropdown() throws Exception {
//		viewsDropdown.click();		
//	}
//	
//	
//	@AndroidFindBy(id = "")
//	@iOSXCUITFindBy(accessibility = "dropDownTitleLabel")
//	List<MobileElement> viewsDropdownlist;
//	
////	Returns views text
//	public List<String> getviewsDropdownvalues() throws Exception {
//		List<String> dropdownValues = new ArrayList<>();
//		 for (MobileElement mobileElement : viewsDropdownlist) {
//			 dropdownValues.add(Element.getElementText(mobileElement));
//		 }
//		System.out.println("dorp down values" + dropdownValues);
//		return dropdownValues;
//		
//	}
//	
//	public void clickviewsDropdownvalue(String val) throws Exception {
//		for (MobileElement mobileElement : viewsDropdownlist) {
//			 if(Element.getElementText(mobileElement).equalsIgnoreCase(val));
//			 mobileElement.click();
//			 return;
//		 }
//	}
//	
//	@AndroidFindBy(id = "")
//	@iOSXCUITFindBy(accessibility = "dropDownHeaderRightButton")
//	MobileElement headerRightbtn;
//	
//	
//	public void clickRightbtn() throws Exception{
//		headerRightbtn.click();
//		Reporter.log("clicked "+headerRightbtn.getText());
//	}
//	
//	public String getRightbtntxt() throws Exception{
//		return headerRightbtn.getText();
//	}
//	
//	@AndroidFindBy(id = "")
//	@iOSXCUITFindBy(accessibility = "dropDownHeaderLeftButton")
//	MobileElement headerLeftbtn;
//	
//	
//	public void clickMenubtn() throws Exception{
//		headerLeftbtn.click();
//		Reporter.log("clicked menu icon");
//	}
	
	@AndroidFindBy(id = "no_readers_title_textview1")
	@iOSXCUITFindBy(accessibility = "Nearby-no-readers-header-label")
	MobileElement noReadersHeader;
	
	public String getnoReadersHeaderlbltxt() throws Exception{
		return noReadersHeader.getText();
	}
	
	@AndroidFindBy(id = "no_readers_description_textview1")
	@iOSXCUITFindBy(accessibility = "Nearby-no-readers-description-label")
	MobileElement noReadersDescription;
	
	public String getnoReadersDesclbltxt() throws Exception{
		return noReadersDescription.getText();
	}
	
	@AndroidFindBy(id = "refreshTextView1")
	@iOSXCUITFindBy(accessibility = "Nearby-refresh-readers-link")
	MobileElement refreshbtn;
	
	
	public void clickRefreshbtn() throws Exception{
		refreshbtn.click();
		Reporter.log("clicked "+refreshbtn.getText());
	}
	
	public String getRefreshbtntxt() throws Exception{
		return refreshbtn.getText();
	}

}
