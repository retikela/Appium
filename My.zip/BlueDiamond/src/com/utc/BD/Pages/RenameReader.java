package com.utc.BD.Pages;

import com.appium.Common.Element;
import com.appium.Common.ObjectMap;

import io.appium.java_client.MobileElement;

public class RenameReader {
	private MobileElement header() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Rename_lbl_title"));
	}
	
	public boolean waitforRenameHeader() throws Exception {
		return Element.waitForElement(header());
	}
	
	public String getHeadertext() throws Exception{
		return header().getText();
	}
	
	private MobileElement backButton() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Rename_btn_back"));
	}
	
	public void clickBack() throws Exception{
		backButton().click();
	}
	
	private MobileElement save() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Rename_btn_save"));
	}
	
	public void clickSave() throws Exception{
		save().click();
	}
	
	public String getSaveTxt() throws Exception{
		return save().getText();
	}
	
	private MobileElement editLabel() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Rename_lbl_editlabel"));
	}
	
	public String geteditLabeltext() throws Exception{
		return editLabel().getText();
	}
	
	private MobileElement defaultReader() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Rename_lbl_readerDefaultName"));
	}
	
	public String getDefaultReaderName() throws Exception{
		return defaultReader().getText();
	}
	
	private MobileElement editReadertbx() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Rename_tbx_edittext"));
	}
	
	public void enterReaderName(String input) throws Exception{
		editReadertbx().clear();
		editReadertbx().sendKeys(input);
		Thread.sleep(600);
//		GenericFunctions.pressBack();
	}
	
	public String getEditboxText() throws Exception{
		return Element.getTextfromTextbx(editReadertbx());
	}
	
}
