package com.utc.BD.Pages;

import java.util.List;

import org.testng.Reporter;

import com.appium.Common.Element;
import com.appium.Common.GenericFunctions;
import com.appium.Common.ObjectMap;

import io.appium.java_client.MobileElement;

public class routePreview {
	
	public MobileElement header() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("RoutePreview_lbl_Header"));
	}

	public boolean waitforRoutePreviewTitle() throws Exception {
		try {
			return Element.waitForElement(header(), 3);
		} catch (Exception e) {
			return false;
		}
	}

	public String getHeaderText() throws Exception {
		return header().getText();
	}

	public MobileElement cancelButton() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("RoutePreview_lbl_cancel"));
	}

	public MobileElement cancelButtonDirections() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("directions_txt_cancel"));
	}

	public MobileElement cardsimage() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("RoutePreview_lbl_cards"));
	}

	public MobileElement floornumber() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("RoutePreview_lbl_floor"));
	}

	public MobileElement PreviewRoute() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("GetDirections_btn_PreviewRoute"));
	}
	
	// Cards
	
	public MobileElement lblCurrentStep() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("RoutePreview_lbl_currentStep"));
	}
	
	public MobileElement imgDirection() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("RoutePreview_img_direction"));
	}
	
	public MobileElement lblNext() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("RoutePreview_lbl_next"));
	}
	
	public MobileElement imgNextDirection() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("RoutePreview_img_nextDirection"));
	}
	
	public MobileElement lblNextStep() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("RoutePreview_lbl_nextStep"));
	}
	
	public List<MobileElement> steps() throws Exception {
		return Element.findElementsbyID(ObjectMap.getvalue("RoutePreview_lbl_steps"));
	}
	
	
	
	public void clickPreviewRoute() throws Exception {
		PreviewRoute().click();
		Reporter.log("Clicked on Preview route button");
		Thread.sleep(2000);
	}

	public void clickBack() throws Exception {
		cancelButton().click();
		Reporter.log("Clicked on Cancel button");
		Thread.sleep(2000);
	}

	public MobileElement btnRoutePreviewSteps() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("RoutePreview_btn_Steps"));
	}

	public MobileElement txtRoutePreviewDirecections() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("RoutePreview_txt_Directions"));
	}

	public void clickRoutePreviewSteps() throws Exception {
		btnRoutePreviewSteps().click();
		Reporter.log("Clicked on steps icon");
		Thread.sleep(1500);
	}

	public MobileElement btnStartRoute() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("RoutePreview_lbl_StartRoute"));
	}

	public MobileElement btnStartRouteicon() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("RoutePreview_icon_StartRoute"));
	}

	public void clickbtnStartRouteicon() throws Exception {
		btnStartRouteicon().click();
		Reporter.log("Clicked on navigation icon");
		Thread.sleep(1500);
	}

	public void clickbtnStartRoute() throws Exception {
		btnStartRoute().click();
		Reporter.log("Clicked on start button");
		Thread.sleep(1500);

	}
	
	public boolean waitForStepsIconToAppear() {
		boolean syncComplete = false;
		if( GenericFunctions.isAndroid()) {
		syncComplete = Element.waitforVisible("id", "route_steps", 30);
		Reporter.log("Waiting for sync progress bar to disappear.");
		return syncComplete; 
		}
		return syncComplete;
	}
	
	public boolean verifyStartRouteAvailibility() throws Exception {
		boolean flag = false;
		try {
			if (btnStartRoute().isDisplayed()) {
				return flag;
			}
		} catch (Exception e) {
			return flag;
		}
		return flag;
	}
	
	public void swipeCard() throws Exception {
	
		Element.swipe(704, 434, -30, 442);
		
	}
	
	public int getCardsSize() throws Exception{ 
		int cardsSize = 0;
		try {
			cardsSize = steps().size();
			cardsSize = cardsSize/2 ; 
			Reporter.log("Number of visible cards on the directions screen are :" +cardsSize);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return cardsSize;
	}
	
	public boolean verifyCardSwipeMovement(int cardSize) throws Exception {
		
		if(cardSize > 2) {
			String cardText1 = lblCurrentStep().getText();
			swipeCard();
			String cardText2 = lblCurrentStep().getText();
			if(! cardText1.contentEquals(cardText2)) {
				Reporter.log("Sucessfully able to swipe between the card. Content on the 1st card and the 2nd card are not matching.");
				return true;
			} else {
				Reporter.log("Failed swiping between the cards. Content on the 1st card and the 2nd card are not matching.");
				return false;
			}
		} else {
			Reporter.log("There is only 1 card present for the route defined");
		}
		return false;
		
	}
	
}