package com.utc.BD.Pages;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;

import org.openqa.selenium.Dimension;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.TestRunner;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import com.appium.Common.AppiumSetup;

public class Setup extends AppiumSetup{

	@BeforeSuite
	public void startAppium() throws Exception {
		super.startAppium();
	}

	
	static Dimension resolution;

	@BeforeMethod(alwaysRun = true)
	public void beforeMethod(Method method) throws Exception {
		super.beforeMethod(method);
		String methodName = "ErrNotSetInBeforeMethod";
		
		ArrayList<String> preLoginCases =new ArrayList<String>( Arrays.asList( "appLogin", "invalidUrlLogin", "invalidKeyLogin" ));
		if(!preLoginCases.contains(methodName)){
		ReadersList readersPage = new ReadersList();
		BlueToothError bterror = new BlueToothError();
//		readersPage.waitForSettings();
		if (bterror.isBluetoothOff()) {
			readersPage.enableDeviceBluetooth();
			Thread.sleep(6000);
		}
		}
		
	}

	@AfterMethod(alwaysRun = true)
	public void afterMethod(ITestResult result) throws Exception {
		super.afterMethod(result);
		if (result.getStatus() == ITestResult.FAILURE || result.getStatus() == ITestResult.SKIP) {
			String methodName = result.getMethod().getMethodName();
			if(!methodName.equalsIgnoreCase("appLogin")){
			driver.closeApp();
			driver.launchApp();
			}else{
				tearDown();
			}
		}
	}

	@AfterSuite(alwaysRun = true)
	public void tearDown() throws InterruptedException {
		super.tearDown();
	}

}
