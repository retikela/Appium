package com.utc.BD.Pages;

import java.util.ArrayList;
import java.util.List;

import com.appium.Common.Element;
import com.appium.Common.GenericFunctions;
import com.appium.Common.Gestures;
import com.appium.Common.ObjectMap;

import io.appium.java_client.MobileElement;

public class Prefereneces_Gestures{
	
	private List<MobileElement> header() throws Exception{
		return Element.findElementsbyID(ObjectMap.getvalue("Gestures_lbl_Header"));
	}
	
	private List<MobileElement> Description() throws Exception{
		return Element.findElementsbyID(ObjectMap.getvalue("Gestures_lbl_Decription"));
	}
	
	private List<MobileElement> ToogleButton() throws Exception{
		return Element.findElementsbyID(ObjectMap.getvalue("Gestures_rbtn_ToogleSwitch"));
	}
	
	public boolean waitforSettingsPAABHeader() throws Exception {
		return Element.waitForElement(header().get(0));
	}
	
	public String getPhaabHeaderText() throws Exception {
		return Element.getElementText(header().get(Integer.parseInt(ObjectMap.getvalue("Gestures_lbl_phaabIndex"))));
	}
	
	public String getShakeToOpenHeaderText() throws Exception {
		return Element.getElementText(header().get(Integer.parseInt(ObjectMap.getvalue("Gestures_lbl_ShakeToOpenIndex"))));
	}
	
	
	public String getPhaabDescText() throws Exception {
		return Element.getElementText(Description().get(Integer.parseInt(ObjectMap.getvalue("Gestures_lbl_phaabDescIndex"))));
	}
	
	public String getShakeToOpenDescText() throws Exception {
		return Element.getElementText(Description().get(Integer.parseInt(ObjectMap.getvalue("Gestures_lbl_ShakeToOpenDescIndex"))));
	}
	
	public MobileElement switchPhoneAsBadge() throws Exception {
		return ToogleButton().get(Integer.parseInt(ObjectMap.getvalue("Gestures_rbtn_phaabToogleIndex")));
	}
	
	public MobileElement switchShakeToOpen() throws Exception {
		return ToogleButton().get(Integer.parseInt(ObjectMap.getvalue("Gestures_rbtn_ShakeToOpenToogleIndex")));
	}
	
	
	private MobileElement back() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Gestures_btn_Back"));
	}
	
	public void clickBack() throws Exception{
		back().click();
	}
	
	private MobileElement lblSettingsGesturesTitle() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Gestures_lbl_Title"));
	}
	
	public String getTitleText() throws Exception {
		return Element.getElementText(lblSettingsGesturesTitle());
	}
	
//	private MobileElement lblUsePhoneAsBadge() throws Exception{
//		return Element.findElementbyID(ObjectMap.getvalue("Gestures_lbl_UsePhoneAsBadge"));
//	}
	
//	public String getUsePhoneAsBadgeText() throws Exception {
//		return Element.getElementText(lblUsePhoneAsBadge());
//	}
	
//	private MobileElement switchPhoneAsBadge() throws Exception{
//		return Element.findElementbyID(ObjectMap.getvalue("Gestures_switch_PhoneAsBadge"));
//	}
	
	public void enablePhoneAsBadge() throws Exception{
		if(Element.getAttribute(switchPhoneAsBadge(),"label").equalsIgnoreCase("radio button off")) {
			switchPhoneAsBadge().click();
		}
	}
	
	public void disablePhoneAsBadge() throws Exception{
		if(Element.getAttribute(switchPhoneAsBadge(),"label").equalsIgnoreCase("radio button on")) {
			switchPhoneAsBadge().click();
		}
	}
	
	
	public void enableShakeToOpen() throws Exception{
		if(Element.getAttribute(switchShakeToOpen(),"label").equalsIgnoreCase("radio button off")) {
			switchShakeToOpen().click();
		}
	}
	
	public void disableShakeToOpen() throws Exception{
		if(Element.getAttribute(switchShakeToOpen(),"label").equalsIgnoreCase("radio button on")) {
			switchShakeToOpen().click();
		}
	}
	
	private List<MobileElement> lblPhaabReaderNames() throws Exception{
		return Element.findElementsbyID(ObjectMap.getvalue("Gestures_lbl_PhaabReaderNames"));
	}
	
	private List<String> readerNames = new ArrayList<String>();
	public List<String> getPHAABReaderNames() throws Exception {
		readerNames.clear();
		for (MobileElement reader : lblPhaabReaderNames()) {
			readerNames.add(Element.getElementText(reader));
		}
		System.out.println("Reader Names : "+readerNames);
		return readerNames;
	}
	
	private List<MobileElement> lblShakeReaderTypes() throws Exception{
		return Element.findElementsbyID(ObjectMap.getvalue("Gestures_lbl_ShakeReaderTypes"));
	}
	
	private List<String> readerTypes = new ArrayList<String>();
	public List<String> getShakeReaderTypes() throws Exception {
		readerTypes.clear();
		for (MobileElement reader : lblShakeReaderTypes()) {
			readerTypes.add(Element.getElementText(reader));
		}
		System.out.println("Reader Names : "+readerTypes);
		return readerTypes;
	}
	
	private List<MobileElement> btnPhaabDeleteIcon() throws Exception{
		return Element.findElementsbyID(ObjectMap.getvalue("Gestures_btn_PhaabDeleteIcon"));
	}
	
	public void clickPhaabDeleteIcon(int index) throws Exception {
		btnPhaabDeleteIcon().get(index).click();;
	}
	
	private List<MobileElement> btnPhaabEditIcon() throws Exception{
		return Element.findElementsbyID(ObjectMap.getvalue("Gestures_btn_phaabeditIcon"));
	}
	
	public void clickEditIcon(int index) throws Exception {
		btnPhaabEditIcon().get(index).click();
	}
	
		
	public void deletePHAAB(String readerName) throws Exception {
		int readerIndex = getPHAABReaderNames().indexOf(readerName);
		clickPhaabDeleteIcon(readerIndex);
	}
	
	public void editPHAAB(String readerName) throws Exception {
		int readerIndex = getPHAABReaderNames().indexOf(readerName);
		clickEditIcon(readerIndex);
	}
	
	public void deleteAllPAABs() throws Exception {
		for (MobileElement deleteIocn : btnPhaabDeleteIcon()) {
			clickPhaabDeleteIcon(0);
//			deleteIocn.click();
			Thread.sleep(1000);
		}
	}
	
}
