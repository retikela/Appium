package com.utc.BD.Pages;

import java.util.List;

import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class Mostused {
	public Mostused(AppiumDriver<?> driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	
	@AndroidFindBy(id = "no_readers_title_textview")
	@iOSXCUITFindBy(accessibility = "MostUsed-no-readers-header-label")
	MobileElement noReadersHeader;
	
	public String getnoReadersHeaderlbltxt() throws Exception{
		return noReadersHeader.getText();
	}
	
	@AndroidFindBy(id = "no_readers_description_textview")
	@iOSXCUITFindBy(accessibility = "MostUsed-no-readers-description-label")
	MobileElement noReadersDescription;
	
	public String getnoReadersDesclbltxt() throws Exception{
		return noReadersDescription.getText();
	}
	
	@AndroidFindBy(id = "refreshTextView")
	@iOSXCUITFindBy(accessibility = "MostUsed-see-nearby-readers-link")
	MobileElement refreshbtn;
	
	
	public void clickSeeNearbybtn() throws Exception{
		Reporter.log("clicking "+refreshbtn.getText());
		refreshbtn.click();
	}
	
	public String getSeeNearbybtntxt() throws Exception{
		return refreshbtn.getText();
	}
	
	@AndroidFindBy(xpath = "//*[@class='android.widget.LinearLayout' and ./parent::*[@class='android.widget.LinearLayout' and (./preceding-sibling::* | ./following-sibling::*)[@class='android.widget.RelativeLayout']] and ./*[@class='android.widget.ImageView']]")
	@iOSXCUITFindBy(accessibility = "Delete_reader_btn")
	List<MobileElement> readerDelbtn;
	
	
	public void clickreaderDelbtn(int i) throws Exception{
		Reporter.log("clicked "+refreshbtn.getText());
		readerDelbtn.get(i).click();
	}
	

}
