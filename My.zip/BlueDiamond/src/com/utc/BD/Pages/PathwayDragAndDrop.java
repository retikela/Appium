package com.utc.BD.Pages;

import java.util.ArrayList;
import java.util.List;

import com.appium.Common.Configure;
import com.appium.Common.Element;
import com.appium.Common.GenericFunctions;
import com.appium.Common.Gestures;
import com.appium.Common.ObjectMap;

import groovyjarjarantlr4.v4.parse.ANTLRParser.element_return;
import io.appium.java_client.MobileElement;

public class PathwayDragAndDrop {
	private MobileElement btnFinish() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("DragAndDrop-btn-Finish"));
	}

	public void clickbtnFinish() throws Exception {
		btnFinish().click();
	}

	public String getbtnFinishText() throws Exception {
		return Element.getElementText(btnFinish());

	}

	public boolean waitforbtnFinish() throws Exception {
		return Element.waitForElement(btnFinish());
	}

	public boolean isbtnFinishEnabled() throws Exception {
		return Element.isEnabled(btnFinish());
	}

	private MobileElement backClose() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("DragAndDrop-btn-Cancel"));
	}

	public void clickClose() throws Exception {
		backClose().click();
	}

	private MobileElement lbldragAndDropHint() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("DragAndDrop-lbl-dragAndDropHint"));
	}

	public String getlbldragAndDropHintText() throws Exception {
		return Element.getElementText(lbldragAndDropHint());

	}

	public boolean waitfordragAndDropHint() throws Exception {
		return Element.waitForElement(lbldragAndDropHint());
	}

	private MobileElement lblNewPathway() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("DragAndDrop-lbl-NewPathway"));
	}

	public String getlblNewPathwayText() throws Exception {
		return Element.getElementText(lblNewPathway());

	}

	private MobileElement lblDropReadersHere() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("DragAndDrop-lbl-DropReadersHere"));
	}

	private MobileElement imgDownOrCross() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("DragAndDrop-img-DownArrow"));
	}

	public String getlblDropReadersHereText() throws Exception {
		return Element.getElementText(lblDropReadersHere());

	}

	public List<MobileElement> getlblFavouriteReaders() throws Exception {
		return Element.findElementsbyID(ObjectMap.getvalue("DragAndDrop-lbl-favouritedoor"));
	}

	public List<MobileElement> getcellFavouriteReaders() throws Exception {
		return Element.findElementsbyID(ObjectMap.getvalue("DragAndDrop-cell-favouritedoor"));
	}

	public List<String> FavouriteReaders = new ArrayList<String>();

	public List<String> getFavouriteReaderNames() throws Exception {
		FavouriteReaders.clear();
		for (MobileElement reader : getlblFavouriteReaders()) {
			FavouriteReaders.add(reader.getText().trim());
		}
		return FavouriteReaders;
	}

	public List<MobileElement> getlblPathwayReaders() throws Exception {
		if (GenericFunctions.isAndroid())
			return Element.findElementsbyXpath(ObjectMap.getvalue("DragAndDrop-lbl-PathwayReader"));
		else
			return Element.findElementsbyID(ObjectMap.getvalue("DragAndDrop-lbl-PathwayReader"));
	}

	public List<String> PathwayReaders = new ArrayList<String>();

	public List<String> getPathwayReaderNames() throws Exception {
		PathwayReaders.clear();
		for (MobileElement reader : getlblPathwayReaders()) {
			PathwayReaders.add(reader.getText().trim());
		}
		return PathwayReaders;
	}

	public List<MobileElement> getimgDottedCircle() throws Exception {
		if (GenericFunctions.isAndroid())
			return Element.findElementsbyXpath(ObjectMap.getvalue("DragAndDrop-img-DottedCircle"));
		else
			return Element.findElementsbyID(ObjectMap.getvalue("DragAndDrop-img-DottedCircle"));
	}

	public int getDottedCircleCount() throws Exception {
		return getimgDottedCircle().size();
	}

	public void addReaderToPathway(String string) throws Exception {
		int favReaderPosition = getFavouriteReaderNames().indexOf(string);
		int emptyDottedCirclePosition = getDottedCircleCount() - 1;
		Gestures.dragAndDrop(getcellFavouriteReaders().get(favReaderPosition),
				getimgDottedCircle().get(emptyDottedCirclePosition));

	}

	public void addReaderToPathway(String string, int position) throws Exception {
		int favReaderPosition = getFavouriteReaderNames().indexOf(string);
		int emptyDottedCirclePosition = (getDottedCircleCount() - 1) - position;
		Gestures.dragAndDrop(getcellFavouriteReaders().get(favReaderPosition),
				getimgDottedCircle().get(emptyDottedCirclePosition));

	}

	public void swapReaders(String Reader1, String Reader2) throws Exception {
		int reader1Position = getPathwayReaderNames().indexOf(getPathwayReaderName(Reader1).toUpperCase());
		System.out.println(reader1Position);
		int reader2Position = getPathwayReaderNames().indexOf(getPathwayReaderName(Reader2));
		if(GenericFunctions.isAndroid())
			Gestures.dragAndDrop(getlblPathwayReaders().get(reader1Position), getlblPathwayReaders().get(reader2Position), 5);
		else
		Gestures.dragAndDrop(getimgDottedCircle().get(reader1Position), getimgDottedCircle().get(reader2Position), 5);
	}

	public void deleteReaderfromPathway(String string) throws Exception {
		int pathReaderPosition = getPathwayReaderNames().indexOf(string);
		// int readerDottedCirclePosition =
		// (getDottedCircleCount()-1)-pathReaderPosition;
		if(new Configure().isAndroid())
		new Gestures().longPress(getlblPathwayReaders().get(pathReaderPosition));
		Gestures.dragAndDrop(getlblPathwayReaders().get(pathReaderPosition), lbldragAndDropHint());
	}

	public boolean VerifyFavoriteReaderList(String reader) throws Exception {
		if (getFavouriteReaderNames().contains(reader)) {
			return true;
		} else
			return false;
	}

	public boolean VerifyPathwayReaderList(String reader) throws Exception {
		String[] names = reader.trim().split("\\s+");
		if (names.length > 1) {
			reader = names[0].substring(0, 1) + names[1].substring(0, 1);
		} else
			reader = names[0].substring(0, 1);
		if (getPathwayReaderNames().contains(reader.toUpperCase())) {
			return true;
		} else
			return false;
	}

	public String getPathwayReaderName(String favouriteReader) {
		String[] names = favouriteReader.trim().split("\\s+");
		if (names.length > 1) {
			favouriteReader = names[0].substring(0, 1) + names[1].substring(0, 1);
		} else
			favouriteReader = names[0].substring(0, 1);
		return favouriteReader;
	}

}
