package com.utc.BD.Pages;

import java.util.ArrayList;
import java.util.List;

import com.appium.Common.Element;
import com.appium.Common.ObjectMap;

import io.appium.java_client.MobileElement;

public class Hidden {
	private MobileElement header() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("HiddenReaders_lbl_Header"));
	}
	
	public boolean waitforHiddenPageHeader() throws Exception {
		return Element.waitForElement(header());
	}
	
	public String getHeaderText() throws Exception {
		return Element.getElementText(header());
		
	}
	
	private MobileElement backButton() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("HiddenReaders_btn_Back"));
	}
	
	public void clickBack() throws Exception{
		backButton().click();
	}
	
	public List<MobileElement> getUnhideIconList() throws Exception{
		List<MobileElement> unhideIcons;
		unhideIcons = Element.findElementsbyID(ObjectMap.getvalue("HiddenReaders_btn_unhideIcon"));
		return unhideIcons;
		
	}
	
	public List<MobileElement> getHideReaderList() throws Exception{
		List<MobileElement> readers;
		readers = Element.findElementsbyID(ObjectMap.getvalue("HiddenReaders_lbl_ReaderNames"));
		return readers;
	}
	
	
	public List<String> hiddenreaders = new ArrayList<String>();
	public List<String> getHiddenReaders() throws Exception{
		hiddenreaders.clear();
		for (MobileElement reader : getHideReaderList()) {
			hiddenreaders.add(reader.getText().trim());
		}
		return hiddenreaders;
	}
	
	public void unhideAllReaders() throws Exception{
		List<MobileElement> readers = getUnhideIconList();
		for (MobileElement mobileElement : readers) {
			getUnhideIconList().get(0).click();
		}
//		for (int i=0;i<readers.size();i++)
//		{
////			readers.get(i).click();
//			getUnhideIconList().get(i).click();
//			
//		}
	}
	
	
}
