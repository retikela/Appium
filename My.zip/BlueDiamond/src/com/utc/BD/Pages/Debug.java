package com.utc.BD.Pages;

import com.appium.Common.Element;
import com.appium.Common.ObjectMap;

import io.appium.java_client.MobileElement;

public class Debug {
	private MobileElement header() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Debug_Navbar_Header"));
	}
	
	public String getheaderTxt() throws Exception{
		return header().getText();
	}
	
	public boolean waitforDebugHeader() throws Exception {
		return Element.waitForElement(header());
	}
	
	private MobileElement backButton() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Debug_btn_Back"));
	}
	
	public void clickBack() throws Exception{
		backButton().click();
	}
	
	private MobileElement lblDebugEnable() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Debug_lbl_debugEnable"));
	}
	
	public String getDebugEnableTxt() throws Exception{
		return lblDebugEnable().getText();
	}
	
	private MobileElement lblDuplicateBeacon() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Debug_lbl_debugBeacon"));
	}
	
	public String getDuplicateBeaconTxt() throws Exception{
		return lblDuplicateBeacon().getText();
	}
	
	private MobileElement debugSwitch() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Debug_switch_debugEnable"));
	}
	
	public void clickDebugSwitch() throws Exception{
		debugSwitch().click();
	}
	
	private MobileElement SliderRssiFilter() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Debug_slider_rssiFilter"));
	}
	
	public void clickDebugSwitch(String percent) throws Exception{
		SliderRssiFilter().sendKeys(percent);
	}
	
	private MobileElement debugBeacons() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Debug_switch_debugBeacon"));
	}
	
	public void clickBeaconSwitch() throws Exception{
		debugBeacons().click();
	}
	
	private MobileElement lblRssiFilter() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Debug_lbl_rssifilterText"));
	}
	
	public String getRssiFilterTxt() throws Exception{
		return lblRssiFilter().getText();
	}
	
	private MobileElement lblRssiOutofRange() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Debug_lbl_rssiOutofRangeText"));
	}
	
	public String getRssiOutofRangeTxt() throws Exception{
		return lblRssiOutofRange().getText();
	}
	
	private MobileElement lblRssiAvarageParam() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Debug_lbl_rssiAvarageParamText"));
	}
	
	public String getRssiAvarageParamTxt() throws Exception{
		return lblRssiAvarageParam().getText();
	}
	
	private MobileElement lblOORtimeout() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Debug_lbl_OORtimeoutText"));
	}
	
	public String getOORtimeoutTxt() throws Exception{
		return lblOORtimeout().getText();
	}
	
	private MobileElement lblScanHistory() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Debug_lbl_ScanHistoryText"));
	}
	
	public String getScanHistoryTxt() throws Exception{
		return lblScanHistory().getText();
	}
	
	private MobileElement lblScanUpdateFreq() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Debug_lbl_ScanUpdateFreqText"));
	}
	
	public String getScanUpdateFreqTxt() throws Exception{
		return lblScanUpdateFreq().getText();
	}
	
	private MobileElement lblScanCredentialValid() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Debug_lbl_ScanCredentialValidText"));
	}
	
	public String getScanCredentialValidTxt() throws Exception{
		return lblScanCredentialValid().getText();
	}
	
	
}
