package com.utc.BD.Pages;

import org.testng.Reporter;

import com.appium.Common.Element;
import com.appium.Common.GenericFunctions;
import com.appium.Common.ObjectMap;

import io.appium.java_client.MobileElement;

public class BrowseFloors {
	
	public MobileElement header_getFloors() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("floors_lbl_header"));
	}
	
	public MobileElement btn_cancel() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("floors_lbl_cancel"));
	}
	
	public MobileElement btn_backArrow() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("floors_btn_backArrow"));
	}
	
	public MobileElement buildingNumber() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("floors_lbl_buildingNumber"));
	}
	
	public MobileElement preference() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("floors_img_preferenceArrow"));
	}
	
	public MobileElement floorNumber() throws Exception {
		if (GenericFunctions.isIOS()) {
			return Element.findElementbyID(ObjectMap.getvalue("floors_lbl_floorNumber"));
		} else {
			return Element.findElementbyXpath(ObjectMap.getvalue("floors_lbl_floorNumber"));
		}
	}
	
	public String getFloorNumber() throws Exception {
		
		return floorNumber().getText();
	}
	
	public MobileElement search() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("floors_txtFld_search"));
	}
	
	public MobileElement clearText() throws Exception{
		if(GenericFunctions.isAndroid()) {
		return Element.findElementbyID(ObjectMap.getvalue("floors_btn_clearText"));
		} else {
			return Element.findElementbyXpath(ObjectMap.getvalue("floors_btn_clearText"));
		}
	}
	
	public String verifyPageTitle() throws Exception {
		return header_getFloors().getText();
	}
	
	public void clickCancel() throws Exception {
		btn_cancel().click();
		Reporter.log("Clicked on cancel button");
		Thread.sleep(500);
	}

	public void selectBuilding() throws Exception {
		buildingNumber().click();
		Reporter.log("Clicked on Building Number");
		Thread.sleep(500);
	}
	
	public void selectFloor() throws Exception {
		floorNumber().click();
		Reporter.log("Clicked on Floor Number");
		Thread.sleep(500);
	}
	
	public void clickBackArrow() throws Exception {
		btn_backArrow().click();
		Reporter.log("Clicked on back arrow");
		Thread.sleep(500);
	}
	
	public void clickPreference() throws Exception {
		floorNumber().click();
		Reporter.log("Clicked on Floor Number");
		Thread.sleep(500);
	}
	
	public void clickClearBtn() throws Exception {
		clearText().click();
		Reporter.log("Clicked on clear text button in the search feild");
		Thread.sleep(500);
	}
	
	public void searchFloor() throws Exception{
		search().sendKeys("11");
	}
	

}
