package com.utc.BD.Pages;

import com.appium.Common.Element;
import com.appium.Common.ObjectMap;

import io.appium.java_client.MobileElement;

public class ConsentAndroid {
	
	private MobileElement Consentform() throws Exception {
		Element.waitforVisible("id", ObjectMap.getvalue("BD-consent-form"));
		return Element.findElementbyID(ObjectMap.getvalue("BD-consent-form"));
	}

	public String consentformText() throws Exception
	
	{
		return Consentform().getText();
	}
	private MobileElement Consentformheader() throws Exception {
		Element.waitforVisible("id", ObjectMap.getvalue("BD-consent-form_header"));
		return Element.findElementbyID(ObjectMap.getvalue("BD-consent-form_header"));
	}

	
	public boolean ConsentformHeaderText() throws Exception {
		return Element.isVisible(Consentformheader());
	}

//BD-consent-form_header_nothanks
	private MobileElement ConsentformGoogleupdate() throws Exception {
		Element.waitforVisible("id", ObjectMap.getvalue("BD-consent-form_header_nothanks"));
		return Element.findElementbyID(ObjectMap.getvalue("BD-consent-form_header_nothanks"));
	}
	public void ConsentformGoogleupdatebtn() throws Exception
	{
		ConsentformGoogleupdate().click();
	}
}




