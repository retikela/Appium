package com.utc.BD.Pages;

import com.appium.Common.Element;
import com.appium.Common.Gestures;
import com.appium.Common.ObjectMap;

import io.appium.java_client.MobileElement;

public class RoutePage {
	Gestures gestures= new Gestures();
	private MobileElement Firstcard() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Direction_card"));
	}
	private MobileElement FirstcardBG() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Direction_card_bg"));
	}
	public boolean waitforFirstcard() throws Exception {
		try {
			return Element.waitForElement(Firstcard(), 95);
		} catch (Exception e) {
			return false;
		}
	}
	public String FirstCardText() throws Exception {
		return Firstcard().getText();
	}
	public void swipeDirectioncard() throws Exception
	{
			Element.swipeLeft(FirstcardBG(), 90);
		//gestures.scrollFromRightToLeftOfScreen();
	}

	private MobileElement Nextimg() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Next_lbl"));
	}
	public String NextimgText() throws Exception {
		return Nextimg().getText();
	}
}