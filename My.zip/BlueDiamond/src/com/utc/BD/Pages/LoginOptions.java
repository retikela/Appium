    package com.utc.BD.Pages;



	import org.openqa.selenium.Point;
	import org.testng.Reporter;
	import org.testng.asserts.SoftAssert;

	import com.appium.Common.AppiumSetup;
	import com.appium.Common.Element;
	import com.appium.Common.GenericFunctions;
	import com.appium.Common.ObjectMap;

	import io.appium.java_client.MobileElement;
	import io.appium.java_client.TouchAction;
	import io.appium.java_client.android.AndroidElement;
	import io.appium.java_client.touch.offset.PointOption;

	public class LoginOptions {
		
		SoftAssert sa = new SoftAssert();

		public MobileElement url() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("Login_tbx_url"));
		}

		public MobileElement authcode() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("Login_tbx_authcode"));
		}

		public MobileElement pin() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("Login_tbx_pin"));
		}

		public MobileElement signIn() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("Login_btn_next"));
		}

		public MobileElement checkboxEula() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("Login_cbx_EULA"));
		}

		public MobileElement Eula() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("Login_lbl_EULA"));
		}

		public MobileElement Privacy() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("Login_lbl_DataPrivacy"));
		}

		public MobileElement checkboxDataPrivacy() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("Login_cbx_DataPrivacy"));
		}

		public MobileElement logo() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("Login_img_logo"));
		}

		public MobileElement authenticationSucess() throws Exception {
			return Element.findElementbyXpath("//*[@text='Authorization is Successful.']");
		}

		public boolean waitforLogo() throws Exception {
			return Element.waitForElement(logo());
		}

		public MobileElement waitforLogo1() throws Exception {
			return Element.findElementbyXpath("");
		}

		public MobileElement lbl_url() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("Login_lbl_URL"));
		}

		public MobileElement lbl_authCode() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("Login_lbl_AuthCode"));
		}

		public MobileElement lbl_Pin() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("Login_lbl_PIN"));
		}
		
		public MobileElement lbl_toolKit() throws Exception {
			if (GenericFunctions.isAndroid()) {
				return Element.findElementbyID(ObjectMap.getvalue("Home_lbl_toolKit"));
			} else {
				return Element.findElementbyXpath(ObjectMap.getvalue("Home_lbl_toolKit"));
			}
		}
		
		public MobileElement lbl_error() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("Login_lbl_error"));
		}
		
		public MobileElement overlay_EULA() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("Login_lbl_EULAPopUp"));
		}
		
		public MobileElement overlay_privacy() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("Login_lbl_EULAPopUp"));
		}
		
		public MobileElement overlay_close() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("Login_img_close"));
		}
		
		public MobileElement image_BD() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("Login_img_logo"));
		}
		
		public MobileElement btn_showPwd() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("Login_btn_showPwd"));
		}
		
		
		public MobileElement progressBar_signIn() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("Login_progressBar_signInProgress"));
		}
		
		public MobileElement btn_allowLocation() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("location_btn_allow"));
		}
		
		
		// Login with Cumulus
		
		public MobileElement headerEulaAcceptance() throws Exception {
			if (GenericFunctions.isAndroid()) {
				return Element.findElementbyID(ObjectMap.getvalue("cumulus_lbl_header"));
			} else {
				return Element.findElementbyID(ObjectMap.getvalue("cumulus_lbl_header"));
				//return Element.findElementbyXpath(ObjectMap.getvalue("cumulus_lbl_header"));
			}
		}
		
		public MobileElement checkBoxEULA_cumulus() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("cumulus_btn_eulaCheckbox"));
		}
		
		public MobileElement checkBoxPrivacy_cumulus() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("cumulus_btn_privacyCheckbox"));
		}
		
		public MobileElement lblEULA_cumulus() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("cumulus_lbl_eula"));
		}
		
		public MobileElement lblPrivacy_cumulus() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("cumulus_lbl_privacyPolicy"));
		}
		
		public MobileElement btnContinue_cumulus() throws Exception {
				return Element.findElementbyID(ObjectMap.getvalue("cumulus_btn_continue"));
		}
		
		public MobileElement btnCloseEULA() throws Exception {
		//	if (GenericFunctions.isAndroid()) {
				return Element.findElementbyID(ObjectMap.getvalue("Eula_btn_close"));
		//	} else {
			//	return Element.findElementbyXpath(ObjectMap.getvalue("Eula_btn_close"));
		//	}
		}
		
		public MobileElement headerEULA() throws Exception {
		//	if (GenericFunctions.isAndroid()) {
				return Element.findElementbyID(ObjectMap.getvalue("EULA_lbl_header"));
			//} else {
		//		return Element.findElementbyXpath(ObjectMap.getvalue("EULA_lbl_header"));
		//	}
		}
		
		public MobileElement headerPrivacy() throws Exception {
		//	if (GenericFunctions.isAndroid()) {
				return Element.findElementbyID(ObjectMap.getvalue("Privacy_lbl_header"));
		//	} else {
				//return Element.findElementbyXpath(ObjectMap.getvalue("Privacy_lbl_header"));
			//}
		}
		
		// Options screen
		
		public MobileElement options_lbl_header() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("options_lbl_header"));
		}
		
		public MobileElement options_lbl_verbiage() throws Exception {
			if (GenericFunctions.isAndroid()) {
				return Element.findElementbyXpath(ObjectMap.getvalue("options_lbl_verbiage"));
			} else {
				return Element.findElementbyID(ObjectMap.getvalue("options_lbl_verbiage"));
			}
		}

		public MobileElement options_btn_email() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("options_btn_email"));
		}
		
		public MobileElement options_img_toolkit() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("options_img_toolkit"));
		}
		
		public MobileElement options_lbl_toolkit() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("options_lbl_toolkit"));
		}
		
		public MobileElement options_btn_phoneNumber() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("options_btn_phoneNumber"));
		}
		
		public MobileElement choosePhone_btn_none() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("choosePhone_btn_none"));
		}
		
		public MobileElement legacyFlow_lyt_lockOut() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("legacyFlow_lyt_lockOut"));
		}
		
		public MobileElement legacyFlow_lbl_lockOut() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("legacyFlow_lbl_lockOut"));
		}
		
		public MobileElement options_img_email() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("options_img_email"));
		}
		
		public MobileElement options_lbl_emailTitle() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("options_lbl_emailTitle"));
		}
		
		public MobileElement options_lbl_emailHelp() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("options_lbl_emailHelp"));
		}
		
		public MobileElement options_lbl_emailSystem() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("options_lbl_emailSystem"));
		}
		
		public MobileElement options_img_phone() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("options_img_phone"));
		}
		
		public MobileElement options_lbl_phoneTitle() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("options_lbl_phoneTitle"));
		}
		
		public MobileElement options_lbl_phoneHelp() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("options_lbl_phoneHelp"));
		}
		
		public MobileElement options_lbl_phoneSystem() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("options_lbl_phoneSystem"));
		}
		
		
		
		public MobileElement btn_none() throws Exception {
			if (GenericFunctions.isAndroid()) {
				return Element.findElementbyID("cancel");
			} else {
				return Element.findElementbyXpath(ObjectMap.getvalue("firmwareUpgrade_btn_cancel"));
			}
		}
		
		// Enter phone number page
		
		public MobileElement phone_lbl_header() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("phone_lbl_header"));
		}
		
		public MobileElement phone_lbl_verbiage() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("phone_lbl_verbiage"));
		}
		
		public MobileElement phone_lbl_countryCode() throws Exception {
			return Element.findElementbyXpath(ObjectMap.getvalue("phone_lbl_countryCode"));
		}
		
		public MobileElement phone_lbl_countryName() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("phone_lbl_countryName"));
		}
		
		public MobileElement phone_tbx_phoneNumber() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("phone_tbx_phoneNumber"));
		}
		
		public MobileElement phone_btn_continue() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("phone_btn_continue"));
		}
		
		public MobileElement phone_btn_close() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("phone_btn_close"));
		}
		
		public MobileElement email_btn_close() throws Exception {
			//if (GenericFunctions.isAndroid()) {
				return Element.findElementbyID(ObjectMap.getvalue("email_btn_close"));
		//	} else {
		//		return Element.findElementbyXpath(ObjectMap.getvalue("email_btn_close"));
		//	}
		}
		
		public MobileElement phone_btn_dropDown() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("phone_btn_dropDown"));
		}
		
		public MobileElement phone_img_progress() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("phone_img_progress"));
		}
		
		public MobileElement phone_lbl_errorPhoneNumber() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("phone_lbl_errorPhoneNumber"));
		}
		
		public MobileElement phone_lbl_errorPhoneNumberRequired() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("phone_lbl_errorPhoneNumberRequired"));
		}
		
		public MobileElement phone_btn_eraseText() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("phone_btn_eraseText"));
		}
		
		public MobileElement searchCountryName() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("country_txb_search"));
		}
		
		public MobileElement selectCountryName() throws Exception {
			if (GenericFunctions.isAndroid()) {
				return Element.findElementbyID(ObjectMap.getvalue("country_lbl_searchItem"));
			} else {
				return Element.findElementbyXpath(ObjectMap.getvalue("country_lbl_searchItem"));
			}
		}
		
		
		// Verification code screen
		
		public MobileElement verify_lbl_header() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("verify_lbl_header"));
		}
		
		public MobileElement verify_lbl_verificationCode() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("verify_lbl_verificationCode"));
		}
		
		public MobileElement verify_lbl_confirmEmail() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("verify_lbl_confirmEmail"));
		}
		
		public MobileElement verify_tbx_verificationCode() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("verify_tbx_verificationCode"));
		}
		
		public MobileElement verify_tbx_confirmEmail() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("verify_tbx_confirmEmail"));
		}
		
		public MobileElement verify_btn_login() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("verify_btn_login"));
		}
		
		public MobileElement verify_btn_back() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("verify_btn_back"));
		}
		
		public MobileElement verify_btn_clearVerificationCode() throws Exception {
			if (GenericFunctions.isAndroid()) {
				return Element.findElementbyID(ObjectMap.getvalue("verify_btn_clearVerificationCode"));
			} else {
				return Element.findElementbyXpath(ObjectMap.getvalue("verify_btn_clearVerificationCode"));
			}
		}
		
		public MobileElement verify_btn_clearEmail() throws Exception {
			if (GenericFunctions.isAndroid()) {
				return Element.findElementbyID(ObjectMap.getvalue("verify_btn_clearEmail"));
			} else {
				return Element.findElementbyXpath(ObjectMap.getvalue("verify_btn_clearEmail"));
			}
		}

		public MobileElement verify_lbl_errorEmail() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("verify_lbl_errorEmail"));
		}
		
		public MobileElement verify_lbl_lockOut() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("verify_lbl_lockOut"));
		}
		
		public MobileElement verify_lyt_lockOut() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("verify_lyt_lockOut"));
		}
		
		public MobileElement verify_btn_resendCode() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("verify_btn_resendCode"));
		}
		
		// End of verification code locator info
		

		public boolean waitForSucessMessage() throws Exception {
			
			return Element.waitForElement(authenticationSucess(),20);
		}
		
		public void clickAllow() throws Exception {
			
			btn_allowLocation().click();
		}
		
		
		public boolean verifyEULA() throws Exception {
			
			boolean elementState = overlay_EULA().isDisplayed();
			
			Reporter.log("EULA Overlay appeared as expected.");
			
			return elementState;
		}
		
		public boolean verifyPrivacy() throws Exception {
			
			boolean elementState = overlay_privacy().isDisplayed();
			
			Reporter.log("Privacy Overlay appeared as expected.");
			
			return elementState;
		}
		
		public void closeOverlay() throws Exception {
			
			overlay_close().click();
			Thread.sleep(1000);
			Reporter.log("Clicked on the close button in the overlay.");
		}
		
		public void clickEULA() throws Exception {
			
			//Element.clickJS(Eula());
			//MobileElement element = (MobileElement) AppiumSetup.driver.findElementByAccessibilityId("SomeAccessibilityID");
			//Point location = element.getLocation();
			
			Point location = Eula().getLocation();
			
			System.out.println(location.getX()); // 245
			System.out.println(location.getY()); //1660
			
			/*Appium.driver

			new TouchAction(AppiumSetup.driver).tap(245, 1660).perform();
			
			TouchAction action= new TouchAction(driver);
			action.press(271, 642).release().perform();*/

			Point point = Eula().getLocation(); 
			
			int x = point.x +1; int y = point.y + Eula().getSize().getHeight() - 1; 
			
			new TouchAction(AppiumSetup.driver).tap(PointOption.point(x, y)).perform();
			
			Thread.sleep(1000);
			Reporter.log("Clicked on the EULA link");
			
		}
		
		public void clickPrivacy() throws Exception {
			
			Privacy().click();
			Thread.sleep(1000);
			Reporter.log("Clicked on the EULA link");
			
		}
		
		
		
		public void verifyElementAvailibility() {
			
			try {
				sa.assertEquals(lbl_url().isDisplayed(), true, "Url label is present.");
				Reporter.log("URL label is available on the page.");
				sa.assertEquals(lbl_authCode().isDisplayed(), true, "Authorization code label is present.");
				Reporter.log("Auth Code label is available on the page.");
				sa.assertEquals(lbl_Pin().isDisplayed(), true, "Pin label is present.");
				Reporter.log("Pin label is available on the page.");
				sa.assertEquals(url().isDisplayed(), true, "Url text box is present.");
				Reporter.log("URL text box is available on the page.");
				sa.assertEquals(authcode().isDisplayed(), true, "Authorization code text box is present.");
				Reporter.log("Auth code text box is available on the page.");
				sa.assertEquals(pin().isDisplayed(), true, "Pin code text box is present.");
				Reporter.log("Pin text box is available on the page.");
				sa.assertEquals(checkboxEula().isDisplayed(), true, "Eula check box is present.");
				Reporter.log("Eula check box is available on the page.");
				sa.assertEquals(checkboxDataPrivacy().isDisplayed(), true, "Data privacy checkbox is present.");
				Reporter.log("Data privacy check box is available on the page.");
				sa.assertEquals(Privacy(), true, "Privacy message is present.");
				Reporter.log("Privacy message is available on the page.");
				sa.assertEquals(Eula().isDisplayed(), true, "Eula message is present.");
				Reporter.log("Eula message is available on the page.");
				
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
			
		/*
		 * public MobileElement LocationServicesAlertinfo() throws Exception { return
		 * Element.findElementbyID(ObjectMap.getvalue("LocationServicesAlert_lbl_info"))
		 * ; }
		 * 
		 * public boolean waitforLocationServicesAlertinfo() { try { return
		 * Element.waitForElement(LocationServicesAlertinfo(), 3); } catch (Exception e)
		 * { return false; } }
		 * 
		 * public MobileElement whileUsing() throws Exception { return
		 * Element.findElementbyID(ObjectMap.getvalue(
		 * "LocationServicesAlert_btn_whileUsing")); }
		 * 
		 * public void clickWhileUsing() throws Exception {
		 * if(waitforLocationServicesAlertinfo()) whileUsing().click(); }
		 * 
		 * public MobileElement alwaysAllow() throws Exception { return
		 * Element.findElementbyID(ObjectMap.getvalue(
		 * "LocationServicesAlert_btn_alwaysAllow")); }
		 * 
		 * public void clickAlwaysAllow() throws Exception {
		 * if(waitforLocationServicesAlertinfo()) alwaysAllow().click(); }
		 * 
		 * public MobileElement dontAllow() throws Exception { return
		 * Element.findElementbyID(ObjectMap.getvalue(
		 * "LocationServicesAlert_btn_dontAllow")); }
		 * 
		 * public void clickDontAllow() throws Exception {
		 * if(waitforLocationServicesAlertinfo()) dontAllow().click(); }
		 * 
		 * public MobileElement NotificationsAlertinfo() throws Exception { return
		 * Element.findElementbyID(ObjectMap.getvalue("NotificationsAlert_lbl_info")); }
		 * 
		 * public boolean waitforNotificationsAlertinfo() { try { return
		 * Element.waitForElement(NotificationsAlertinfo(), 3); } catch (Exception e) {
		 * return false; } }
		 * 
		 * public MobileElement allow() throws Exception { return
		 * Element.findElementbyID(ObjectMap.getvalue("NotificationsAlert_btn_allow"));
		 * }
		 * 
		 * public void clickAllow() throws Exception {
		 * if(waitforNotificationsAlertinfo()) allow().click(); }
		 * 
		 * public MobileElement NotificationdontAllow() throws Exception { return
		 * Element.findElementbyID(ObjectMap.getvalue("NotificationsAlert_btn_dontAllow"
		 * )); }
		 * 
		 * public void clickNotificationsAllow() throws Exception {
		 * if(waitforNotificationsAlertinfo()) NotificationdontAllow().click(); }
		 */
		public void enterUrl(String name) throws Exception {
			url().clear();
			url().sendKeys(name);
			Thread.sleep(600);
			GenericFunctions.pressBack();
			Reporter.log("Entered URL & minimized the keyboard.");
			Thread.sleep(600);
		}

		public String getUrl() throws Exception {
			return url().getText();
		}

		public void enterAuthcode(String authcode) throws Exception {
			authcode().sendKeys(authcode);
			Thread.sleep(600);
			GenericFunctions.pressBack();
			Reporter.log("Entered AuthCode & minimized the keyboard.");
			Thread.sleep(600);
		}

		public void enterPin(String pin) throws Exception {
			pin().sendKeys(pin);
			Thread.sleep(600);
			GenericFunctions.pressBack();
			Reporter.log("Entered PIN & minimized the keyboard.");
			Thread.sleep(600);
		}

		public void clickSignin() throws Exception {
			signIn().click();
			Reporter.log("Clicked on the sign in button.");
			Thread.sleep(3000);
		}

		public void checkEula() throws Exception {
			if (!getEulaStatus()) {
				checkboxEula().click();
				Reporter.log("Selected the EULA check box");
			}
		}

		public void checkDataPrivacy() throws Exception {
			if (!getDataPrivacyStatus()) {
				checkboxDataPrivacy().click();
				Reporter.log("Selected the Privacy check box");
			}
		}

		public void uncheckEula() throws Exception {
			if (getEulaStatus()) {
				checkboxEula().click();
			}
		}
		
		public boolean waitForSignInProgress() throws Exception {
			boolean syncComplete =  Element.waitforInVisibility("id","aidSignInProgress", 30);
			Reporter.log("Waiting for sign in progress bar to disappear.");
			return syncComplete;
		}

		public void uncheckDataPrivacy() throws Exception {
			if (getDataPrivacyStatus()) {
				checkboxDataPrivacy().click();
			}
		}

		private boolean getEulaStatus() throws Exception {
			return GenericFunctions.getInstance().isCheckBocChecked(checkboxEula());
		}

		private boolean getDataPrivacyStatus() throws Exception {
			return GenericFunctions.getInstance().isCheckBocChecked(checkboxDataPrivacy());
		}

		public MobileElement errorTitle() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("Login_lbl_errorTitle"));
		}

		public MobileElement errorDescription() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("Login_lbl_errorDescription"));
		}

		public MobileElement errorDismiss() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("Login_btn_errorDismiss"));
		}

		public String getErrorTitle() throws Exception {
			return errorTitle().getText();
		}

		public String getErrorDescription() throws Exception {
			return errorDescription().getText();
		}

		public boolean waitforDismiss() throws Exception {
			return Element.waitForElement(errorDismiss(), 15);
		}

		public void clickDismiss() throws Exception {
			errorDismiss().click();
		}
		public boolean verfifyIdentitiesListAvailibility() throws Exception {

			try {
				home_lbl_identities().isDisplayed();
				return true;
			} catch (Exception e) {
				Reporter.log("Identities list widget is not available in home screen, Since user has logged in via auth code");
				return false;
			}
		}
		public MobileElement home_lbl_identities() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("home_lbl_identities"));
		}
		
		public String getEULAtxt() throws Exception {
			
			if(GenericFunctions.isIOS()) {
				return Eula().getAttribute("value");
			} else {
				return Eula().getText();
			}
			
		}

		public String getPrivacytxt() throws Exception {
			return Privacy().getText();
		}

		public String getNextTxt() throws Exception {
			return signIn().getText();
		}
		
		public boolean getSignBtnVisibility() throws Exception {
			return Element.isEnabled(signIn());
		}
		
		public boolean waitForHomePage() throws Exception {
			boolean syncComplete = false;
			if (GenericFunctions.isAndroid()) {
				Thread.sleep(1000);
				syncComplete = lbl_toolKit().isDisplayed();
				Reporter.log("Post Sync completion, Landed on Toolkit home screen");
				return syncComplete;
			} else {
				syncComplete = lbl_toolKit().isDisplayed();
				Reporter.log("Post Sync completion, Landed on Toolkit home screen");
				return syncComplete;
			}
		}
		
		public boolean navigateToHomeScreen() throws Exception {
			boolean syncComplete = false;
			if (GenericFunctions.isAndroid()) {
				Thread.sleep(300);
				syncComplete = lbl_toolKit().isDisplayed();
				Reporter.log("Successfully navigated to home screen");
				return syncComplete;
			} else {
				syncComplete = lbl_toolKit().isDisplayed();
				Reporter.log("Successfully navigated to home screen");
				return syncComplete;
			}
		}
		
		public String getErrorText() throws Exception {
			
			return lbl_error().getText();
		}
		
		public void checkPinMask() throws Exception {
			
		
			String maskedPin = pin().getText();
			System.out.println(maskedPin);
			btn_showPwd().click();
			String unmaskedPin = pin().getText();
			System.out.println(unmaskedPin);
			
			if(!maskedPin.equals(unmaskedPin)) {
				System.out.println("Pin is getting masked as expected.");
			} else {
				System.out.println("Pin is not getting masked.");
			}
			
		}
		
		public String verifyAuthCodeCaseSensitivity() throws Exception {
			
			return authcode().getText();
			
		}
		
		public String convertIntoUpper(String data) throws Exception {
			
			authcode().sendKeys(data);
			return data.toUpperCase();
		}
		
		// Login with Cumulus 
		
		public void selectEULACumulus() throws Exception {
			
			checkBoxEULA_cumulus().click();
			Reporter.log("Selected EULA checkbox");
		}
		
		public void selectPrivacyCumulus() throws Exception {
			
			checkBoxPrivacy_cumulus().click();
			Reporter.log("Selected Privacy checkbox");
		}
		
		public void clickContinueCumulus() throws Exception {
			
			btnContinue_cumulus().click();
			Reporter.log("Clicked on Continue button in EULA & Privacy screen");
			
		}
		
		public void clickEULACumulus() throws Exception {
			
			lblEULA_cumulus().click();
			Reporter.log("Clicked on EULA label");
		}
		
		public void clickPrivacyCumulus() throws Exception {
			
			lblPrivacy_cumulus().click();
			Reporter.log("Clicked on Privacy label");
		}
		
		public String getEulaAcceptanceHeaderText() throws Exception {

			return headerEulaAcceptance().getText();
		}

		public String getEULALabelTextCumulus() throws Exception {

			return lblEULA_cumulus().getText();
		}

		public String getPrivacyTextCumulus() throws Exception {

			return lblPrivacy_cumulus().getText();
		}
		
		public String getEULAPageHeader() throws Exception {

			return headerEULA().getText();
		}
		
		public String getPrivacyPageHeader() throws Exception {

			return headerPrivacy().getText();
		}
		
		public void clickBack() throws Exception {

			btnCloseEULA().click();
			Reporter.log("Clicked on back button");
		}
		
		
		// Options screen methods
		
		public void clickEmailOption() throws Exception {
			if (GenericFunctions.isAndroid()) {
				options_btn_email().click();
			} else {
				options_img_email().click();
			}
			Reporter.log("Clicked on login with email option");
		}
		
		public void clickPhoneNumberOption() throws Exception {
			//if (GenericFunctions.isAndroid()) {
				options_btn_phoneNumber().click();
			//} else {
			//	options_lbl_phoneHelp().click();
		//	}
			Reporter.log("Clicked on login with phone number option");
		}
		
		public void clickBackFromEmailPage() throws Exception{
			options_btn_phoneNumber().click();
			Reporter.log("Clicked on login with email option");
		}
		
		public String getOptionsPageHeader() throws Exception {

			return options_lbl_header().getText();
		}
		
		public String getOptionsPageVerbiage() throws Exception {

			return options_lbl_verbiage().getText();
		}
		
		public String getOptionsProductName() throws Exception {

			return options_lbl_toolkit().getText();
		}
		
		public String getOptionsEmailHeader() throws Exception {

			return options_lbl_emailTitle().getText();
		}
		
		public String getOptionsEmailHelp() throws Exception {

			return options_lbl_emailHelp().getText();
		}
		
		public String getOptionsEmailSystem() throws Exception {

			return options_lbl_emailSystem().getText();
		}
		
		public String getOptionsPhoneHeader() throws Exception {

			return options_lbl_phoneTitle().getText();
		}
		
		public String getOptionsPhoneHelp() throws Exception {

			return options_lbl_phoneHelp().getText();
		}
		
		public String getOptionsPhoneSystem() throws Exception {

			return options_lbl_phoneSystem().getText();
		}
		
		
		public void clickNoneOfAbove() throws Exception {
			if (GenericFunctions.isAndroid()) {
				btn_none().click();
				Reporter.log("Clicked on none of the above option");
				Thread.sleep(1000);
			}
		}
		
		// Enter phone number screen
		
		public String getVerifyPhoneNumberPageHeader() throws Exception {

			return phone_lbl_header().getText();
		}
		
		public String getVerifyPhoneNumberPageVerbiage() throws Exception {

			return phone_lbl_verbiage().getText();
		}
		
		public String getCountryName() throws Exception {

			return phone_lbl_countryName().getText();
		}
		
		public String getCountryCodeLbl() throws Exception {

			return phone_lbl_countryCode().getText();
		}
		
		public void clickContinue_phoneNumber() throws Exception{
			phone_btn_continue().click();
			Reporter.log("Clicked on continue button in verify phone number screen");
		}
		
		public void clickBack_phoneNumber() throws Exception{
			phone_btn_close().click();
			Reporter.log("Clicked on back button in verify phone number screen");
		}
		
		public void clickChooseCountry() throws Exception{
			phone_btn_dropDown().click();
			Reporter.log("Clicked on back button in verify phone number screen");
		}
		
		public void enterPhoneNumber(String phoneNumber) throws Exception{
			phone_tbx_phoneNumber().sendKeys(phoneNumber);
			Reporter.log("Entered phone number : "+phoneNumber+" in the text field");
		}
		
		public void clickPhoneNumber() throws Exception{
			phone_tbx_phoneNumber().click();
			Reporter.log("Clicked on Phone number edit field");
		}
		
		public void clickClearText() throws Exception{
			phone_btn_eraseText().click();
			Reporter.log("Clicked on clear text button in the field");
		}
		
		
		public MobileElement btn_search() throws Exception {
			if (GenericFunctions.isAndroid()) {
				return Element.findElementbyID("edt_search");
			} else {
				return Element.findElementbyXpath(ObjectMap.getvalue("firmwareUpgrade_btn_cancel"));
			}
		}
		
		public void enterCountryName(String countryname) throws Exception{
			
			searchCountryName().click();
			searchCountryName().sendKeys(countryname);
			selectCountryName().click();
		}
		
		public boolean waitForVerification() throws Exception {
			boolean syncComplete =  Element.waitforInVisibility("id",ObjectMap.getvalue("phone_img_progress"), 30);
			Reporter.log("Waiting for verfication progress bar to disappear.");
			return syncComplete;
		}
		
		public boolean waitForSendingVerification() throws Exception {
			boolean syncComplete =  Element.waitforInVisibility("id",ObjectMap.getvalue("verify_img_sendingVerfCode"), 30);
			Reporter.log("Waiting for verfication progress bar to disappear.");
			return syncComplete;
		}
		
		public String getErrorMessageTextPhoneNumber() throws Exception {

			return phone_lbl_errorPhoneNumber().getText();
		}
		
		
		// Verification code methods
		
		public String getVerificationCodePageHeader() throws Exception {

			return verify_lbl_header().getText();
		}
		
		public String getVerificationCodeLblText() throws Exception {

			return verify_lbl_verificationCode().getText();
		}
		
		public String getConfirmEmailLblText() throws Exception {

			return verify_lbl_confirmEmail().getText();
		}
		
		public void clickLogin_Verification() throws Exception{
			verify_btn_login().click();
			Reporter.log("Clicked on login button in verification code screen");
		}
		
		public void clickBack_Verification() throws Exception{
			verify_btn_back().click();
			Reporter.log("Clicked on back button in verification code screen");
		}
		
		public void enterConfirmEmail(String email) throws Exception{
			verify_tbx_confirmEmail().sendKeys(email);
			Reporter.log("Entered email address in the text field");
		}
		
		public void clickConfirmEmail() throws Exception{
			verify_tbx_confirmEmail().click();
			Reporter.log("Clicked on confirm email address text field");
		}
		
		public void enterVerificationCode(String verificationCode) throws Exception{
			verify_tbx_verificationCode().sendKeys(verificationCode);
			Reporter.log("Entered verification code : "+verificationCode+" in the text field");
		}
		
		public void clickVerificationCode() throws Exception{
			verify_tbx_verificationCode().click();
			Reporter.log("Clicked on verification code edit field");
		}
		
		public void clickClearVerificationCode() throws Exception{
			verify_btn_clearVerificationCode().click();
			Reporter.log("Clicked on clear button in verification code screen");
		}
		
		public void clickClearEmail() throws Exception{
			verify_btn_clearEmail().click();
			Reporter.log("Clicked on clear button in Email screen");
		}
		
		public void clickResendCode() throws Exception{
			verify_btn_resendCode().click();
			Reporter.log("Clicked on resend code link");
		}
		
		public String getErrorMessageVerificationCode() throws Exception {

			return verify_lbl_errorEmail().getText();
		}
		
		public String getErrorMessageLockOut() throws Exception {

			return verify_lbl_lockOut().getText();
		}
		
		public String getErrorMessageLockOut_legacy() throws Exception {

			return legacyFlow_lbl_lockOut().getText();
		}
		
		public boolean waitForSignIn() throws Exception {
			boolean syncComplete =  Element.waitforInVisibility("id",ObjectMap.getvalue("verify_img_inProgress"), 30);
			Reporter.log("Waiting for verfication progress bar to disappear.");
			return syncComplete;
		}
		
		public MobileElement alertMessageResendCode() throws Exception {
			return Element.findElementbyXpath(ObjectMap.getvalue("alreadyAssigned_lbl_alert"));
		}

		public MobileElement alertTitleResendCode() throws Exception {
			return Element.findElementbyXpath(ObjectMap.getvalue("alreadyAssigned_lbl_alertTitle"));
		}
		
		public String getTitleFromAlertResendCode() throws Exception {
			if (GenericFunctions.isAndroid()) {
				return GenericFunctions.getInstance().getAlertTitle();
			} else {
				return alertTitleResendCode().getText();
			}
		}

		public boolean getMessageFromAlertResendCode() throws Exception {
			String message = "";
			if (GenericFunctions.isAndroid()) {
				message = GenericFunctions.getAlertMsg();
				message = message.replaceAll("\n", " ");
				if(message.contains(ObjectMap.getvalue("resendCode_lbl_txt"))) {
					return true;
				} else {
					return false;
				}
				
			} else {
				message  = alertMessageResendCode().getText();
				if(message.contains(ObjectMap.getvalue("resendCode_lbl_txt"))) {
					return true;
				} else {
					return false;
				}
			}
		}
		
		public MobileElement btn_okResend() throws Exception {
			if (GenericFunctions.isAndroid()) {
				return Element.findElementbyID("button2");
			} else {
				return Element.findElementbyXpath(ObjectMap.getvalue("alreadyAssigned_btn_ok"));
			}
		}
		
		public void clickOkOnResendCode() throws Exception {
			btn_okResend().click();
			Reporter.log("Clicked on OK in Resend code alert.");
			Thread.sleep(1000);
		}
		
		
		public MobileElement alertMessageResendCodeSuccess() throws Exception {
			return Element.findElementbyXpath(ObjectMap.getvalue("alreadyAssigned_lbl_alert"));
		}

		public MobileElement alertTitleResendCodeSuccess() throws Exception {
			return Element.findElementbyXpath(ObjectMap.getvalue("alreadyAssigned_lbl_alertTitle"));
		}
		
		public String getTitleFromAlertResendCodeSuccess() throws Exception {
			if (GenericFunctions.isAndroid()) {
				return GenericFunctions.getInstance().getAlertTitle();
			} else {
				return alertTitleResendCodeSuccess().getText();
			}
		}

		public boolean getMessageFromAlertResendCodeSucccess() throws Exception {
			String message = "";
			if (GenericFunctions.isAndroid()) {
				message = GenericFunctions.getAlertMsg();
				message = message.replaceAll("\n", " ");
				if(message.contains(ObjectMap.getvalue("resendCodeSucess_lbl_txt"))) {
					return true;
				} else {
					return false;
				}
				
			} else {
				message  = alertMessageResendCodeSuccess().getText();
				if(message.contains(ObjectMap.getvalue("resendCodeSucess_lbl_txt"))) {
					return true;
				} else {
					return false;
				}
			}
		}
		
		public MobileElement btn_okResendSucess() throws Exception {
			if (GenericFunctions.isAndroid()) {
				return Element.findElementbyID("button2");
			} else {
				return Element.findElementbyXpath(ObjectMap.getvalue("alreadyAssigned_btn_ok"));
			}
		}
		
		public void clickOkOnResendCodeSuccess() throws Exception {
			btn_okResendSucess().click();
			Reporter.log("Clicked on OK in Resend code alert.");
			Thread.sleep(1000);
		}

		
	} 



