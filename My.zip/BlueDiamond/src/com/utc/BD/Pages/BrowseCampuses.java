package com.utc.BD.Pages;

import org.testng.Reporter;

import com.appium.Common.Element;
import com.appium.Common.GenericFunctions;
import com.appium.Common.ObjectMap;

import io.appium.java_client.MobileElement;

public class BrowseCampuses {
	
	public MobileElement header_browseCampuses() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("campuses_lbl_header"));
	}
	
	public MobileElement search_campus() throws Exception {
		if (GenericFunctions.isAndroid()) {
			return Element.findElementbyID(ObjectMap.getvalue("campuses_txtFld_search"));
		} else {
			return Element.findElementbyXpath(ObjectMap.getvalue("campuses_txtFld_search"));
		}
	}
	
	public MobileElement btn_cancel() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("campuses_lbl_cancel"));
	}
	
	public MobileElement buildingNumber() throws Exception {
		if (GenericFunctions.isIOS()) {
			return Element.findElementbyID(ObjectMap.getvalue("campuses_lbl_building"));
		} else {
			return Element.findElementbyID(ObjectMap.getvalue("campuses_lbl_building"));
		}
	}
	
	public MobileElement preference() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("campuses_img_preferenceArrow"));
	}
	
	public MobileElement btn_backArrow() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("campuses_btn_backArrow"));
	}
	
	public MobileElement btn_backArrowToCampus() throws Exception {
		return Element.findElementbyXpath(ObjectMap.getvalue("campuses_btn_backArrowToCampus"));
	}
	
	public MobileElement campusName() throws Exception {
		if (GenericFunctions.isIOS()) {
			return Element.findElementbyID(ObjectMap.getvalue("campuses_lbl_campus"));
		} else {
			return Element.findElementbyID(ObjectMap.getvalue("campuses_lbl_campus"));
		}
	}
	
	public MobileElement selectedCampusName() throws Exception {
		if (GenericFunctions.isIOS()) {
			return Element.findElementbyXpath(ObjectMap.getvalue("campuses_lbl_selectedCampus"));
		} else {
			return Element.findElementbyID(ObjectMap.getvalue("campuses_lbl_selectedCampus"));
		}
	}
	
	public MobileElement selectedBuildingName() throws Exception {
		if (GenericFunctions.isIOS()) {
			return Element.findElementbyXpath(ObjectMap.getvalue("campuses_lbl_selectedBuilding"));
		} else {
			return Element.findElementbyID(ObjectMap.getvalue("campuses_lbl_selectedBuilding"));
		}
	}

	public MobileElement floorNumber() throws Exception {
			return Element.findElementbyID(ObjectMap.getvalue("campuses_lbl_floor"));
	}
	
	public MobileElement search() throws Exception {
		if (GenericFunctions.isAndroid()) {
			return Element.findElementbyID(ObjectMap.getvalue("campuses_txtFld_search"));
		} else {
			return Element.findElementbyXpath(ObjectMap.getvalue("campuses_txtFld_search"));
		}
	}
	
	public MobileElement clearText() throws Exception{
		if (GenericFunctions.isAndroid()) {
		return Element.findElementbyID(ObjectMap.getvalue("campuses_btn_clearText"));
		} else {
			return Element.findElementbyXpath(ObjectMap.getvalue("campuses_btn_clearText"));
		}
	}
	
	public void selectCampus() throws Exception {
		campusName().click();
		Thread.sleep(500);
		Reporter.log("Clicked on Campuse name");
	}
	
	public void selectBuilding() throws Exception {
		buildingNumber().click();
		Thread.sleep(500);
		Reporter.log("Clicked on Building name");
	}
	
	public void selectFloor() throws Exception {
		floorNumber().click();
		Thread.sleep(500);
		Reporter.log("Clicked on Floor name");
	}
	
	public void clickBackArrow() throws Exception {
		btn_backArrow().click();
		Thread.sleep(500);
		Reporter.log("Clicked on back arrow");
	}
	
	public void clickBackArrowToCampus() throws Exception {
		btn_backArrowToCampus().click();
		Thread.sleep(500);
		Reporter.log("Clicked on back arrow");
	}
	
	public void clickPreference() throws Exception {
		preference().click();
		Thread.sleep(500);
		Reporter.log("Clicked on preference arrow");
	}
	
	public void clickClearBtn() throws Exception {
		clearText().click();
		Thread.sleep(500);
		Reporter.log("Clicked on Clear text button");
	}
	
	public void searchFloor() throws Exception{
		search().sendKeys("11");
	}
		
	public String verifyPageTitle() throws Exception {
		return header_browseCampuses().getText();
	}
	
	public void clickSearch() throws Exception {
		search_campus().click();
		Thread.sleep(500);
		Reporter.log("Clicked on search feild in Browse Campus screen");
	}

	public void clickCancel() throws Exception {
		btn_cancel().click();
		Thread.sleep(500);
		Reporter.log("Clicked on cancel button in Browse Campus screen");
	}
	
	public String getCampusName() throws Exception {
		return campusName().getText();
	}
	
	public String getBuildingName() throws Exception {
		return buildingNumber().getText();
	}
	
	public String getFloorName() throws Exception {
		return floorNumber().getText();
	}
	
	public String getSelectedCampusName() throws Exception {
		return selectedCampusName().getText();
	}
	
	public String getSelectedBuildingName() throws Exception {
		return selectedBuildingName().getText();
	}
}
