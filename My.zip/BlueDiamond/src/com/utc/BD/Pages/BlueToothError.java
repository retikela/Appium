package com.utc.BD.Pages;

import com.appium.Common.Element;
import com.appium.Common.GenericFunctions;
import com.appium.Common.Gestures;
import com.appium.Common.ObjectMap;

import io.appium.java_client.MobileElement;

public class BlueToothError {

	
	private MobileElement deviceSettings() throws Exception{
		return Element.findElementbyXpath(ObjectMap.getvalue("Device_Navigate_SettingsScreen"));
	}
	
	private MobileElement returnToApp() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Device_Settings_ReturntoApp"));
	}
	
	public void clickReturnToApp() throws Exception{
//		returnToApp().click();
		 new Gestures().maximizeTheApp();
	}
	
	public boolean waitForDeviceSettings() throws Exception{
		return Element.waitForElement(deviceSettings());
	}
	
	private MobileElement btOffIcon() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("BTerror_img_BluetoothOfficon"));
	}
	
	private MobileElement errorDescription() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("BTerror_lbl_errorDescription"));
	}
	
	private MobileElement errorHint() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("BTerror_lbl_errorHintmsg"));
	}
	
	private MobileElement btOffMessage() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("BTerror_lbl_BluetoothOff"));
	}
	
	private MobileElement btEnableSettingsLink() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("BTerror_btnlink_BluetoothSettings"));
	}
	
	public void clickSettingsLink() throws Exception{
		btEnableSettingsLink().click();
	}
	
	public String getErrorDescription() throws Exception{
		return errorDescription().getText();
	}
	
	public String getBTOffMessage() throws Exception{
		return btOffMessage().getText();
	}
	
	public String getErrorHint() throws Exception{
		return errorHint().getText();
	}
	
	public String getEnableSettingsLink() throws Exception{
		return btEnableSettingsLink().getText();
	}
	
	public boolean waitforBTOffIconIcon() throws Exception{
		return Element.waitForElement(btOffIcon());
	}
	
	public boolean isBluetoothOff() {
		try {
			if(getBTOffMessage().equalsIgnoreCase(ObjectMap.getvalue("BluetoothOff_Message"))){
				return true;
			}else{
				return false;
			}
		} catch (Exception e) {
			return false;
		}
	}
}
