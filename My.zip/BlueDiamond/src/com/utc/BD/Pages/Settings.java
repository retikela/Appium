package com.utc.BD.Pages;

import com.appium.Common.Element;
import com.appium.Common.GenericFunctions;
import com.appium.Common.Gestures;
import com.appium.Common.ObjectMap;

import io.appium.java_client.MobileElement;

public class Settings{
	Gestures gestures= new Gestures();
	
	private MobileElement header() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Settings_Navbar_Header"));
	}
	
	public boolean waitforSettingsHeader() throws Exception {
		return Element.waitForElement(header());
	}
	
	private MobileElement about() throws Exception{
		return Element.findElementbyIdIndex(ObjectMap.getvalue("Settings_lbl_menuList"), Integer.parseInt(ObjectMap.getvalue("Settings_Cell_aboutIndex")));
	}
	
	private MobileElement debug() throws Exception{
		return Element.findElementbyIdIndex(ObjectMap.getvalue("Settings_lbl_menuList"), Integer.parseInt(ObjectMap.getvalue("Settings_Cell_debugIndex")));
	}
	
	private MobileElement credentials() throws Exception{
		return Element.findElementbyIdIndex(ObjectMap.getvalue("Settings_lbl_menuList"), Integer.parseInt(ObjectMap.getvalue("Settings_Cell_credentialsIndex")));
	}
	
	private MobileElement help() throws Exception{
		return Element.findElementbyIdIndex(ObjectMap.getvalue("Settings_lbl_menuList"), Integer.parseInt(ObjectMap.getvalue("Settings_Cell_helpIndex")));
	}
	
	private MobileElement preferences() throws Exception{
		return Element.findElementbyIdIndex(ObjectMap.getvalue("Settings_lbl_menuList"), Integer.parseInt(ObjectMap.getvalue("Settings_Cell_preferencesIndex")));
	}
	
	private MobileElement notification() throws Exception{
		return Element.findElementbyIdIndex(ObjectMap.getvalue("Settings_lbl_menuList"), Integer.parseInt(ObjectMap.getvalue("Settings_Cell_notificationIndex")));
	}
	private MobileElement close() throws Exception{
		if(GenericFunctions.isAndroid()) {
			return Element.findElementbyID(ObjectMap.getvalue("Settings_btn_close"));
		}else
		return Element.findElementbyXpath(ObjectMap.getvalue("Settings_btn_close"));
//		Element.findElementbyClass(GenericFunctions.getInstance().getTableClass());
	}
	
	public void clickCloseButton() throws Exception{
		if(GenericFunctions.isAndroid())
		//Element.swipeLeft(close(), 90);
			System.out.println("Page closed");

		else
		Gestures.clickonRightSideofScreen();

	}
	
	public void clickAbout() throws Exception{
		about().click();
	}
	
	public void clickDebug() throws Exception{
		debug().click();
	}
	
	public void clickCredentials() throws Exception{
		credentials().click();
	}
	
	public void clickHelp() throws Exception{
		help().click();
	}
	
	public void clickPreferences() throws Exception{
		preferences().click();
	}
	
	public void clickNotification() throws Exception{
		notification().click();
	}
	public String getAboutText() throws Exception{
//		return Element.findChildElementsbyClass(about(), GenericFunctions.getLableClass()).get(0).getText();
		return about().getText();
	}
	
	public String getDebugText() throws Exception{
		return debug().getText();
	}
	
	public String getCredentialsText() throws Exception{
//		return Element.findChildElementsbyClass(credentials(), GenericFunctions.getLableClass()).get(0).getText();
		return credentials().getText();
	}
	
	public String getAHelpText() throws Exception{
//		return Element.findChildElementsbyClass(help(), GenericFunctions.getLableClass()).get(0).getText();
		return help().getText();
	}
	
	public String getPreferencesText() throws Exception{
//		return Element.findChildElementsbyClass(preferences(), GenericFunctions.getLableClass()).get(0).getText();
		return preferences().getText();
	}

}
