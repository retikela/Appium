package com.utc.BD.Pages;

import com.appium.Common.Element;
import com.appium.Common.GenericFunctions;
import com.appium.Common.ObjectMap;

import io.appium.java_client.MobileElement;

public class CtHealthAndSafety {
	private MobileElement locationContinueBtn() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("location_btn_continue"));
	}

	private MobileElement selfAssessmentChkBox() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("optIn_cbx_SelfAssessment"));
	}

	private MobileElement assessReqTitle() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("optIn_lbl_assessReqTitle"));
	}

	private MobileElement selfAssRequiredPopUpMsg() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("optIn_lbl_selfAssRequiredPopUpMsg"));
	}

	private MobileElement selfAssRequiredOkBtn() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("optIn_btn_selfAssRequiredOkBtn"));
	}

	private MobileElement socialDistancingChkBox() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("optIn_cbx_SocialDistancing"));
	}

	private MobileElement continueButton() throws Exception {

		return Element.findElementbyID(ObjectMap.getvalue("optIn_btn_Save"));
	}

	private MobileElement healthAndSafety() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("optIn_lbl_H&S"));
	}
	private MobileElement contactNotification() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("optIn_lbl_contactNotification"));
	}

	private MobileElement selfAssessmentTitle() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("optIn_lbl_SelfAssessmentTitle"));
	}

	private MobileElement socialDistancingTitle() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("optIn_lbl_SocialDistancingTitle"));
	}

	private MobileElement healthAndSafetyDescription() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("optIn_lbl_H&S_Desc"));
	}

	private MobileElement selfAssessmentDescription() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("optIn_lbl_SelfAssessment"));
	}

	private MobileElement socialDistancingDescription() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("optIn_lbl_SocialDistancing"));
	}

	private MobileElement covidIcon() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("optIn_img_covidIcon"));
	}

	private MobileElement backButton() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("optIn_btn_Backbutton"));
	}

	private MobileElement saveButton() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("optOut_btn_Save"));
	}

	private MobileElement header() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("optOut_lbl_H&S"));
	}

	private MobileElement menuIconInHomeScrn() throws Exception {
		return Element.findElementbyXpath("//*[@id='readersButton']//preceding::*[1]");
	}
public static boolean isAccessDenied = true;

	private MobileElement healthAndSafetyTracking() throws Exception {
		if (GenericFunctions.isIOS() && isAccessDenied) {
			return Element.findElementbyIdIndex(ObjectMap.getvalue("Preferences_lbl_options"),
					Integer.parseInt(ObjectMap.getvalue("Preferences_Cell_HealthAndSafetyTrackingIndex_optOut")));
		} else {
			return Element.findElementbyIdIndex(ObjectMap.getvalue("Preferences_lbl_options"),
					Integer.parseInt(ObjectMap.getvalue("Preferences_Cell_HealthAndSafetyTrackingIndex")));
		}
	}

	private MobileElement notificationDetailBackbtn() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Rename_btn_back"));
	}

	public String getHeaderText() throws Exception {
		return header().getText();
	}

	public void continueBtnInLocationScrn() throws Exception {
		Element.waitForElement(locationContinueBtn(), 20);
		locationContinueBtn().click();
	}

	public boolean waitForOptIn() {
		try {
			return Element.waitforVisible("id", ObjectMap.getvalue("optIn_lbl_H&S"), 50);
		} catch (Exception e) {
			return false;
		}
	}

	public void disableSelfAssChkBox() throws Exception {
		if (GenericFunctions.isIOS()) {
			if (selfAssessmentChkBox().getAttribute("value").equalsIgnoreCase("checkBox checked")) {
				selfAssessmentChkBox().click();
			}

		} else {
			if (Element.getCheckBoxStatus(selfAssessmentChkBox())) {
				selfAssessmentChkBox().click();
			}
		}
	}

	public void enableSelfAssChkBox() throws Exception {
		if (GenericFunctions.isIOS()) {
			if (selfAssessmentChkBox().getAttribute("value").equalsIgnoreCase("checkBox unChecked")) {
				selfAssessmentChkBox().click();
			}

		} else {
			if (!Element.getCheckBoxStatus(selfAssessmentChkBox())) {
				selfAssessmentChkBox().click();
			}
		}
	}

	public void disableSocialDistChkBox() throws Exception {

		if (GenericFunctions.isIOS()) {
			if (socialDistancingChkBox().getAttribute("value").equalsIgnoreCase("checkBox checked")) {
				socialDistancingChkBox().click();
			}

		} else {
			if (Element.getCheckBoxStatus(socialDistancingChkBox())) {
				socialDistancingChkBox().click();
			}
		}
	}

	public void enableSocialDistChkBox() throws Exception {
		if (GenericFunctions.isIOS()) {
			if (socialDistancingChkBox().getAttribute("value").equalsIgnoreCase("checkBox unChecked")) {
				socialDistancingChkBox().click();
			}

		} else {
			if (!Element.getCheckBoxStatus(socialDistancingChkBox())) {
				socialDistancingChkBox().click();
			}
		}
	}

	public void selfAssRequiredPopupOkBtn() throws Exception {
		selfAssRequiredOkBtn().click();
	}

	public String assReqTitle() throws Exception {
		return assessReqTitle().getText();
	}

	public String selfAssRequiredPopUpDescription() throws Exception {
		return selfAssRequiredPopUpMsg().getText();
	}

	public void clickContinueButton() throws Exception {
		// Element.waitforVisible("id", ObjectMap.getvalue("optIn_lbl_H&S"), 30000);
		Element.swipeDown(30);
		continueButton().click();
	}

	public String healthAndSafetyDescriptionText() throws Exception {
		return healthAndSafetyDescription().getText();
	}

	public String selfAssDescriptionText() throws Exception {
		return selfAssessmentDescription().getText();
	}

	public String socialDistDescriptionText() throws Exception {
		return socialDistancingDescription().getText();
	}

	public void sideMenuIconInHomeScren() throws Exception {
		menuIconInHomeScrn().click();
	}

	public void clickOnHealthAndSafetyTracking() throws Exception {
		healthAndSafetyTracking().click();
	}

	public void saveButtonInOptoutScrn() throws Exception {
		Element.swipeDown(30);
		saveButton().click();
	}

	public String healthAndSafetyTitle() throws Exception {
		if(GenericFunctions.isIOS()) {
		return healthAndSafety().getText();
		}
		else
		{
			String firstPart1=healthAndSafety().getText();
			String secoundPart=contactNotification().getText();
			return firstPart1+" "+secoundPart;
		}
	}

	public String selfAssessment() throws Exception {
		return selfAssessmentTitle().getText();
	}

	public String socialDistancing() throws Exception {
		return socialDistancingTitle().getText();
	}

	public void clickBackbtn() throws Exception {
		notificationDetailBackbtn().click();
	}

	public void clickOkPopup() throws Exception {
		if (GenericFunctions.isAndroid()) {
				GenericFunctions.acceptAlert();
		} else {
				GenericFunctions.clickAlertButton(0);

		}
	}
	
	public boolean selfAssTitle() throws Exception
	{
		try {
			return Element.waitforVisible("id", ObjectMap.getvalue("selfAss_txt_HeaderTitle"), 30);
		} catch (Exception e) {
			return false;

		}
	}

	public boolean waitForOptOut() {
		try {
			return Element.waitforVisible("id", ObjectMap.getvalue("optIn_lbl_H&S"), 30);
		} catch (Exception e) {
			return false;
		}
	}
}
