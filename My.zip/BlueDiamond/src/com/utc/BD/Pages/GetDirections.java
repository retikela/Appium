package com.utc.BD.Pages;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.Reporter;

import com.appium.Common.AppiumSetup;
import com.appium.Common.Element;
import com.appium.Common.GenericFunctions;
import com.appium.Common.Gestures;
import com.appium.Common.ObjectMap;

import io.appium.java_client.MobileElement;

public class GetDirections {

	public MobileElement header_getDirections() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("getDirections_lbl_header"));
	}
	
	/*public MobileElement clickFilter() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("getDirections_btn_filter"));
	}*/
	
	// written by Ravinder 
	public MobileElement clickFilter() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("poi_Filter"));
	}
	public MobileElement btnFliterApply() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("getDirections_btn_fliterapply"));
	}
	private MobileElement ConferenceRoom() throws Exception{
		return Element.findElementbyIdIndex(ObjectMap.getvalue("Filter_lbl_floorList"), Integer.parseInt(ObjectMap.getvalue("Fliter_Cell_firstindex")));
	}
	public MobileElement FilterClear() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Filter_lbl_Clear"));
	}
	/*public MobileElement FilterApply () throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Filter_lbl_Apply"));
	}*/
	public MobileElement FilterApply () throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("getDirections_btn_fliterapply"));
	}

	public MobileElement FilterAllfloorstab () throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Filter_lbl_AllFloorsTab"));
	}
	public MobileElement ClickFilterApply () throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Filter_lbl_Apply"));
	}
	public void clickConfernceRoom() throws Exception{
		ConferenceRoom().click();
	}
	public void clickFilterAllfloors() throws Exception{
		FilterAllfloorstab().click();
	}
	public void clickClearfilter() throws Exception{
		FilterClear().click();
	}
	public void clickFilterApply() throws Exception{
		FilterApply().click();
	}
	public void clickonFilter() throws Exception {
		clickFilter().click();

	}
	public MobileElement btnclickapply() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("getDirections_btn_click"));
	}

	public MobileElement btn_cancel() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("getDirections_lbl_cancel"));
	}

	public MobileElement startField() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("getDirections_tbx_start"));
	}

	public MobileElement endField() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("getDirections_tbx_end"));
	}

	public MobileElement imgDirection() throws Exception {
		if (GenericFunctions.isIOS()) {
			return Element.findElementbyID(ObjectMap.getvalue("getDirections_img_direction"));
		} else {
			return Element.findElementbyXpath(ObjectMap.getvalue("getDirections_img_direction"));
		}
	}

	public MobileElement verbiage() throws Exception {
		if (GenericFunctions.isIOS()) {
			return Element.findElementbyID(ObjectMap.getvalue("getDirections_lbl_verbiage"));
		} else {
			return Element.findElementbyXpath(ObjectMap.getvalue("getDirections_lbl_verbiage"));
		}
	}

	public MobileElement btnPreviewRoute() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("getDirections_btn_previewRoute"));
	}
//
	public MobileElement chooseStartandEnd() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("getDirection_lbl_chosestart_end"));
	}
	public String btnPreviewRoutegettext() throws Exception
	{
		return btnPreviewRoute().getText();
	}
	public MobileElement btnClearStart() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("getDirections_btn_clearStart"));
	}

	public MobileElement btnClearEnd() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("getDirections_btn_clearEnd"));//getDirections_btn_clearEnd
	}

	public MobileElement imgPOI() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("getDirections_img_poi"));
	}

	public String chooseStartandEndText() throws Exception
	{
		return chooseStartandEnd().getText();
	}
	public String verifyPageTitle() throws Exception {
		return header_getDirections().getText();
	}

	public String getVerbiage() throws Exception {
		return verbiage().getText();
	}

	public void clickCancel() throws Exception {
		btn_cancel().click();
		Reporter.log("Clicked on cancel button from Get Direction screen");
	}

	public void clickOnStartFiled() throws Exception {
		startField().click();
		Reporter.log("Clicked on Start feild");
		GenericFunctions.getInstance().pressBack();
	}

	public void clickOnEndFiled() throws Exception {
		endField().click();
		Reporter.log("Clicked on End feild");
		GenericFunctions.getInstance().pressBack();
	}

	public String selectRandomPOIForStart() throws Exception {
		MobileElement poi;
		MobileElement searchString;
		int count = 0;
		String poiName = "";
		String poiNameSubString = "";
		List<MobileElement> poiCount = Element.findElementsbyXpath(ObjectMap.getvalue("getDirection_lbl_poiCount"));
		Thread.sleep(1000);
		count = poiCount.size();

		Random r = new Random();
		int randomNumber = r.nextInt(count - 1) + 1;
		if (GenericFunctions.isAndroid()) {
			poi = Element.findElementbyXpath("(//*[@id='listPOI' or @id='listBrowseMaps']//*[@id='poiName'])[" + randomNumber + "]");
		} else {
			poi = Element.findElementbyXpath("(//*[@id='poiName'])[" + randomNumber + "]");	
		}
		poiName = poi.getText();
		Thread.sleep(1000);
		Reporter.log("Randomly choosen POI is : "+poiName+" ");

		if (GenericFunctions.isIOS()) {
			poiNameSubString = poiName.substring(0, 2);
			Thread.sleep(1000);
			startField().sendKeys(poiNameSubString);
			Thread.sleep(1000);
			Reporter.log("Entered search string as : "+poiNameSubString+" ");
			List<MobileElement> filterPoiCount = Element.findElementsbyXpath(ObjectMap.getvalue("getDirection_lbl_poiCount"));
			Thread.sleep(2000);
			for (int i=0; i< filterPoiCount.size() ; i++) {
				if(filterPoiCount.get(i).getText().contains(poiName)) {
					Thread.sleep(1000);
					MobileElement clickPOI = filterPoiCount.get(i);
					Reporter.log("Start POI is selected");
					Thread.sleep(1000);
				}
			}
		} else {
			startField().sendKeys(poiName);
			Reporter.log("Entered search string as : "+poiName+" ");
			Thread.sleep(1000);
			searchString = Element.findElementbyXpath("//*[@id='poiName' and @text='" + poiName + "']");
			searchString.click();
			Thread.sleep(1000);
		}

		return poiName;

		/*startField().sendKeys(poiName);
		if (GenericFunctions.isAndroid()) {
			searchString = Element.findElementbyXpath("//*[@id='poiName' and @text='" + poiName + "']");
		} else {
			searchString = Element.findElementbyXpath("//*[@class='UIAImage']//following-sibling::*[@class='UIAStaticText' and @text='" + poiName + "']");	
		}
		if (poiName.contentEquals(searchString.getText())) {
			return true;
		} else {
			return false;
		}*/
	}

	public MobileElement selectRandomPOI() throws Exception {
		MobileElement poi;
		Random r = new Random();
		int count = 0;
		int randomNumber = r.nextInt(count - 1) + 1;
		if (GenericFunctions.isAndroid()) {
			poi = Element.findElementbyXpath("(//*[@id='listPOI' or @id='listBrowseMaps']//*[@id='poiName'])[" + randomNumber + "]");
		} else {
			poi = Element.findElementbyXpath("(//*[@id='poiName'])[" + randomNumber + "]");	
		}
		return poi;
	}

	public void selectRandomPOIEnd(String startPOI) throws Exception {
		MobileElement poi;
		MobileElement searchString;
		int count = 0;
		int randomNumber = 0;
		String poiName = "";
		Random r ;
		String poiNameSubString = "";
		List<MobileElement> poiCount = Element.findElementsbyXpath(ObjectMap.getvalue("getDirection_lbl_poiCount"));
		Thread.sleep(1000);
		count = poiCount.size();

		r = new Random();
		randomNumber = r.nextInt(count - 1) + 1;
		if (GenericFunctions.isAndroid()) {
			poi = Element.findElementbyXpath("(//*[@id='listPOI' or @id='listBrowseMaps']//*[@id='poiName'])[" + randomNumber + "]");
		} else {
			poi = Element.findElementbyXpath("(//*[@id='poiName'])[" + randomNumber + "]");	
		}

		poiName = poi.getText();
		Thread.sleep(1000);
		if (GenericFunctions.isIOS()) {
			poiNameSubString = poiName.substring(0, 2);
			Thread.sleep(1000);
			endField().sendKeys(poiNameSubString);
			Thread.sleep(1000);
			Reporter.log("Entered "+poiNameSubString+" as search string in the End feild");
			List<MobileElement> filterPoiCount = Element.findElementsbyXpath(ObjectMap.getvalue("getDirection_lbl_poiCount"));
			Thread.sleep(2000);
			for (int i=0; i< filterPoiCount.size() ; i++) {
				if(filterPoiCount.get(i).getText().contains(poiName)) {
					Thread.sleep(1000);
					clickJS(filterPoiCount.get(i));
					Reporter.log("End POI is selected");
					Thread.sleep(1000);
				}
			}
		} else {

			while(startPOI.equals(poiName)) {
				r = new Random();
				randomNumber = r.nextInt(count - 1) + 1;
				if (GenericFunctions.isAndroid()) {
					poi = Element.findElementbyXpath("(//*[@id='listPOI' or @id='listBrowseMaps']//*[@id='poiName'])[" + randomNumber + "]");
				} else {
					poi = Element.findElementbyXpath("(//*[@id='poiName'])[" + randomNumber + "]");	
				}

				poiName = poi.getText();
			}

			endField().sendKeys(poiName);
			Thread.sleep(1000);
			Reporter.log("Entered "+poiName+" as search string in the End feild");
			/*searchString = Element.findElementbyXpath("//*[@id='poiName' and @text='" + poiName + "']");
			searchString.click();*/
			Thread.sleep(1000);
		}
	}	

	public boolean selectRandomPOIForEnd() throws Exception {
		MobileElement poi;
		MobileElement searchString;
		try {
			List<MobileElement> poiCount = Element.findElementsbyXpath(ObjectMap.getvalue("getDirection_lbl_poiCount"));
			int count = poiCount.size();
			Random r = new Random();
			int randomNumber = r.nextInt(count - 1) + 1;
			if (GenericFunctions.isAndroid()) {
				poi = Element.findElementbyXpath("(//*[@id='listPOI' or @id='listBrowseMaps']//*[@id='poiName'])[" + randomNumber + "]");
			} else {
				poi = Element.findElementbyXpath("(//*[@id='poiName'])[" + randomNumber + "]");	
			}
			String poiName = poi.getText();
			endField().sendKeys(poiName);
			if (GenericFunctions.isAndroid()) {
				searchString = Element.findElementbyXpath("//*[@id='poiName' and @text='" + poiName + "']");
			} else {
				searchString = Element.findElementbyXpath("//*[@class='UIAImage']//following-sibling::*[@class='UIAStaticText' and @text='" + poiName + "']");	
			}
			if (poiName.contentEquals(searchString.getText())) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			return true;
		}
	}


	public boolean clickPOI() throws Exception {
		MobileElement poi;
		MobileElement searchString;
		int count = 0;
		List<MobileElement> poiCount = Element.findElementsbyXpath(ObjectMap.getvalue("home_lbl_poiList"));
		count = poiCount.size();

		Random r = new Random();
		int randomNumber = r.nextInt(count - 1) + 1;
		if (GenericFunctions.isAndroid()) {
			poi = Element.findElementbyXpath(
					"(//*[@id='listPOI' or @id='listBrowseMaps']//*[@id='poiName'])[" + randomNumber + "]");
		} else {
			poi = Element.findElementbyXpath(
					"(//*[@class='UIAImage']//following-sibling::*[@class='UIAStaticText'][1])[" + randomNumber + "]");
		}

		String poiName = poi.getText();
		startField().sendKeys(poiName);
		if (GenericFunctions.isAndroid()) {
			searchString = Element.findElementbyXpath("//*[@id='poiName' and @text='" + poiName + "']");
		} else {
			searchString = Element.findElementbyXpath(
					"//*[@class='UIAImage']//following-sibling::*[@class='UIAStaticText' and @text='" + poiName + "']");
		}
		if (poiName.contentEquals(searchString.getText())) {
			return true;
		} else {
			return false;
		}
	}

	public void debug() throws Exception {
		MobileElement poi;
		String poiName = "";
		/* List<MobileElement> poiCount = Element.findElementsbyXpath(ObjectMap.getvalue("points_lbl_poiCount"));
        count = poiCount.size();*/

		poi = Element.findElementbyXpath("(//*[@id='map']//*[@content-desc='Google Map']//*[@class='android.view.View'])[1]");
		poiName = poi.getAttribute("contentDescription");
		poiName = poiName.substring(0, poiName.length() - 1);

		/*poi.click();
        Thread.sleep(1000);
        String selectedpoitxt = getSelectedPoiText();

        if (selectedpoitxt.contains(poiName)) {
            flagList.add(true);



        } else {
            flagList.add(false);
        }
        clickGetDirections();



        if (endField().getText().contains(selectedpoitxt)) {
            flagList.add(true);
        } else {
            flagList.add(false);
        }
        return getList(flagList);*/
	}

	public boolean getList(ArrayList<Boolean> flagList) {

		if (flagList.contains(false)) {
			return false;
		} else {
			return true;
		}

	}

	public void clickJS(MobileElement element) {

		JavascriptExecutor executor = (JavascriptExecutor)AppiumSetup.driver;
		executor.executeScript("arguments[0].click();", element);
	}

	public void clickPreviewRoute() throws Exception {

		btnPreviewRoute().click();
		Reporter.log("Clicked on preview route button");
	}

}
