package com.utc.BD.Pages;

import java.util.List;

import com.appium.Common.Element;
import com.appium.Common.Gestures;
import com.appium.Common.ObjectMap;

import io.appium.java_client.MobileElement;

public class Preferences {
	
	private MobileElement header() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Preferences_Navbar_Header"));
	}
	
	public boolean waitforPreferencesHeader() throws Exception {
		return Element.waitForElement(header());
	}
	
	public String getHeaderText() throws Exception{
		return header().getText();
	}
	
	private MobileElement backButton() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Preferences_btn_Back"));
	}
	
	public void clickBack() throws Exception{
		backButton().click();
	}
	
	
	
	private MobileElement backgroundServices() throws Exception{
		return Element.findElementbyIdIndex(ObjectMap.getvalue("Preferences_lbl_options"), Integer.parseInt(ObjectMap.getvalue("Preferences_Cell_BackgroundServicesIndex")));
	}
	
	private MobileElement notifications() throws Exception{
		return Element.findElementbyIdIndex(ObjectMap.getvalue("Preferences_lbl_options"), Integer.parseInt(ObjectMap.getvalue("Preferences_Cell_NotificationsIndex")));
	}
	
	private MobileElement sensitivity() throws Exception{
		return Element.findElementbyIdIndex(ObjectMap.getvalue("Preferences_lbl_options"), Integer.parseInt(ObjectMap.getvalue("Preferences_Cell_SensitivityIndex")));
	}
	
	private MobileElement pathways() throws Exception{
		return Element.findElementbyIdIndex(ObjectMap.getvalue("Preferences_lbl_options"), Integer.parseInt(ObjectMap.getvalue("Preferences_Cell_PathwaysIndex")));
	}
	
	private MobileElement favorites() throws Exception{
		return Element.findElementbyIdIndex(ObjectMap.getvalue("Preferences_lbl_options"), Integer.parseInt(ObjectMap.getvalue("Preferences_Cell_FavoritesIndex")));
	}
	
	private MobileElement hidden() throws Exception{
		return Element.findElementbyIdIndex(ObjectMap.getvalue("Preferences_lbl_options"), Integer.parseInt(ObjectMap.getvalue("Preferences_Cell_HiddenIndex")));
	}
	
	private MobileElement Gestures() throws Exception{
		return Element.findElementbyIdIndex(ObjectMap.getvalue("Preferences_lbl_options"), Integer.parseInt(ObjectMap.getvalue("Preferences_Cell_GesturesIndex")));
	}
	
	private MobileElement locationSettings() throws Exception{
		return Element.findElementbyIdIndex(ObjectMap.getvalue("Preferences_lbl_options"), Integer.parseInt(ObjectMap.getvalue("Preferences_Cell_LocationSettings")));
	}
	
	public void clickBackgroundServices() throws Exception {
		backgroundServices().click();
	}
	
	public void clickNotifications() throws Exception {
		notifications().click();
	}
	
	public void clickSensitivity() throws Exception {
		sensitivity().click();
	}
	
	public void clickPathways() throws Exception {
		pathways().click();
	}
	
	public void clickHidden() throws Exception {
		hidden().click();
	}
	
	public void clickFavorites() throws Exception {
		favorites().click();
		Thread.sleep(2000);
	}
	
	public void clickGestures() throws Exception {
		Gestures().click();
	}
	
	public void clickLocationSettings() throws Exception {
		locationSettings().click();
	}
	
	public String getBackgroundServicesTxt() throws Exception {
		return backgroundServices().getText();
	}
	
	public String getNotificationsTxt() throws Exception {
		return notifications().getText();
	}
	
	public String getSensitivityTxt() throws Exception {
		return sensitivity().getText();
	}
	
	public String getPathwaysTxt() throws Exception {
		return pathways().getText();
	}
	
	public String getHiddenTxt() throws Exception {
		return hidden().getText();
	}
	
	public String getFavoritesTxt() throws Exception {
		return favorites().getText();
	}
	
	public String getGesturesTxt() throws Exception {
		return Gestures().getText();
	}
	
	
//	private MobileElement priorityTop() throws Exception{
//		return Element.findElementbyXpath(ObjectMap.getvalue("Preferences_Cell_SortPriorityTop"));
//	}
//	
//	public void clickPriorityTop() throws Exception{
//		priorityTop().click();
//	}
//	
//	private MobileElement priorityBottom() throws Exception{
//		return Element.findElementbyXpath(ObjectMap.getvalue("Preferences_Cell_SortPriorityBottom"));
//	}
//	
//	public void clickPriorityBottom() throws Exception{
//		priorityBottom().click();
//	}
//	
//	private MobileElement priorityBottomTickmark() throws Exception{
//		return Element.findChildElementsbyClass(priorityBottom(), GenericFunctions.getButtonClass()).get(0);
//	}
//	
//	public boolean isCheckedPriorityBottom() throws Exception{
//		String check = priorityBottomTickmark().getText();
//		if(check!=null&&check.equalsIgnoreCase(ObjectMap.getvalue("Preferences_btn_SortPriorityChecked"))){
//			return true;
//		}
//		return false;
//	}
//	
//	private MobileElement priorityTopTickmark() throws Exception{
//		return Element.findChildElementsbyClass(priorityTop(), GenericFunctions.getButtonClass()).get(0);
//	}
//	
//	public boolean isCheckedPriorityTop() throws Exception{
//		String check = priorityTopTickmark().getText();
//		if(check!=null&&check.equalsIgnoreCase(ObjectMap.getvalue("Preferences_btn_SortPriorityChecked"))){
//			return true;
//		}
//		return false;
//	}

	
	private MobileElement hideReader() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Preferences_btn_hiddenDoor"));
	}
	
	private MobileElement show() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Preferences_lbl_Show"));
	}
	
	public boolean waitforShowoption() throws Exception {
		return Element.waitForElement(show());
	}
	
	public void clickShow() throws Exception {
		show().click();
	}
	
	private MobileElement showImage() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Preferences_img_ShowImg"));
	}
	
	public List<MobileElement> getSectionlist() throws Exception{
		return Element.findElementsbyID(ObjectMap.getvalue("Preferences_lbl_sectionHeader"));
	}
	
	public MobileElement Hidden() throws Exception{
		return getSectionlist().get(Integer.parseInt(ObjectMap.getvalue("Preferences_lbl_HiddenIndex")));
	}
	
	public String getHiddenText() throws Exception{
		return Hidden().getText();
	}
	
	public MobileElement BGNotifications() throws Exception{
		return getSectionlist().get(Integer.parseInt(ObjectMap.getvalue("Preferences_lbl_BackgroundNotificationsIndex")));
	}
	
	public String getBGNotificationsText() throws Exception{
		return BGNotifications().getText();
	}
	
	private MobileElement Sensitivity() throws Exception{
		return getSectionlist().get(Integer.parseInt(ObjectMap.getvalue("Preferences_lbl_Sensitivity")));
	}
	
	public String getSensitivityText() throws Exception{
		return Sensitivity().getText();
	}
	
//	public List<MobileElement> getHideReaderList() throws Exception{
//		List<MobileElement> readers;
//		readers = Element.findElementsbyID(ObjectMap.getvalue("Preferences_btn_hiddenDoor"));
//		return readers;
//		
//	}
	
//	public List<MobileElement> getShowbtnList() throws Exception{
//		List<MobileElement> showbtns;
//		showbtns = Element.findElementsbyID(ObjectMap.getvalue("Preferences_lbl_Show"));
//		return showbtns;
//		
//	}
	
//	public List<String> hiddenreaders = new ArrayList<String>();
//	public List<String> getHiddenReaders() throws Exception{
//		hiddenreaders.clear();
//		for (MobileElement reader : getHideReaderList()) {
//			hiddenreaders.add(reader.getText());
//		}
//		return hiddenreaders;
//	}
	
//	public void unhideAllReaders() throws Exception{
////		for (MobileElement reader : getHideReaderList()) {
////			unhideReader(reader);
////		}
//		List<MobileElement> readers = getHideReaderList();
//		for (int i=0;i<readers.size();i++)
//		{
//			readers.get(i).click();
//			getShowbtnList().get(i).click();
//			
//		}
//	}
	
//	public void unhideReader(MobileElement reader) throws Exception{
//		reader.click();
////		waitforShowoption();
////		show().click();
//	}
	
	private MobileElement Less() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Preferences_lbl_Min"));
	}
	
	public String getLessText() throws Exception{
		return Less().getText();
	}
	
	private MobileElement More() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Preferences_lbl_Max"));
	}
	
	public String getMoreText() throws Exception{
		return More().getText();
	}
	
	private MobileElement sensitivitySlider() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Preferences_slider_Sensitivity"));
	}
	
	public void setMinvalToSlider() throws Exception{
//		sensitivitySlider().sendKeys("0.2");
		new Gestures().horizontalSwipe(sensitivitySlider());
//		Element.swipeSliderLeft(sensitivitySlider(), 10);
//		sensitivitySlider().setValue("0%");
	}
	
	public String getSensitivitySliderVal() throws Exception{
		return sensitivitySlider().getAttribute("value");
	}
	
	public void setMaxvalToSlider() throws Exception{
		sensitivitySlider().setValue("100%");
	}
	
}
