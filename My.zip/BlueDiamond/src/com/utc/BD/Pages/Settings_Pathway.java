package com.utc.BD.Pages;

import java.util.ArrayList;
import java.util.List;

import com.appium.Common.Element;
import com.appium.Common.GenericFunctions;
import com.appium.Common.Gestures;
import com.appium.Common.ObjectMap;

import io.appium.java_client.MobileElement;

public class Settings_Pathway{
	
	private MobileElement header() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Pathways_lbl_Header"));
	}
	
	public boolean waitforSettingsPathwaysHeader() throws Exception {
		return Element.waitForElement(header());
	}
	
	public String getHeaderText() throws Exception {
		return Element.getElementText(header());
	}
	
	
	private MobileElement back() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Pathways_btn_Back"));
	}
	
	public void clickBack() throws Exception{
		back().click();
	}
	
	private MobileElement lblSettingsPathwayTitle() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Pathways_lbl_Title"));
	}
	
	public String getTitleText() throws Exception {
		return Element.getElementText(lblSettingsPathwayTitle());
	}
	
	private MobileElement lblAddPathway() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Pathways_lbl_infoAddPathway"));
	}
	
	public String getAddPathwayText() throws Exception {
		return Element.getElementText(lblAddPathway());
	}
	
	private MobileElement btnAdd() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Pathways_img_addIcon"));
	}
	
	public void clicAddPathwayButton() throws Exception{
		btnAdd().click();
	}
	
	private List<MobileElement> lblPathwayNames() throws Exception{
		return Element.findElementsbyID(ObjectMap.getvalue("Pathways_lbl_pathwayNames"));
	}
	
	private List<String> pathwayNames = new ArrayList<String>();
	public List<String> getPathwayNames() throws Exception {
		pathwayNames.clear();
		for (MobileElement pathway : lblPathwayNames()) {
			pathwayNames.add(Element.getElementText(pathway));
		}
		System.out.println("Pathway Names : "+pathwayNames);
		return pathwayNames;
	}
	
	private List<MobileElement> btnDeleteIcon() throws Exception{
		return Element.findElementsbyID(ObjectMap.getvalue("Pathways_btn_deleteIcon"));
	}
	
	public void clickDeleteIcon(int index) throws Exception {
		btnDeleteIcon().get(index).click();;
	}
	
	private List<MobileElement> btnEditIcon() throws Exception{
		return Element.findElementsbyID(ObjectMap.getvalue("Pathways_btn_editIcon"));
	}
	
	public void clickEditIcon(int index) throws Exception {
		btnEditIcon().get(index).click();
	}
	
	private MobileElement btnReOrderIcon(String name) throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Pathways_btn_reOrderIcon")+" "+name);
	}
	
	public void swapPathwayNames(String pathway1, String pathway2) throws Exception {
//		int pathway1Index = getPathwayNames().indexOf(pathway1);
//		int pathway2Index = getPathwayNames().indexOf(pathway2);
		Gestures.dragAndDrop(btnReOrderIcon(pathway1), btnReOrderIcon(pathway2), 5);
	}
	
	public void deletePathway(String pathwayName) throws Exception {
		int pathwayIndex = getPathwayNames().indexOf(pathwayName);
		clickDeleteIcon(pathwayIndex);
	}
	
	public void editPathway(String pathwayName) throws Exception {
		int pathwayIndex = getPathwayNames().indexOf(pathwayName);
		clickEditIcon(pathwayIndex);
	}
	
	public void deleteAllpAthways() throws Exception {
		for (MobileElement deleteIocn : btnDeleteIcon()) {
			clickDeleteIcon(0);
//			deleteIocn.click();
			System.out.println("Alert Title: "+GenericFunctions.getInstance().getAlertTitle());
			System.out.println("Alert Message: "+GenericFunctions.getInstance().getAlertMessage());
			if(GenericFunctions.isAndroid())
			GenericFunctions.acceptAlert();
			else
				GenericFunctions.declineAlert();
			Thread.sleep(1000);
		}
	}
	
}
