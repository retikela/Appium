package com.utc.BD.Pages;
//Map-lbl-unabletodisplaymap
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.Reporter;

import com.appium.Common.AppiumSetup;
import com.appium.Common.Element;
import com.appium.Common.GenericFunctions;
import com.appium.Common.ObjectMap;

import io.appium.java_client.MobileElement;

public class MapPage {
	
	public static  boolean waitforMapsHeader() throws Exception {
		return Element.waitForElement(MapsHeader());
	}
	private static MobileElement MapsHeader() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("maps_lbl_MapsTab"));
	}

	private static MobileElement UnabletoDisplayMap() throws Exception{
		return Element.findElementbyID(ObjectMap.getvalue("Map-lbl-unabletodisplaymap"));
	}
	
	public MobileElement btnReaders() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("home_btn_readers"));
	}

	public MobileElement btnMaps() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("home_btn_maps"));
	}

	public MobileElement btnSearch() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("home_btn_search"));
	}

	public MobileElement btnCampuses() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("home_btn_campuses"));
	}

	public MobileElement btnDirections() throws Exception {
		if (GenericFunctions.isAndroid()) {
			return Element.findElementbyID(ObjectMap.getvalue("home_btn_directions"));
		} else {
			return Element.findElementbyID(ObjectMap.getvalue("home_btn_direction"));
		}
	}
	
	public MobileElement poiCard() throws Exception {
		if (GenericFunctions.isAndroid()) {
			return Element.findElementbyXpath(ObjectMap.getvalue("home_lbl_poiCard"));
		} else {
			return Element.findElementbyXpath(ObjectMap.getvalue("home_lbl_poiCard"));
		}
	}

	public MobileElement btnFloors() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("home_btn_floors"));
	}

	public MobileElement btnPathway() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("home_btn_pathway"));
	}

	public MobileElement progress() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("home_progressBar_loading"));
	}
	
	public MobileElement floorNumber() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("home_lbl_floorNumber"));
	}
	
	public MobileElement snagBar() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Home_lbl_locationVerbiage"));
	}
	
	
	// Door Open card
	public MobileElement doorOpenCard() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Home_lbl_doorOpenLayout"));
	}
	
	public MobileElement lblDoorOpenStatus() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Home_lbl_credentialSent"));
	}
	
	public MobileElement lblDoorName() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Home_lbl_selectedReaderName"));
	}
	
	public MobileElement lblDoorVerb() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Home_lbl_readerName"));
	}
	
	public MobileElement imgCloseCard() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Home_img_readerClose"));
	}
	
	public MobileElement imgDoorOpen() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Home_img_doorUnclocked"));
	}
	
	public MobileElement readerNameFromReadersTab() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Home_lbl_readerNameReadersTab"));
	}
	
	// Pathway layout
	public MobileElement lblPathwayLayout() throws Exception {
		if(GenericFunctions.isAndroid()) {
		return Element.findElementbyXpath(ObjectMap.getvalue("Home_lbl_pathwayLayout"));
		} else {
			return Element.findElementbyXpath(ObjectMap.getvalue("Home_lbl_pathwayLayout"));
		}
	}
	
	public MobileElement pathwayLayout() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Home_lyt_pathwayLayout"));
	}
	
	public MobileElement lblPathwayLayout_readers() throws Exception {
		if (GenericFunctions.isAndroid()) {
			return Element.findElementbyXpath(ObjectMap.getvalue("Home_lbl_reader"));
		} else {
			return Element.findElementbyXpath(ObjectMap.getvalue("Home_lbl_reader"));
		}
	}
	
	public MobileElement lblPathwayLayout_pathway() throws Exception {
		if (GenericFunctions.isAndroid()) {
			return Element.findElementbyXpath(ObjectMap.getvalue("Home_lbl_pathway"));
		} else {
			return Element.findElementbyXpath(ObjectMap.getvalue("Home_lbl_pathway"));
		}
	}
	
	public MobileElement btnStartPathway() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Home_btn_startPathway"));
	}
	
	public MobileElement btnUnlockDoor() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Home_btn_unclockDoor"));
	}
	
	public MobileElement imgClosePathwayLayout() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Home_img_pathwayClose"));
	}
	
	public MobileElement imgReaderPoiPathway() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Home_img_pathway"));
	}
	
	public MobileElement lblReaderNameInPathwayLayout() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Home_lbl_readerName_pathwayLayout"));
	}
	
	public MobileElement lblPathwayNameInPathwayLayout() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Home_lbl_pathwayName_pathwayLayout"));
	}
	
	
	
	
	

	public void clickMaps() throws Exception {
		btnMaps().click();
		Reporter.log("Clicked on Maps tab");
		Thread.sleep(1500);
	}

	public void clickReaders() throws Exception {
		btnReaders().click();
		Reporter.log("Clicked on Readers tab");
		Thread.sleep(1500);
	}

	public void clickSearch() throws Exception {
		btnSearch().click();
		Reporter.log("Clicked on Search icon");
		Thread.sleep(1500);
	}

	public void clickCampuses() throws Exception {
		btnCampuses().click();
		Reporter.log("Clicked on Campuses icon");
		Thread.sleep(1500);
	}

	public void clickDirections() throws Exception {
		btnDirections().click();
		Reporter.log("Clicked on Directions icon");
		Thread.sleep(1500);
	}

	public void clickFloors() throws Exception {
		floorNumber().click();
		Reporter.log("Clicked on Floors icon");
		Thread.sleep(1500);
	}
	
	public MobileElement selectedPOI() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Home_lbl_selectedPoi"));
	}
	
	public String getSelectedPoiText() throws Exception {
		return selectedPOI().getText();

	}
	
	public String getFloorNumber() throws Exception {
		return floorNumber().getText();

	}
	
	public MobileElement btngetDirections() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("home_lbl_getdirections"));
	}
	
	public String UnabletoDisplayMapgetText() throws Exception
	{
		return UnabletoDisplayMap().getText();
	}
	public void clickGetDirections() throws Exception{
		btngetDirections().click();
		Reporter.log("Clicked on Directions icon from the POI info card");
		Thread.sleep(1000);
	}
	
	public MobileElement endField() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("getDirections_tbx_end"));
	}

	public boolean waitForLoading() {
		boolean syncComplete = Element.waitforInVisibility("id", "progressBar", 30);
		Reporter.log("Waiting for sync progress bar to disappear.");
		return syncComplete;
	}
	
	public boolean waitForSearchIconToAppear() {
		boolean syncComplete = Element.waitforVisible("id", "imageButtonSearch", 30);
		Reporter.log("Waiting for sync progress bar to disappear.");
		return syncComplete;
	}

	public boolean verifySearchAvailibility() throws Exception {
		boolean flag = false;
		try {
			if (btnMaps().isDisplayed()) {
				return flag;
			}
		} catch (Exception e) {
			return flag;
		}
		return flag;
	}
	
	public boolean verifyEndFromPOICard() throws Exception {
		MobileElement poi;
		ArrayList<Boolean> flagList = new ArrayList<Boolean>();
		int count = 0;
		String poiName = "";
		List<MobileElement> poiCount = Element.findElementsbyXpath(ObjectMap.getvalue("home_lbl_poiList"));
		count = poiCount.size();

		Random r = new Random();
		int randomNumber = r.nextInt(count - 1) + 1;
		if (GenericFunctions.isAndroid()) {
			poi = Element.findElementbyXpath("(//*[@id='map']//*[@content-desc='Google Map']//*[@class='android.view.View'])[" + randomNumber + "]");
		} else {
			poi = Element.findElementbyXpath("(//*[@XCElementType='XCUIElementTypeMap']/..//following-sibling::*[@XCElementType='XCUIElementTypeOther']/*)[" + randomNumber + "]");
		}
		
		if (GenericFunctions.isAndroid()) {
		poiName = poi.getAttribute("contentDescription");
		poiName = poiName.substring(0, poiName.length() - 2);
		} else {
			poiName = poi.getText();
			Reporter.log("Selected POI text is : "+poiName+" ");
		}

		// Click on POI from Maps screen
		poi.click();
		Reporter.log("Clicked on POI");
		Thread.sleep(1000);
		
		// Retrieve POI name from the card and verify it with POI selected
		String selectedpoitxt = getSelectedPoiText();

		if (selectedpoitxt.contains(poiName)) {
			flagList.add(true);
			Reporter.log("Text for the searched POI is as expected.");
		} else {
			flagList.add(false);
		}
		
		// Click on the direction icon on the card and verify the end field is filled with POI selected
		
		clickGetDirections();

		if (endField().getText().contains(selectedpoitxt)) {
			flagList.add(true);
			Reporter.log("POI updated in the End feild is as expected");
		} else {
			flagList.add(false);
		}
		
		return getList(flagList);
	}
	
	public boolean verifyEndFromDirections() throws Exception {
		MobileElement poi;
		ArrayList<Boolean> flagList = new ArrayList<Boolean>();
		int count = 0;
		String poiName = "";
		List<MobileElement> poiCount = Element.findElementsbyXpath(ObjectMap.getvalue("home_lbl_poiList"));
		count = poiCount.size();

		Random r = new Random();
		int randomNumber = r.nextInt(count - 1) + 1;
		if (GenericFunctions.isAndroid()) {
			poi = Element.findElementbyXpath("(//*[@id='map']//*[@content-desc='Google Map']//*[@class='android.view.View'])[" + randomNumber + "]");
		} else {
			poi = Element.findElementbyXpath("(//*[@XCElementType='XCUIElementTypeMap']/..//following-sibling::*[@XCElementType='XCUIElementTypeOther']/*)[" + randomNumber + "]");
		}
		
		if (GenericFunctions.isAndroid()) {
		poiName = poi.getAttribute("contentDescription");
		poiName = poiName.substring(0, poiName.length() - 2);
		} else {
			poiName = poi.getText();
			Reporter.log("Selected POI text is : "+poiName+" ");
		}

		// Click on POI from Maps screen
		poi.click();
		Reporter.log("Clicked on POI");
		Thread.sleep(1000);
		
		// Retrieve POI name from the card and verify it with POI selected
		String selectedpoitxt = getSelectedPoiText();

		if (selectedpoitxt.contains(poiName)) {
			flagList.add(true);
			Reporter.log("Text for the searched POI is as expected.");
		} else {
			flagList.add(false);
		}
		
		// Click on the direction icon from the widget and verify the end field is filled with POI selected

		clickDirections();

		if (endField().getText().contains(selectedpoitxt)) {
			flagList.add(true);
			Reporter.log("POI updated in the End feild is as expected");
		} else {
			flagList.add(false);
		}
		
		return getList(flagList);
	}
	
	public boolean getList(ArrayList<Boolean> flagList) {

		 if(flagList.contains(false)) {
            return false;
        } else {
            return true;
        }
    }

	public MobileElement startField() throws Exception {
        return Element.findElementbyID(ObjectMap.getvalue("directions_tbx_start"));
    }  
	

	public boolean verifySnagBarAvailibility() throws Exception {
		boolean flag = false;
		try {
			if (snagBar().isDisplayed()) {
				return flag;
			}
		} catch (Exception e) {
			return flag;
		}
		return flag;
	}
	
	public void clickDeviceBackButton() throws InterruptedException {
		GenericFunctions.navigateBack();
		Thread.sleep(1500);
		Reporter.log("Clicked on device back button");
	}


	// Door Open scenario
	
	public String getReaderName() throws Exception {
		return lblDoorName().getText();

	}
	
	public String getReaderNameReaderTab() throws Exception {
		return readerNameFromReadersTab().getText();

	}
	
	public void clickCloseIconOnDoorOpenCard() throws Exception{
		imgCloseCard().click();
		Reporter.log("Clicked on close icon on the Door Open card");
		Thread.sleep(1000);
	}
	
	// Pathway scenarios

	public String getPathwayLayOutText() throws Exception {
		return lblPathwayLayout().getText();

	}
	public MobileElement mapErormessage() throws Exception {
		return Element.findElementbyID(ObjectMap.getvalue("Map-lbl-errormessage"));
	}
	public String mapErrormessagetext() throws Exception 
	{
		return mapErormessage().getText();
	}

}
