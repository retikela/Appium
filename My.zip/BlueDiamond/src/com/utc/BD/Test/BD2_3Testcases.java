package com.utc.BD.Test;

import java.util.List;

import javax.swing.text.View;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.appium.Common.Configure;
import com.appium.Common.GenericFunctions;
import com.appium.Common.Gestures;
import com.appium.Common.ObjectMap;
import com.appium.Common.SwitchContext;
import com.utc.BD.Pages.Favorites;
import com.utc.BD.Pages.Mostused;
import com.utc.BD.Pages.Nearby;
import com.utc.BD.Pages.ReadersHeaderNdFooter;
import com.utc.BD.Pages.ReadersList;
import com.utc.BD.Pages.Setup;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class BD2_3Testcases extends Setup {

	static ReadersHeaderNdFooter readerHnF;
	static ReadersList readersPage;
	static Favorites fav;
	static TestCases testCases;
	Mostused mostused;
	Nearby nearby;
	Configure config = new Configure();

	@BeforeClass
	public void initiateDriver() {
		readerHnF = ReadersHeaderNdFooter.getInstance(driver);
		readersPage = new ReadersList(driver);
		fav = new Favorites();
		testCases = new TestCases();
		testCases.initiateDriver();
		mostused = new Mostused(driver);
		nearby = new Nearby(driver);
	}

//	To verify the selected view is loaded, view name and check mark is displayed after selection
	@Test(description = "TC45371, ,TC45949")
	public void SelectMostUsedView() throws Exception {
		String view = ObjectMap.getvalue("Home_lbl_MostUsed_txt");
		if (!(readerHnF.getviewsDropdownText().equalsIgnoreCase(view))) {
			readerHnF.clickViewsDropdown();
			readerHnF.clickviewsDropdownvalue(view);
			Assert.assertEquals(readerHnF.getviewsDropdownText(), view, "View is not selected");
			if (new Configure().isiOS()) {
				readerHnF.clickViewsDropdown();
				Assert.assertTrue(readerHnF.isviewSelected(view), "selected view is not checked");
				readerHnF.clickViewsDropdown();
//		if(readersPage.getReadersList().size()>0) 
//		Assert.assertEquals(readerHnF.getRightbtntxt(), ObjectMap.getvalue("MostUsed_btn_HeaderRightbtn_txt"),"Delete button is not displayed");
			}
		}
	}

	@Test(description = "TC45370,TC45433,TC45948,TC45958")
	public void SelectNearbyView() throws Exception {
		String view = ObjectMap.getvalue("Home_lbl_Nearby_txt");
		if (!(readerHnF.getviewsDropdownText().equalsIgnoreCase(view))) {
			readerHnF.clickViewsDropdown();
			readerHnF.clickviewsDropdownvalue(view);
			Assert.assertEquals(readerHnF.getviewsDropdownText(), view, "View is not selected");
			if (new Configure().isiOS()) {
				readerHnF.clickViewsDropdown();
				Assert.assertTrue(readerHnF.isviewSelected(view), "selected view is not checked");
				readerHnF.clickViewsDropdown();
				Assert.assertEquals(readerHnF.getRightbtntxt(), ObjectMap.getvalue("Nearby_btn_HeaderRightbtn_txt"),
						"Refresh button is not displayed");
			}
		}
	}

	@Test(description = "TC45372,TC45951")
	public void SelectMapsView() throws Exception {
		String view = ObjectMap.getvalue("Home_lbl_Maps_txt");
		if (!(readerHnF.getviewsDropdownText().equalsIgnoreCase(view))) {
			readerHnF.clickViewsDropdown();
			readerHnF.clickviewsDropdownvalue(view);
			Assert.assertEquals(readerHnF.getviewsDropdownText(), view, "View is not selected");
			readerHnF.clickViewsDropdown();
			Assert.assertTrue(readerHnF.isviewSelected(view), "selected view is not checked");
			readerHnF.clickViewsDropdown();
		}
	}

//	To verify the delete button is displayed in most used view
	@Test
	public void VerifyDeletebtninMostUsedView() throws Exception {
		SelectMostUsedView();
//		if(readersPage.getReadersList().size()>0)
//		Assert.assertEquals(readerHnF.getRightbtntxt(),ObjectMap.getvalue("MostUsed_btn_HeaderRightbtn_txt"),"Delete button is not displayed");
//		else
//			TO-DO Validate the no readers usage data message
	}

//	To verify the Refresh button is displayed in Nearby view
	@Test
	public void VerifyRefreshbtninNearbyView() throws Exception {
		SelectNearbyView();
		Assert.assertEquals(readerHnF.getRightbtntxt(), ObjectMap.getvalue("Nearby_btn_HeaderRightbtn_txt"),
				"Refresh button is not displayed");
	}

//	To verify the delete button functionality in most used view (clearing the list and pop-up)
	@Test
	public void VerifPopuponDeletbtn() throws Exception {
		VerifyDeletebtninMostUsedView();
		if (readersPage.getReadersList().size() > 0) {
			readerHnF.clickRightbtn();
//		System.out.println(readerHnF.getPopupText());
//		System.out.println(readerHnF.getPopupTitle());
			sa.assertEquals(readerHnF.getPopupTitle(), ObjectMap.getvalue("MostUsed_lbl_deletepopup-header_txt"));
			sa.assertEquals(readerHnF.getPopupText(), ObjectMap.getvalue("MostUsed_lbl_deletepopup-desc_txt"));
			if (config.isiOS()) {
				sa.assertEquals(readerHnF.getPopupDeletetxt(), ObjectMap.getvalue("MostUsed_btn_Acceptalert_txt"));
				sa.assertEquals(readerHnF.getPopupCanceltxt(), ObjectMap.getvalue("MostUsed_btn_Cancelalert_txt"));
			}
			readerHnF.selectDeleteinPopup();
			List<MobileElement> readersList = readersPage.getReadersList();
			Assert.assertTrue(readersList.size() == 0);
		} else {
//			throw new SkipException("Skipping the testcas as readers list is empty");
		}
		sa.assertAll();
	}

	@Test(description = "Verfiy the selected reader is unlocked after selecting lock icon in Nearby Screen" + "TC45532"
			+ "TC45534" + "TC45537" + "TC45973" + "TC45974" + "TC45978"+"TC48832"+"TC47105")
	public void verifyUnlockDoorinNearby() throws Exception {
		VerifPopuponDeletbtn();
		SelectNearbyView();
		List<MobileElement> readersList = readersPage.getReadersList();
		readerHnF.clickRightbtn();
		if (!(readersList.size() > 0)) {
			readersPage.waitForSettings();
			testCases.navigateFromHomeToFavorites();
			fav.DeleteAllReaders();
			testCases.navigateFromFavoritesToHome();
		}
		String unlockedReader = unlockReaderFromlist(0);
		Thread.sleep(3000);
		SelectMostUsedView();
		Assert.assertTrue(readersPage.getReaders().contains(unlockedReader),
				"unlocked reader in nearby is not displayed in most used");
		sa.assertAll();
	}

	@Test(description = "Verfiy the selected reader is unlocked after selecting lock icon in most used")
	public void verifyUnlockDoorinMostUsed() throws Exception {
		verifyUnlockDoorinNearby();
		unlockReaderFromlist(0);
	}

	public String unlockReaderFromlist(int i) throws Exception {
		List<MobileElement> readersList = readersPage.getReadersList();
		String unlockedReader;
//		readerHnF.clickRightbtn();
		if (readersList.size() > i) {
			readersPage.clickReader(readersList.get(i));
			sa.assertEquals(readersList.get(i).getText(), readerHnF.getReaderNickname(),
					"Selected reader text is not displayed as expected");
		} else if (readersList.size() == 0) {
			Assert.fail("Readers list is empty");
		}
		Assert.assertTrue(readerHnF.isUnlockimgDisplayed(), "unlock image is not displayed");
		unlockedReader = readersList.get(i).getText();
		sa.assertEquals(readerHnF.getFooterStatus(), ObjectMap.getvalue("status_unclock"),
				"Unlocking text is expected");
		readerHnF.clickUnlock();
		// sa.assertTrue(readersPage.waitForAnimation(), "Animation is not displayed");
//		 sa.assertEquals(readerHnF.getFooterStatus(),
//		 ObjectMap.getvalue("status_unclocking"),
//		 "Unlocking text is expected");
		sa.assertEquals(readerHnF.getReaderNickname(), readersList.get(i).getText(),
				"Selected reader text is not displayed during unlocking");
		if (config.isAndroid())
			Thread.sleep(4000);
		sa.assertAll();
		return unlockedReader;

	}

	@Test(description = "verify the MostUsed view when there are no readers")
	public void verifyEMptyMostUsedView() throws Exception {
		verifyUnlockDoorinNearby();
		readerHnF.clickRightbtn();
		readerHnF.selectDeleteinPopup();
		sa.assertEquals(mostused.getnoReadersHeaderlbltxt(), ObjectMap.getvalue("MostUsed_lbl_noReaders-header_txt"));
		sa.assertEquals(mostused.getnoReadersDesclbltxt(),
				ObjectMap.getvalue("MostUsed_lbl_noReaders-description_txt"));
		sa.assertEquals(mostused.getSeeNearbybtntxt(), ObjectMap.getvalue("MostUsed_lbl_seeNearbyReaders_txt"));
//		if(config.isiOS())
//		sa.assertFalse(readerHnF.isUnlockimgDisplayed(),"unlock image is displayed");
		sa.assertAll();
	}

	@Test(description = "verify user is navigated to Nearby Screen on clicking See Nearby" + "TC47115"+"47091")
	public void verifySeeNearbyonclick() throws Exception {
		SelectMostUsedView();
		if (readersPage.getReadersList().size() > 0) {
			readerHnF.clickRightbtn();
			readerHnF.selectDeleteinPopup();
		}
		mostused.clickSeeNearbybtn();
		String view = ObjectMap.getvalue("Home_lbl_Nearby_txt");
		Assert.assertEquals(readerHnF.getviewsDropdownText(), view, "Nearby View is not displayed");

	}

	@Test(description = "verify the MostUsed view delete reader from list")
	public void verifydeleteReader() throws Exception {
		verifyUnlockDoorinNearby();
		deleteReaderFromlist(0);
	}

	@Test(description = "verify the Nearby view when there are no readers" + "TC45499" + "TC45432" + "TC45411"
			+ "TC45961" + "TC45434" + "TC45962" + "TC45965" + "TC45967")
	public void verifyEmptyNearbyView() throws Exception {
		testCases.setSnsitivityto(0);
		SelectNearbyView();
		Thread.sleep(3000);
		sa.assertEquals(nearby.getnoReadersHeaderlbltxt(), ObjectMap.getvalue("Nearby_lbl_noReaders-header_txt"));
		sa.assertEquals(nearby.getnoReadersDesclbltxt(), ObjectMap.getvalue("Nearby_lbl_noReaders-description_txt"));
		sa.assertEquals(nearby.getRefreshbtntxt(), ObjectMap.getvalue("Nearby_lbl_Refresh_txt"));
		testCases.setSnsitivityto(100);
		sa.assertAll();
	}

	public String deleteReaderFromlist(int i) throws Exception {
		List<MobileElement> readersList = readersPage.getReadersList();
		String deletedReader;
		deletedReader = readersList.get(i).getText();
		Assert.assertTrue(readersPage.getReaders().contains(deletedReader), "reader is not displayed in most used");
		if (readersList.size() > i) {
			new Gestures().swipeFromRightToLeft(readersList.get(i), 90);
			mostused.clickreaderDelbtn(i);
		} else if (readersList.size() == 0) {
			Assert.fail("Readers list is empty");
		}
		Assert.assertFalse(readersPage.getReaders().contains(deletedReader), "reader is not displayed in most used");
		return deletedReader;

	}

	@Test(description = "verify the views options text")
	public void validateDropDownOptions() throws Exception {
		readerHnF.clickViewsDropdown();
		List<String> dropdownVals = readerHnF.getviewsDropdownvalues();
		sa.assertEquals(dropdownVals.get(0), ObjectMap.getvalue("Home_lbl_MostUsed_txt"));
		sa.assertEquals(dropdownVals.get(1), ObjectMap.getvalue("Home_lbl_Maps_txt"));
		sa.assertEquals(dropdownVals.get(2), ObjectMap.getvalue("Home_lbl_Nearby_txt"));
		sa.assertEquals(dropdownVals.get(3), ObjectMap.getvalue("Home_lbl_Pathways_txt"));
		readerHnF.clickviewsDropdownvalue(dropdownVals.get(2));
		testCases.deletePathway();
		testCases.createPathway(1);
		sa.assertAll();
	}

}
