package com.utc.BD.Test;

import javax.lang.model.util.Elements;

import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.Test;

import com.appium.Common.Configure;
import com.appium.Common.Element;
import com.appium.Common.GenericFunctions;
import com.appium.Common.ObjectMap;
import com.utc.BD.Pages.AccessDenied;
import com.utc.BD.Pages.CtHealthAndSafety;
import com.utc.BD.Pages.CtNotifications;
import com.utc.BD.Pages.CtSelfAssessment;
import com.utc.BD.Pages.Help;
import com.utc.BD.Pages.LoginPage;
import com.utc.BD.Pages.Preferences;
import com.utc.BD.Pages.ReadersList;
import com.utc.BD.Pages.Settings;
import com.utc.BD.Pages.Setup;
import com.utc.BD.Pages.WalkThrough;
import com.utc.BD.Pages.Widget;

import io.appium.java_client.MobileElement;
import com.utc.BD.Pages.WalkThrough;
import com.utc.BD.Pages.MapPage;


public class TestCaseForContractTracing extends Setup  {
	
	LoginPage lp = new LoginPage();
	ReadersList readersPage = new ReadersList();
	Configure config = new Configure();
	WalkThrough walk = new WalkThrough();
	CtHealthAndSafety healthAndSafety=new CtHealthAndSafety();
	CtSelfAssessment selfAss=new CtSelfAssessment();
	CtNotifications ctNotification=new CtNotifications();
	Settings settings=new Settings();
	Preferences preferences = new Preferences();
	GenericFunctions genericfnc= GenericFunctions.getInstance();
	TestCases TC = new TestCases();
	MapPage mp=new MapPage();
	Help help = new Help(driver);
	AccessDenied accessDenied = new AccessDenied();
	
	@Test(description = "Verify Optin screen TC4435,TC4437,TC4438,TC5244,TC5248,TC4431,TC4433,TC4434,TC5249,TC4488,TC4524, TC4525 Total Count=12")
	public void optinValidations() throws Exception {
		/*
		 * click on Continue btn ,And verify alret ->click on Ok 
		 * */

		Assert.assertTrue( healthAndSafety.waitForOptIn(), "Optin page is not Displaying");
		healthAndSafety.clickContinueButton();
		sa.assertEquals(ObjectMap.getvalue("optIn_selfAssRequiredPopupTitle_txt"), genericfnc.getAlertTitle(),"Validating selfAss popup Title");
		sa.assertEquals(ObjectMap.getvalue("optIn_selfAssRequiredPopupDesceiption_txt"), genericfnc.getAlertMessage(),"Validating selfAss popup Alrt Message");
		healthAndSafety.clickOkPopup();
		 Assert.assertTrue(healthAndSafety.waitForOptIn(),"Optin screen is not displayed after clicking po-up");
		 /*
		  * Verify Ui Elements and Description and checked both chk box and click on continue btn
		  * */
		 sa.assertEquals(ObjectMap.getvalue("healthAndSafety_HealthandSftyTitle_txt"), healthAndSafety.healthAndSafetyTitle(),"Validate healthAndSafety_HealthandSftyTitle");
	     sa.assertEquals(ObjectMap.getvalue("healthAndSafety_selfAssessment_txt"), healthAndSafety.selfAssessment(),"Validate selfAssessment ");
	    // sa.assertEquals(ObjectMap.getvalue("healthAndSafety_socialDistancing_txt"), healthAndSafety.socialDistancing(),"Validate Social Distancing");
		 sa.assertEquals(ObjectMap.getvalue("optIn_txt_HealthAndSafetyDesceiption_txt"), healthAndSafety.healthAndSafetyDescriptionText(),"Validate Health and safety Description");
		 sa.assertEquals(ObjectMap.getvalue("optIn_txt_SelfAssDesceiption_txt"), healthAndSafety.selfAssDescriptionText(),"Validate Self Ass Description");
		 sa.assertEquals(ObjectMap.getvalue("optIn_SocialDistancing_txt"), healthAndSafety.socialDistDescriptionText(),"Validating Social Distance Description");
		 healthAndSafety.enableSelfAssChkBox();
		 healthAndSafety.enableSocialDistChkBox();
		 healthAndSafety.clickContinueButton();
		 Assert.assertTrue( healthAndSafety.selfAssTitle(), "SelfAssT page is not Displaying");
		 sa.assertAll();
	}
	
	@Test(description = "Verify OptOut Screen TC4477,TC4480,TC4481,TC4483,TC4484,TC4491,TC4493,TC4495,TC4497,TC4498,TC4499,TC4500"
			+ "TC4159,TC4531,TC4522,TC4523,TC4528,TC4530,TC4531,TC4532,TC4533,TC4534,TC4535,TC4536,TC4488,TC4524, TC4525  Total Count=27 ")
	public void optOutValidations() throws Exception
	{
	navigateFromMainPageToOptOutPage();
		/*
		 * Uchk both chk box ,click on Save btn ,And verify alret ->click on Ok 
		 * */
	healthAndSafety.disableSelfAssChkBox();
	healthAndSafety.disableSocialDistChkBox();
		healthAndSafety.saveButtonInOptoutScrn();
		sa.assertEquals(ObjectMap.getvalue("optIn_selfAssRequiredPopupTitle_txt"), genericfnc.getAlertTitle(),"Validating selfAss popup Title");
		sa.assertEquals(ObjectMap.getvalue("optIn_selfAssRequiredPopupDesceiption_txt"),genericfnc.getAlertMessage(),"Validating selfAss popup Alrt Message");
		healthAndSafety.clickOkPopup();
		Assert.assertTrue(healthAndSafety.waitForOptOut(),"OptOut screen is not displayed after clicking po-up");
		 /*
		  * Verify Ui Elements and Description and checked both chk box and click on continue btn
		  * */ 
		 sa.assertEquals(ObjectMap.getvalue("healthAndSafety_HealthandSftyTitle_txt"), healthAndSafety.healthAndSafetyTitle(),"Validate healthAndSafety_HealthandSftyTitle");
	     sa.assertEquals(ObjectMap.getvalue("healthAndSafety_selfAssessment_txt"), healthAndSafety.selfAssessment(),"Validate self-ass title");
	    // sa.assertEquals(ObjectMap.getvalue("healthAndSafety_socialDistancing_txt"), healthAndSafety.socialDistancing(),"Validate social dist title");
		 sa.assertEquals(ObjectMap.getvalue("optIn_txt_HealthAndSafetyDesceiption_txt"), healthAndSafety.healthAndSafetyDescriptionText(),"Validate HealthAndSafetyDesceiption");
		 sa.assertEquals(ObjectMap.getvalue("optIn_txt_SelfAssDesceiption_txt"), healthAndSafety.selfAssDescriptionText(),"Validate SelfAssDesceiption");
		 sa.assertEquals(ObjectMap.getvalue("optIn_SocialDistancing_txt"), healthAndSafety.socialDistDescriptionText(),"validate SocialDistancing description");
		healthAndSafety.enableSelfAssChkBox();
		healthAndSafety.enableSocialDistChkBox();
		healthAndSafety.saveButtonInOptoutScrn();
		Assert.assertEquals(preferences.getHeaderText(), ObjectMap.getvalue("Preferences_Header_Txt"),
				"Unable to navigate Preferences page");
		navigateFromOptOutPageToMainPage();
	}
	
	
	@Test(description = "Verify Notification should mark as Read after clicking on notification ,TC5374"
			+ "TC4813 , Total Count=2")
	public void verifyNotificationMarkRead() throws Exception
	{try {
		navigateFromMainPageToNotificationPage();
		if(ctNotification.totalNumberOFTooCloseNotification()>0) {
			Assert.assertEquals(ctNotification.clickOnNotificationAndVerifyIVDot(),0);
	}else {
		throw new SkipException("Skipping the testcases as Notification list is empty");
	}
	}catch (Exception e) {
		Assert.fail("Failed to execute the test case");
	}
	finally {
		navigateFromNotificationPageToMainPage();
		}
	}
	
	@Test(description = "quarantineStarted Notification validations TC5380,TC5393,TC5406 "
			+ "TC4810,TC5392 , Total Count=5")
	public void quarantineNotificationValidation() throws Exception
	{ 
		navigateFromMainPageToNotificationPage();
		/*Notification recv time and click on qurantine strd in Notification tray  */
		if(ctNotification.totalNumberOFQurantineNotification()>0) {
			String dateAndTime=ctNotification.QuarantinenotificationRcvTime();
			ctNotification.clickOnQuarantineStrtd();
			/*Comparing date and time  and validating all elements in quarantine Notification detail page */
			Assert.assertTrue(ctNotification.waitforNotificationHeader(), "Unable to navigate quarantine strd Notification detail page");
			sa.assertEquals(ctNotification.timeAndDateQurantineNotification(),dateAndTime,"date And Time Validation");
			sa.assertEquals(ctNotification.QurantineStrtdTitle(), ObjectMap.getvalue("notification_txt_quarantine"),"Quarantine started Title Validation");
			sa.assertEquals(ctNotification.notificationDescription(), ObjectMap.getvalue("notification_txt_notificationdescription"),"Notification description Validation");
			sa.assertEquals(ctNotification.verifyDeleteBtn(),"Delete button is not Displaying");
			sa.assertAll();
			ctNotification.clickBackbtn();	
	}else {
		Assert.fail("Failed testcases as Qurantine Notification not received");
	}
		navigateFromNotificationPageToMainPage();
	}
	
	@Test(description = "TooClose Notification validations TC5372,TC5378,TC5377,TC5406,TC5406"
			+ "TC4810,TC4811,TC5351,TC4817 ,TC5405 Total Count=10")
	public void tooCloseNotificationValidation() 
	{ 
		try {
			navigateFromMainPageToNotificationPage();
		
		/*Notification recv time and click on Tooclose in Notification tray  */
		if(ctNotification.totalNumberOFTooCloseNotification()>0) {
		String dateAndTime=ctNotification.tooCloseNotificationRcvTime();
		int CountTooclosenBfreDelete=ctNotification.totalNumberOFTooCloseNotification();
		ctNotification.clickOnTooClose();
		/*Comparing date and time  and validating all elements in Too close Notification detail page */
		Assert.assertTrue(ctNotification.waitforNotificationHeader(), "Unable to navigate Tooclose Notification detail page");
		sa.assertEquals(ctNotification.timeAndDateQurantineNotification(),dateAndTime,"Data and Time Validation for quarantine Notification");
		sa.assertEquals(ctNotification.tooCloseTitle(), ObjectMap.getvalue("notification_lbl_ToocloseTitle"),"Too close Title valiodation");
		sa.assertEquals(ctNotification.toCloseNotificationDescription(), ObjectMap.getvalue("notification_lbl_descriptionTooclose"),"Too close Notification description Validation");
		sa.assertEquals(ctNotification.verifyDeleteBtn(),"Delete button is Displaying");
		ctNotification.clickOnDeleteBtn();
		/*Verify Delete Notification popup all Elements*/
		 Assert.assertTrue( ctNotification.verifyDeleteNotificationPopupTitle(), "Delete Notification popup is not Displaying");
		 sa.assertEquals(ObjectMap.getvalue("notification_deleteNtfnTitle_txt"), ctNotification.titleOfDeleteNotifictnPopUp(),"Validate deleteNotification popup title");
		 sa.assertEquals(ObjectMap.getvalue("notification_descriptionMsgDeletePopup_txt"), ctNotification.deleteNotifictnPopUpDescriptionMsg(),"Validate deleteNotification popup discription");
		 /*click on Cancel btn on delete notification popup and verify It should Be on same page*/
		 ctNotification.clickCancelBtnOnDeleteNtfnPopup();
		 Assert.assertTrue(ctNotification.waitforNotificationHeader(), " Notification detail page is not Displaying");
		 /*click on Delete btn in Notification detail page*/
		 ctNotification.clickOnDeleteBtn();
		 /*click on delete btn in Delete Notification popup and verify after delete it should Navigate to Notification tray*/
		 ctNotification.clickDeleteBtnOnDeleteNotifictnPopup();
		 Assert.assertEquals(ctNotification.getHeaderText(), ObjectMap.getvalue("notification_Header_Txt"));
		int CountTooclosenAftrDelete=ctNotification.totalNumberOFTooCloseNotification();
		/*Verify Tooclose Notification is getting deleted*/
		sa.assertEquals(CountTooclosenBfreDelete,CountTooclosenAftrDelete+1);
		sa.assertAll();
		}else {
			throw new SkipException("Skipping the testcases as Too close Notification not received");
		}
		} catch (Exception e) {
			Assert.fail("Failed to execute the TooClose Notification test case");
		}
		finally {
			try {
				navigateFromNotificationPageToMainPage();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	
	@Test(description = "Verify all Notification should display as Read after clicking on 'Mark all as Read' btn TC5374,TC5373,TC5375" 
			+ " TC4811,TC4812,TC4813,TC4814 Total Count=7")
	public void veridfyMarkAllAsRead() 
	{
		try {
			navigateFromMainPageToNotificationPage();
		
		if(ctNotification.getNotifications().size()>0) {
		sa.assertEquals(ctNotification.VerifymarkAllRead(),"markAllRead button is Displaying");
		int totalNotificationBfreClickMrkAllRead=ctNotification.totalNotificationReceived();
		ctNotification.clickMarkAllRead();
		 Assert.assertEquals(ctNotification.getHeaderText(), ObjectMap.getvalue("notification_Header_Txt"));
		System.out.println(ctNotification.ivDotCount());
		sa.assertEquals(ctNotification.ivDotCount(),0);
		/*verify total notification count should same befre click markAllaread btn*/
		sa.assertEquals(ctNotification.totalNotificationReceived(),totalNotificationBfreClickMrkAllRead,"Validate Total Unread Notification");
		sa.assertAll();
		}else {
			throw new SkipException("Skipping the testcases as Notification not received");
		}
		} catch (Exception e) {
			Assert.fail("Failed to execute the veridfyMarkAllAsRead test case");
		}
		finally {
			try {
				navigateFromNotificationPageToMainPage();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
	}
	
	public void navigateFromNotificationPageToMainPage() throws Exception {
		ctNotification.clickBackbtn();
		if(genericfnc.isIOS()) {
			Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
		settings.clickCloseButton();
		Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers page");
		}
	}

	public void navigateFromMainPageToNotificationPage() throws Exception {
		readersPage.waitForSettings();
		readersPage.clickSettings();
		Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
		settings.clickNotification();
		Assert.assertEquals(ctNotification.getHeaderText(), ObjectMap.getvalue("notification_Header_Txt"));
		
	}

	public void navigateFromOptOutPageToMainPage() throws Exception {
		healthAndSafety.clickBackbtn();
		if(genericfnc.isIOS()) {
		Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
		settings.clickCloseButton();
		Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers page");
		}
	}
    
	public void navigateFromMainPageToOptOutPage() throws Exception {
		readersPage.waitForSettings();
		readersPage.clickSettings();
		Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
		settings.clickPreferences();
		Assert.assertEquals(preferences.getHeaderText(), ObjectMap.getvalue("Preferences_Header_Txt"),
				"Unable to navigate Preferences page");
		sa.assertEquals(ObjectMap.getvalue("Preferences_Header_Txt"), preferences.getHeaderText(),"validate prefrences Header");
		healthAndSafety.clickOnHealthAndSafetyTracking();
		 sa.assertEquals(ObjectMap.getvalue("healthAndSafety_HealthandSftyTitle_txt"), healthAndSafety.healthAndSafetyTitle(),"Validate healthAndSafety_HealthandSftyTitle");
		sa.assertAll();
	}
	
	@Test()
    public void walkThrough() throws Exception
    {
       // TC.appLogin();
        try {
           sa.assertEquals(ObjectMap.getvalue("WalkthroughScreen_MapsAndDirections_txt"), walk.MapsAndDirectionsHeaderText());
        	sa.assertEquals(ObjectMap.getvalue("WalkthroughScreen_mapsAndDirectionsDescription_txt"), walk.mapsandDirectionswalkthrough());
            walk.skipBtn().isDisplayed();
            walk.swipewalkthroughscreen();
            sa.assertEquals(ObjectMap.getvalue("WalkthroughScreen_homescreen_txt"), walk.homescreenheader());
            sa.assertEquals(ObjectMap.getvalue("WalkThrough_homescreenDescription_txt"), walk.homescreenwalkthroughText());
            walk.skipBtn().isDisplayed();
            walk.swipewalkthroughscreen();
            sa.assertEquals(ObjectMap.getvalue("WalkthroughScreen_menu_txt"), walk.menuheader());
            sa.assertEquals(ObjectMap.getvalue("WalkThrough_menuDescription_txt"), walk.menuwalkthroughText());
            walk.skipBtn().isDisplayed();
            walk.swipewalkthroughscreen();
            sa.assertEquals(ObjectMap.getvalue("WalkthroughScreen_readeroptions_txt"), walk.readeroptionsheader());
            sa.assertEquals(ObjectMap.getvalue("WalkThrough_readeroptionsDescription_txt"), walk.readeroptionswalkthroughText());
            walk.skipBtn().isDisplayed();
            walk.swipewalkthroughscreen();
            sa.assertEquals(ObjectMap.getvalue("WalkthroughScreen_gesturesheader_txt"), walk.gesturesheader());
            sa.assertEquals(ObjectMap.getvalue("WalkThrough_gesturesDescription_txt"), walk.gestureswalkthroughText());
            walk.skipBtn().isDisplayed();
            walk.swipewalkthroughscreen();
            sa.assertEquals(ObjectMap.getvalue("WalkthroughScreen_pathwaysheader_txt"), walk.pathwaysheader());
            sa.assertEquals(ObjectMap.getvalue("WalkThrough_pathwaysDescription_txt"), walk.pathwayswalkthroughText());
            walk.skipBtn().isDisplayed();
            walk.swipewalkthroughscreen();
            sa.assertEquals(ObjectMap.getvalue("WalkthroughScreen_twofactorauthenticationheader_txt"), walk.twofactorauthenticationheader());
            sa.assertEquals(ObjectMap.getvalue("WalkThrough_twofactorauthenticationDescription_txt"), walk.twofactorauthenticationwalthroughText());
            walk.skipBtn().isDisplayed();
            walk.clickwLearnMore();
            Assert.assertTrue(help.waitforHelpHeader(), "Help page should be displayed");
            help.clickBack();
            walk.swipewalkthroughscreen();
            sa.assertEquals(ObjectMap.getvalue("WalkthroughScreen_Health&SafetyTracking_txt"), walk.HealthAndSafetyTrackingHeader());
            sa.assertEquals(ObjectMap.getvalue("WalkthroughScreen_Health&SafetyTrackingDescription_txt"), walk.HealthAndSafetyTrackingwalkthroughText());
        walk.clickDone();
        walk.clickcontinueBluetoothBtn();
        walk.clickallowBluetoothBtn();
        Assert.assertTrue( walk.locationScreen(), "Location screen is not Displaying");
        locationScrn();
        Assert.assertTrue( healthAndSafety.waitForOptIn(), "Optin page is not Displaying");
        sa.assertAll();
        } catch (Exception e) {
            // TODO Auto-generated catch block
        	Assert.fail();
        }
    }
	
	@Test(description = "User is self assessed as covid positive TC5304,TC5386,TC5426,TC5358,TC5360,TC5399"
			+ "TC5297,TC5385,TC5387,TC5425,TC5364,TC5394,TC5330 ,TC4456,TC5388, TC4468 Total Count=16")
	public void SelfAssessmentasCovidPsitive()
	{
		try {
	      selfAss.waitForSelfAssProgressBar();
			selfAss.waitForSelfAssPageToLoad();
	       selfAss.clickcompleteSA();
		    selfAss.markUserAsCovidPositive();
		    //Click on Apply btn and validate All element on conf popup
			selfAss.clickAplyBtn();
			sa.assertEquals(ObjectMap.getvalue("SelfAssessment_confirmationTitle_txt"), selfAss.conformationPoupTitle(),"Validating Confrmation popup Title");
			//click on cancel btn and validating it is on same page
			 selfAss.clickConfirmCancelBtn(); 
			 sa.assertEquals(ObjectMap.getvalue("SelfAssessment_titleQuestion_txt"), selfAss.AreYouDiagnoisedwithCovidQuetsion());
			 selfAss.clickAplyBtn();
			selfAss.clickConfirmOKBtn();
			Thread.sleep(10000);
			Assert.assertTrue(accessDenied.waitforAccessDeniedHeader(), ObjectMap.getvalue("AccessDenied_Heading_txt"));
			healthAndSafety.isAccessDenied = true;
			String QEDate=accessDenied.getQuarantineEndDate();
			System.out.println(QEDate);
			Thread.sleep(10000);
			quarantineNotificationValidation();
			sa.assertAll();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Assert.fail();
		
		}
	}

	@Test()
	public void selfAssAsCovidNegative() throws Exception
	{
		selfAss.waitForSelfAssProgressBar();
		selfAss.waitForSelfAssPageToLoad();
	   selfAss.clickcompleteSA();
		ValidateSAQuestionnaireForm();
		Thread.sleep(10000);
		selfAss.clickAplyBtn();
		 sa.assertEquals(ObjectMap.getvalue("SelfAssessment_confirmationTitle_txt"), selfAss.conformationPoupTitle(),"Validating Confrmation popup Title");
		//click on cancel btn and validating it is on same page
		 selfAss.clickConfirmCancelBtn(); 
		 sa.assertEquals(ObjectMap.getvalue("SelfAssessment_titleQuestion_txt"), selfAss.AreYouDiagnoisedwithCovidQuetsion());
		 selfAss.clickAplyBtn();
		selfAss.clickConfirmOKBtn();
		Thread.sleep(10000);
		navigateFromMainPageToPrefrencePage();
		sa.assertEquals(selfAss.preferencesOptionWhenCovidNegative(),true,"Verify the preferences option when access denied");
		navigateFromPrefrencePageToMainPage();
		 sa.assertAll();
		
	}
	@Test(description = "User can access the application by taking Self assessment TC5548,TC5385 Total Count=2")
	public void SelfAssessment()
	{
		try {
			selfAssAsCovidNegative();
			Assert.assertTrue(mp.waitforMapsHeader(), "Unable to navigate Maps page");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Assert.fail();
		}
	}
	
	//validate the question-add in commin.properties-call this function in above method
	public void  ValidateSAQuestionnaireForm()
	{
		try {	
			sa.assertEquals(ObjectMap.getvalue("SelfAssessment_titleQuestion_txt"), selfAss.AreYouDiagnoisedwithCovidQuetsion());
			Element.swipeDown(90);
			sa.assertEquals(ObjectMap.getvalue("SelfAssessment_Question1_txt"), selfAss.AreYouExperiencingAnySymptomsQuestion());
			sa.assertEquals(ObjectMap.getvalue("SelfAssessment_Question2_txt"), selfAss.AreYouInContaimentZoneQuestion());
			sa.assertEquals(ObjectMap.getvalue("SelfAssessment_Question3_txt"), selfAss.contactExposureQuestion());
			sa.assertEquals(ObjectMap.getvalue("SelfAssessment_Quetsion4_txt"), selfAss.DoYouRequireCompleteQuarantinePeriodQuestion());
			 Element.swipeUp(90);
			 sa.assertAll();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Assert.fail();		}
	}
	
	@Test(description = "Access Denied Validations TC5355,TC5356 Count=2 ")
	public void accessDeniedValidation() throws Exception
	{
		//Verify the Notification Badge count
		readersPage.waitForSettings();
		readersPage.clickSettings();
		ctNotification.notificationBatchCount();
		settings.clickCloseButton();
		//VerifyAccess denied Title,Description
		Assert.assertTrue(accessDenied.waitforAccessDeniedHeader(), ObjectMap.getvalue("AccessDenied_Heading_txt"));
		sa.assertEquals(accessDenied.accessDeniedDescription(), ObjectMap.getvalue("accessDenied_Description_txt"),"AccessDenied description Validation");
		sa.assertEquals(accessDenied.accessDeniedQuesMsg(), ObjectMap.getvalue("accessDenied_msgQues_txt"),"AccessDenied quesDescription Validation");
		//Click on Refresh, Then verify Title, Decription after click on Refresh btn
		accessDenied.clickRefreshBtn();
		Assert.assertTrue(accessDenied.waitforAccessDeniedHeader(), ObjectMap.getvalue("AccessDenied_Heading_txt"));
		sa.assertEquals(accessDenied.accessDeniedDescription(), ObjectMap.getvalue("accessDenied_Description_txt"),"AccessDenied description Validation");
		sa.assertEquals(accessDenied.accessDeniedQuesMsg(), ObjectMap.getvalue("accessDenied_msgQues_txt"),"AccessDenied quesDescription Validation");
		//Verify Qauarantine Started Notification in Notification tray
		quarantineNotificationValidation();
	     navigateFromMainPageToPrefrencePage();
		//Verify only H&S and Logging options should be displayed in Preferences
		sa.assertEquals(accessDenied.healthAndSafetyTrackingPresent(),true,"Verify the preferences option when access denied");
		//Verify Gesture Option should not display in Preferences
		navigateFromPrefrencePageToMainPage();
		/*navigateFromMainPageToNotificationPage();
		int totalnotificationsCount=ctNotification.notificationsCount();
		navigateFromNotificationPageToMainPage();*/
		//sa.assertEquals(totalnotificationsCount,ctNotification.notificationBatchCount());
	}
	public void navigateFromMainPageToPrefrencePage() throws Exception {
		/*Add assertion for below all */
		readersPage.waitForSettings();
		readersPage.clickSettings();
		Assert.assertTrue(settings.waitforSettingsHeader(), "Unable to navigate Settings page");
		settings.clickPreferences();	
		Assert.assertEquals(preferences.getHeaderText(), ObjectMap.getvalue("Preferences_Header_Txt"),
				"Unable to navigate Preferences page");
	}
	public void navigateFromPrefrencePageToMainPage() throws Exception {
		preferences.clickBack();	
		readersPage.waitForSettings();
		Assert.assertTrue(readersPage.waitForSettings(), "Unable to navigate Readers page");
		settings.clickCloseButton();
		
	}
	
	public void locationScrn() throws Exception
	{
		walk.toggleLocation();
			
	}
	
}
